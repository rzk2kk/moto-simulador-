# MotoSimulador — Unity 6.3 LTS / versão 15

Projeto para o Editor **6000.3.27f2** e URP **17.3.0**. O pacote atual é MotoSimulador_Unity_6000.3.27f2_v15.zip.

## Abrir e testar

1. Extraia o ZIP em uma pasta nova.
2. Abra `ABRIR_JOGO.bat`. Na primeira execução, ele compila o jogo em segundo plano e o inicia automaticamente.
3. Depois da primeira compilação, o mesmo arquivo abre diretamente o executável. Use `ABRIR_PROJETO.bat` para editar no Unity.

Para sair: **I**, segure **Shift** e aperte **Q**; depois segure **W** e solte **Shift**. **A/D** dirigem, **Espaço** freia na frente, **S** freia atrás. **L** farol, **Z/X** setas, **H** alerta; **R** recomeça. Os botões correspondentes também estão no HUD. A liberação da embreagem é mais rápida e os manetes animam com o comando.

É um teste físico em revisão com **parâmetros provisórios**. Esta versão remove os retrovisores, tira as faixas adesivas, permite girar a câmera segurando o botão direito do mouse e arrastando, ajusta altura/distância da câmera em primeira pessoa e anima embreagem, freio, acelerador e chave de ignição. O farol, as setas e a luz de freio usam lentes translúcidas com emissão; foram adicionados sons procedurais de partida e motor ligado. A câmera em terceira pessoa orbita ao redor da moto.

Ajustes contra a instabilidade perto de 20 km/h: subpassos uniformes na faixa de baixa velocidade, torque limitado pela carga traseira estimada, centro de aplicação das forças mais baixo, suspensão mais amortecida e assistência de equilíbrio ativa mesmo com rodas fora do chão. As setas piscam, o farol tem feixe, a luz traseira reage ao freio e o HUD mostra velocímetro ligado à velocidade real do corpo. O limite continua em 50 km/h. A cena deve ser testada no PC; não há confirmação local da física e iluminação do Unity nesta nuvem.

O Editor precisa importar e compilar o projeto na primeira execução, o que pode demorar. O jogo Windows só é produzido no PC porque não há Unity Editor Windows neste ambiente de nuvem. O executável e o log ficam em `Build/Windows` e `Build/primeira_compilacao.log`.

## Estado real

- Modelo original preservado e visível; não substituído por formas genéricas.
- Escala uniforme calculada por entre-eixos configurável; raios medidos no modelo importado.
- Massa de moto/piloto, centro de massa, suspensão e aderência iniciais, ainda sem certificação para o ano da CG enviada.
- Motor, embreagem, marchas e freios independentes ligados a WheelColliders; assistência de equilíbrio e câmera de primeira pessoa.
- 31 testes C# puro aprovados; esses testes não executam Unity/PhysX.
- O código de build e os BATs foram preparados, mas não foi possível executar nem validar o executável sem o Editor Windows.

Consulte Documentation/TESTE_FISICO_v15.md para os ajustes, comandos e limitações. O perfil Assets/MotoSim/Config/PhysicsCalibration.json está marcado ReferenceVerified=false. Não apresentar seus números como especificações oficiais da Honda.

Guidão e conjunto do garfo dianteiro agora acompanham a direção e o curso físico da roda. A pintura preto/amarelo é demonstrativa. A velocidade da pista está limitada a 50 km/h. A câmera alterna entre primeira e terceira pessoa pelo botão no HUD ou tecla V. Amortecedores traseiros, corrente, sistema elétrico, áudio, painel original, piloto 3D, materiais finais, mapa e otimização ainda estão pendentes na Unity. O núcleo físico não equivale ao jogo completo.

## Automação

A marca MotoSimProject.json solicita a cena riding-test. A preparação preserva cenas Untitled em Generated/Recuperadas antes de criar outra cena, mantendo a correção v2. Não sobrescreve uma cena de teste já existente. O menu MotoSim/Abrir teste físico permite retomar; MotoSim/Abrir inspeção da moto mantém acesso à etapa visual anterior.

Câmera ativa e gravação da cena são verificadas antes do marcador de conclusão. Falhas são registradas no Console e em MotoSim_Setup_Error.txt. O relatório de escala/massa/raios é salvo em ProjectSettings/MotoSimCalibrationReport.json após montagem no PC.

## Reprodução

Na raiz do repositório: python3 tools/check_core.py. Gerar o pacote: python3 tools/package_unity_project.py. O núcleo tem fonte única em Assets/MotoSim/Core, referenciada pelos projetos .NET. O SDK local é preparado por tools/setup_dotnet.py com verificação SHA-512 oficial.

O BAT usa a instalação padrão C:\Program Files\Unity\Hub\Editor\6000.3.27f2\Editor\Unity.exe. Se estiver em outra pasta, o Hub pode abrir diretamente a pasta MotoSimulador. Nenhuma reinstalação do Editor é necessária para o pacote.

## Atribuição

CG 160: rafaazx1000, CC-BY-4.0; https://sketchfab.com/3d-models/cg-160-0900747144084e538244f8c504161baa . Modificações: separação de peças, hierarquia, materiais demonstrativos, exportação e montagem de teste. Preservar atribuição e indicação das alterações. Essa é a licença declarada do modelo, não uma declaração de licença para todo o código.
