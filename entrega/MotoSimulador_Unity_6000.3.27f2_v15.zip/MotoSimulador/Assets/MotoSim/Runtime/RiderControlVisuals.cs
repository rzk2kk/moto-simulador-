using UnityEngine;

namespace MotoSim.Unity
{
    /// <summary>Animates the clutch and front-brake levers from the actual rider inputs.</summary>
    public sealed class RiderControlVisuals : MonoBehaviour
    {
        [SerializeField] private Transform clutchLever;
        [SerializeField] private Transform frontBrakeLever;
        [SerializeField] private Transform throttlePivot;
        [SerializeField] private Transform ignitionKeyPivot;
        [SerializeField] private MotorcycleController motorcycle;
        [SerializeField] private float travelDegrees = 14;
        [SerializeField] private float throttleDegrees = 24;
        [SerializeField] private float ignitionDegrees = 32;
        [SerializeField] private float clutchAnimationResponse = 24;
        private Quaternion clutchRest;
        private Quaternion brakeRest;
        private Quaternion throttleRest;
        private Quaternion ignitionRest;

        public void Configure(Transform clutch, Transform frontBrake, Transform throttle,
            Transform ignitionKey, MotorcycleController vehicle)
        {
            clutchLever = clutch;
            frontBrakeLever = frontBrake;
            throttlePivot = throttle;
            ignitionKeyPivot = ignitionKey;
            motorcycle = vehicle;
            clutchRest = clutchLever.localRotation;
            brakeRest = frontBrakeLever.localRotation;
            throttleRest = throttlePivot.localRotation;
            ignitionRest = ignitionKeyPivot.localRotation;
        }

        private void Awake()
        {
            if (clutchLever != null) clutchRest = clutchLever.localRotation;
            if (frontBrakeLever != null) brakeRest = frontBrakeLever.localRotation;
            if (throttlePivot != null) throttleRest = throttlePivot.localRotation;
            if (ignitionKeyPivot != null) ignitionRest = ignitionKeyPivot.localRotation;
        }

        private void LateUpdate()
        {
            if (motorcycle == null) return;
            float clutch = motorcycle.ClutchLever;
            float brake = motorcycle.FrontBrakeInput;
            float throttle = motorcycle.ThrottleInput;
            if (clutchLever != null)
                clutchLever.localRotation = Quaternion.Slerp(clutchLever.localRotation,
                    clutchRest * Quaternion.AngleAxis(-travelDegrees * clutch, Vector3.forward),
                    1 - Mathf.Exp(-clutchAnimationResponse * Time.deltaTime));
            if (frontBrakeLever != null)
                frontBrakeLever.localRotation = brakeRest * Quaternion.AngleAxis(travelDegrees * brake, Vector3.forward);
            if (throttlePivot != null)
                throttlePivot.localRotation = Quaternion.Slerp(throttlePivot.localRotation,
                    throttleRest * Quaternion.AngleAxis(-throttleDegrees * throttle, Vector3.forward),
                    1 - Mathf.Exp(-14 * Time.deltaTime));
            if (ignitionKeyPivot != null)
                ignitionKeyPivot.localRotation = Quaternion.Slerp(ignitionKeyPivot.localRotation,
                    ignitionRest * Quaternion.AngleAxis(motorcycle.Telemetry.EngineRunning ? ignitionDegrees : 0,
                        Vector3.forward), 1 - Mathf.Exp(-10 * Time.deltaTime));
        }
    }
}
