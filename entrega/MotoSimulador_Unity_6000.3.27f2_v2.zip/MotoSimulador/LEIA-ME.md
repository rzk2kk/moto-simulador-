# MotoSimulador — Unity 6.3 LTS

Projeto preparado para o Editor **6000.3.27f2**, instalado no PC do usuário. URP **17.3.0**, versão conferida no repositório oficial Unity-Technologies/Graphics, branch 6000.3/staging.

## Para abrir

No ZIP MotoSimulador_Unity_6000.3.27f2_v2.zip:

1. Extraia todo o conteúdo para uma pasta nova no computador.
2. Abra **ABRIR_PROJETO.bat**.
3. Aguarde o Editor resolver os pacotes e importar o modelo.

O BAT procura a instalação padrão C:\Program Files\Unity\Hub\Editor\6000.3.27f2\Editor\Unity.exe, correspondente à pasta de instalações mostrada pelo usuário. Se a instalação estiver em outra pasta, adicione a pasta MotoSimulador ao Hub. Não é necessário criar um projeto novo ou copiar os componentes um por um.

Na primeira abertura, o código Editor foi preparado para configurar a URP, importar a moto, preparar materiais de inspeção e criar uma cena com câmera e luz. Ao usar Play, a câmera de inspeção gira em torno da moto. Não há pista, mapa ou motocicleta feita de formas genéricas.

**Esta entrega é uma cena de inspeção, ainda não uma moto pilotável.** O Editor não foi executado no ambiente da nuvem; a abertura real precisa ser validada no PC. Não foi criado executável Windows.

## Automação de abertura

Assets/MotoSim/Editor/PrepareInspectionProject.cs só executa automaticamente em um projeto que contenha MotoSimProject.json com o identificador correto. Isso evita alterar outro projeto caso apenas os scripts sejam copiados.

A preparação gera Assets/MotoSim/Generated/CG160_Inspecao.unity e os assets URP e materiais. A conclusão é registrada em ProjectSettings/MotoSimInspectionSetup.json. Cenas e materiais existentes não são regenerados sobre edições manuais. Se houver uma falha, ela é registrada no Console e em MotoSim_Setup_Error.txt; uma preparação incompleta não recebe o marcador de sucesso. O menu MotoSim/Abrir inspeção da moto permite retomar a preparação.

Os materiais são conversões iniciais para URP/Lit. Não há texturização final, pintura automotiva certificada, reflexos calibrados, lentes fotométricas ou validação de desempenho no Intel UHD. O modelo permanece nas unidades originais, sem calibração para metros.

## O que foi validado aqui

- Núcleo C# compilado para .NET Standard 2.1 usando SDK .NET 8.0.427, com **23 cenários executados e aprovados**. Consulte VALIDACAO_CORE.json no ZIP e core-test-report.json na raiz do repositório.
- Sintaxe C# dos arquivos Unity analisada com Roslyn. Essa análise não valida referências/API Unity nem executa os scripts Editor/Runtime.
- Exportação neutra FBX/GLB reimportada no Blender, com hierarquia, UVs e todos os 141.138 triângulos preservados. O manifesto registra hashes e limites.
- Integridade e estrutura do ZIP conferidas. O FBX no projeto é cópia exata do arquivo validado.
- Métodos públicos de criação do asset URP conferidos na fonte oficial 17.3.0. Isso não substitui compilar e abrir o projeto na Unity.

Não foram validados: importação/execução no Editor, materiais finais, URP em tempo real, WheelColliders, colisões, pilotagem, calibração física ou desempenho. O fato de a Unity existir no PC não torna o Editor acessível automaticamente pela máquina da nuvem.

## Código de física preparado

O núcleo em Assets/MotoSim/Core calcula rotação por torque e inércia, marcha lenta, resposta progressiva do acelerador, corte de combustão no limite de giro, embreagem com escorregamento, possibilidade de o motor morrer, câmbio 1–N–2–3–4–5, freio-motor, comandos separados dos freios e consumo simples de combustível.

**Os valores de DrivetrainSettings são provisórios de simulação, não especificações oficiais da Honda CG 160.** Ainda não há temperatura, desgaste, bateria, tempo de partida, partida no tranco ou danos por giro excessivo. O limitador não impede que a roda arraste mecanicamente o motor acima do corte.

MotorcycleController, KeyboardRiderInput e WheelPoseBinding estão incluídos para a integração, mas **não são adicionados à moto da cena de inspeção**. Ainda faltam escala e dimensões reais, configuração do Rigidbody/colisores/WheelColliders e vínculos mecânicos no jogo. physicalScaleVerified permanece falso até essa calibração. Não marcar essa opção apenas para tentar colocar a moto em movimento.

O adaptador tem assistência de equilíbrio por torque e inclinação aproximada para jogabilidade. Não representa um modelo completo de piloto/giroscópio. As constraints, drivers, estados de luz e corrente do Blender não são transferidos automaticamente pelo FBX neutro.

As câmeras de pilotagem, áudio, painel de velocidade/RPM, sistema elétrico, ligação de todos os comandos e o mapa ainda estão pendentes. A câmera que orbita nesta entrega serve somente à inspeção.

## Controles do adaptador — após integração física

I: ignição; W: acelerador; A/D: direção; Espaço: freio dianteiro; S: freio traseiro; Shift esquerdo: embreagem puxada; E: passada para cima; Q: passada para baixo; N: meia passada para neutro a partir de 1 ou 2. De N, Q seleciona 1 e E seleciona 2. Exige Input Manager legado ou Both e embreagem para as trocas.

Essas teclas ainda não pilotam a moto da cena de inspeção. Não há controle de farol/setas/buzina conectado ao jogo nesta etapa.

## Reprodução no repositório

Na raiz: python3 tools/check_core.py. Se o SDK não estiver disponível no Linux x86-64, executar python3 tools/setup_dotnet.py, que confere SHA-512 do SDK oficial antes de extrair.

Gerar o projeto distribuível: python3 tools/package_unity_project.py. O script preserva um FBX local que tenha sido modificado e não inclui Library, caches ou pastas temporárias no ZIP. O build do jogo ainda não existe.

## Atribuição do modelo

Autor declarado: rafaazx1000, licença CC-BY-4.0. Origem: https://sketchfab.com/3d-models/cg-160-0900747144084e538244f8c504161baa . Modificações: separação de componentes, nomes/hierarquia, materiais demonstrativos e exportação da pose neutra. Preservar atribuição e indicação das modificações. Essa é a licença declarada do modelo, não uma declaração de licença para todo o código.

## Correção da abertura — revisão v2
O erro de criação adicional com Untitled sem salvar foi tratado salvando cenas sem nome automaticamente em Generated/Recuperadas antes da criação da inspeção. Consulte Documentation/CORRECAO_v2.md. A revisão também verifica a câmera, melhora a retomada e mostra os erros de preparação em janela. Validação real no Editor continua pendente.
