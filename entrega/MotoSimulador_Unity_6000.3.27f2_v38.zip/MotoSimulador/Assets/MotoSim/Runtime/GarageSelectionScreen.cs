using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace MotoSim.Unity
{
    /// <summary>Simple responsive bike selector for the MotoSim garage and async loading overlay.</summary>
    public sealed class GarageSelectionScreen : MonoBehaviour
    {
        private enum ScreenMode { MainMenu, Garage, Settings }

        [SerializeField] private GameObject[] displayModels = new GameObject[0];
        [SerializeField] private string[] bikeNames = new string[0];
        [SerializeField] private string[] scenePaths = new string[0];
        [SerializeField] private Texture2D officialLoadingBackground;
        private int selectedIndex;
        private bool loading;
        private float loadProgress;
        private ScreenMode screenMode = ScreenMode.MainMenu;
        private float masterVolume = 1f;
        private int selectedQuality;
        [SerializeField, Min(1f)] private float previewSpinSeconds = 10f;
        private GUIStyle title, heading, body, small, button, card, menuButton, logo, redLogo;

        public void Configure(GameObject[] models, string[] names, string[] scenes, Texture2D loadingBackground)
        {
            displayModels = models ?? new GameObject[0];
            bikeNames = names ?? new string[0];
            scenePaths = scenes ?? new string[0];
            officialLoadingBackground = loadingBackground;
            selectedIndex = Mathf.Clamp(PlayerPrefs.GetInt("MotoSim.GarageSelection", 0), 0, Mathf.Max(0, bikeNames.Length - 1));
            masterVolume = PlayerPrefs.GetFloat("MotoSim.MasterVolume", 1f);
            selectedQuality = Mathf.Clamp(QualitySettings.GetQualityLevel(), 0, Mathf.Max(0, QualitySettings.names.Length - 1));
            ApplySelection();
        }

        private void Start()
        {
            string saved = PlayerPrefs.GetString("MotoSim.SelectedBike", "");
            for (int i = 0; i < bikeNames.Length; i++)
                if (bikeNames[i] == saved) selectedIndex = i;
            masterVolume = PlayerPrefs.GetFloat("MotoSim.MasterVolume", 1f);
            AudioListener.volume = masterVolume;
            selectedQuality = Mathf.Clamp(PlayerPrefs.GetInt("MotoSim.Quality", QualitySettings.GetQualityLevel()),
                0, Mathf.Max(0, QualitySettings.names.Length - 1));
            if (QualitySettings.names.Length > 0) QualitySettings.SetQualityLevel(selectedQuality, true);
            if (PlayerPrefs.GetInt("MotoSim.OpenGarageOnStart", 0) == 1)
            {
                screenMode = ScreenMode.Garage;
                PlayerPrefs.DeleteKey("MotoSim.OpenGarageOnStart");
                PlayerPrefs.Save();
            }
            ApplySelection();
        }

        private void Update()
        {
            if (loading || screenMode != ScreenMode.Garage || selectedIndex < 0 || selectedIndex >= displayModels.Length) return;
            GameObject selected = displayModels[selectedIndex];
            if (selected != null && selected.activeInHierarchy)
                selected.transform.Rotate(Vector3.up, 360f / Mathf.Max(1f, previewSpinSeconds) * Time.deltaTime, Space.World);
        }

        private void ApplySelection()
        {
            for (int i = 0; i < displayModels.Length; i++)
                if (displayModels[i] != null) displayModels[i].SetActive(screenMode == ScreenMode.Garage && i == selectedIndex);
        }

        private void EnsureStyles()
        {
            if (title != null) return;
            title = new GUIStyle(GUI.skin.label) { fontSize = 27, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleLeft, normal = { textColor = Color.white } };
            heading = new GUIStyle(GUI.skin.label) { fontSize = 18, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleLeft, normal = { textColor = Color.white } };
            body = new GUIStyle(GUI.skin.label) { fontSize = 14, alignment = TextAnchor.MiddleLeft, wordWrap = true, normal = { textColor = new Color(.86f, .87f, .9f) } };
            small = new GUIStyle(body) { fontSize = 11, normal = { textColor = new Color(.68f, .7f, .74f) } };
            button = new GUIStyle(GUI.skin.button) { fontSize = 15, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleCenter };
            card = new GUIStyle(GUI.skin.button) { fontSize = 15, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleLeft, padding = new RectOffset(14, 8, 8, 8) };
            menuButton = new GUIStyle(GUI.skin.button) { fontSize = 22, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleLeft, padding = new RectOffset(20, 12, 8, 8) };
            logo = new GUIStyle(GUI.skin.label) { fontSize = 39, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleRight, normal = { textColor = Color.white } };
            redLogo = new GUIStyle(logo) { alignment = TextAnchor.MiddleLeft, normal = { textColor = new Color(.95f, .025f, .035f) } };
        }

        private void OnGUI()
        {
            GUI.matrix = Matrix4x4.identity;
            GUI.color = Color.white;
            GUI.backgroundColor = Color.white;
            EnsureStyles();
            if (loading) { DrawLoading(); GUI.matrix = Matrix4x4.identity; return; }
            float w = Screen.width, h = Screen.height;
            float scale = Mathf.Clamp(Mathf.Min(w / 1440f, h / 900f), .68f, 1.35f);
            GUI.matrix = Matrix4x4.Scale(new Vector3(scale, scale, 1));
            w /= scale; h /= scale;

            if (screenMode == ScreenMode.MainMenu)
            {
                DrawMainMenu(w, h);
                GUI.matrix = Matrix4x4.identity;
                return;
            }
            if (screenMode == ScreenMode.Settings)
            {
                DrawSettings(w, h);
                GUI.matrix = Matrix4x4.identity;
                return;
            }

            Rect top = new Rect(0, 0, w, 82);
            Fill(top, new Color(.025f, .03f, .045f, .92f));
            if (GUI.Button(new Rect(18, 16, 142, 50), "‹  VOLTAR", button)) OpenMainMenu();
            GUI.Label(new Rect(178, 13, 220, 52), "GARAGEM", title);
            GUI.Label(new Rect(w * .39f, 15, 330, 50), "MOTOSIMULADOR", heading);
            GUI.Label(new Rect(w - 280, 18, 250, 45), "JOGADOR   •   NÍVEL 1", body);

            float leftX = 24, leftW = w * .225f, topY = 118;
            Fill(new Rect(leftX, topY, leftW, h * .70f), new Color(.025f, .03f, .04f, .91f));
            GUI.Label(new Rect(leftX + 16, topY + 12, leftW - 28, 32), "ESCOLHA SUA MOTO", heading);
            string[] types = { "Honda CG 160", "Honda CB 300 Twister", "Honda Africa Twin" };
            int count = Mathf.Min(bikeNames.Length, scenePaths.Length);
            float cardH = Mathf.Min(78, (h * .62f) / Mathf.Max(1, count));
            for (int i = 0; i < count; i++)
            {
                float y = topY + 56 + i * (cardH + 10);
                GUI.backgroundColor = i == selectedIndex ? new Color(.73f, .025f, .035f, 1) : new Color(.12f, .13f, .15f, .96f);
                string displayName = i < types.Length ? types[i] : bikeNames[i];
                if (GUI.Button(new Rect(leftX + 12, y, leftW - 24, cardH), displayName + "\nDISPONÍVEL", card))
                { selectedIndex = i; PlayerPrefs.SetInt("MotoSim.GarageSelection", i); ApplySelection(); }
            }
            GUI.backgroundColor = Color.white;
            GUI.Label(new Rect(leftX + 16, topY + h * .64f, leftW - 32, 34), "A moto selecionada aparece no centro.", small);

            float rightW = w * .225f, rightX = w - rightW - 24;
            Rect info = new Rect(rightX, topY + 48, rightW, h * .55f);
            Fill(info, new Color(.025f, .03f, .04f, .91f));
            string name = selectedIndex < bikeNames.Length ? bikeNames[selectedIndex] : "Moto";
            GUI.Label(new Rect(rightX + 20, info.y + 18, rightW - 40, 50), name, title);
            GUI.Label(new Rect(rightX + 20, info.y + 74, rightW - 40, 36), "HONDA  •  MODELO 3D", body);
            Fill(new Rect(rightX + 18, info.y + 120, rightW - 36, 2), new Color(.75f, .025f, .04f));
            GUI.Label(new Rect(rightX + 20, info.y + 140, rightW - 40, 80), "Modelo incluído no MotoSimulador.\nEscolha Testar para pilotar no circuito.", body);
            GUI.Label(new Rect(rightX + 20, info.y + 233, rightW - 40, 34), "OPÇÃO DE PILOTAGEM", small);
            GUI.Label(new Rect(rightX + 20, info.y + 265, rightW - 40, 40), "Treino de moto", heading);

            float bottomY = h - 92;
            GUI.backgroundColor = new Color(.75f, .025f, .04f, 1);
            if (GUI.Button(new Rect(w * .34f, bottomY, w * .2f, 62), "✓   SELECIONAR", button))
            { SaveSelection(); }
            GUI.backgroundColor = new Color(.08f, .09f, .11f, 1);
            if (GUI.Button(new Rect(w * .56f, bottomY, w * .2f, 62), "TESTAR  →", button))
            { SaveSelection(); StartCoroutine(LoadSelectedScene()); }
            GUI.backgroundColor = Color.white;
            GUI.Label(new Rect(24, h - 31, 300, 24), "MOTOS DISPONÍVEIS: " + count, small);
            GUI.matrix = Matrix4x4.identity;
        }

        private void DrawMainMenu(float width, float height)
        {
            Fill(new Rect(0, 0, width, height), new Color(.015f, .018f, .025f, .19f));
            Fill(new Rect(0, 0, width, 86), new Color(.015f, .018f, .025f, .72f));

            float logoX = width * .39f;
            GUI.Label(new Rect(logoX, 118, width * .28f, 65), "MOTO", logo);
            GUI.Label(new Rect(logoX + width * .28f, 118, width * .32f, 65), "SIMULADOR", redLogo);
            Fill(new Rect(logoX + 8, 187, width * .58f, 5), new Color(.92f, .025f, .035f));

            Rect profile = new Rect(width - 398, 16, 378, 58);
            Fill(profile, new Color(.015f, .018f, .022f, .91f));
            Stroke(profile, new Color(.43f, .45f, .48f, .9f), 2);
            GUI.Label(new Rect(profile.x + 18, profile.y + 7, 220, 24), "●  Jogador", heading);
            GUI.Label(new Rect(profile.x + 18, profile.y + 31, 115, 20), "Nível 1", small);
            Fill(new Rect(profile.x + 122, profile.y + 36, 95, 9), new Color(.18f, .19f, .2f));
            Fill(new Rect(profile.x + 122, profile.y + 36, 65, 9), new Color(.92f, .025f, .035f));
            GUI.Label(new Rect(profile.x + 232, profile.y + 12, 128, 34), "R$ 0,00", heading);

            float left = 24, menuWidth = Mathf.Clamp(width * .24f, 305, 370);
            float buttonHeight = Mathf.Clamp(height * .078f, 60, 74);
            float gap = 14;
            float y = height * .28f;
            DrawMenuButton(new Rect(left, y, menuWidth, buttonHeight), "▶   CONTINUAR", true,
                () => { if (PlayerPrefs.GetInt("MotoSim.HasProgress", 0) == 1) StartCoroutine(LoadSelectedScene()); else OpenGarage(); });
            y += buttonHeight + gap;
            DrawMenuButton(new Rect(left, y, menuWidth, buttonHeight), "◉   NOVO JOGO", false, StartNewGame);
            y += buttonHeight + gap;
            DrawMenuButton(new Rect(left, y, menuWidth, buttonHeight), "⌂   GARAGEM", false, OpenGarage);
            y += buttonHeight + gap;
            DrawMenuButton(new Rect(left, y, menuWidth, buttonHeight), "⚙   CONFIGURAÇÕES", false,
                () => screenMode = ScreenMode.Settings);
            y += buttonHeight + gap;
            DrawMenuButton(new Rect(left, y, menuWidth, buttonHeight), "⇥   SAIR", false, Application.Quit);

            GUI.Label(new Rect(22, height - 42, 160, 24), "v1.0.0", small);
            GUI.Label(new Rect(width - 180, height - 44, 158, 28), "BRASIL  ▾", small);
        }

        private void DrawSettings(float width, float height)
        {
            Fill(new Rect(0, 0, width, height), new Color(.01f, .012f, .018f, .64f));
            Rect panel = new Rect(width * .28f, height * .18f, width * .48f, height * .64f);
            Fill(panel, new Color(.025f, .03f, .04f, .97f));
            Stroke(panel, new Color(.75f, .025f, .04f), 2);
            GUI.Label(new Rect(panel.x + 28, panel.y + 20, panel.width - 56, 48), "CONFIGURAÇÕES", title);
            GUI.Label(new Rect(panel.x + 32, panel.y + 105, 180, 30), "Volume geral", body);
            float volume = GUI.HorizontalSlider(new Rect(panel.x + 220, panel.y + 112, panel.width - 265, 24), masterVolume, 0, 1);
            if (!Mathf.Approximately(volume, masterVolume))
            {
                masterVolume = volume;
                AudioListener.volume = masterVolume;
                PlayerPrefs.SetFloat("MotoSim.MasterVolume", masterVolume);
            }
            GUI.Label(new Rect(panel.x + 32, panel.y + 180, 180, 30), "Tela cheia", body);
            bool fullscreen = GUI.Toggle(new Rect(panel.x + 220, panel.y + 180, 160, 30), Screen.fullScreen, "Ativada");
            if (fullscreen != Screen.fullScreen) Screen.fullScreen = fullscreen;
            GUI.Label(new Rect(panel.x + 32, panel.y + 250, 180, 30), "Qualidade", body);
            string[] qualityNames = QualitySettings.names;
            if (qualityNames.Length > 0)
            {
                int quality = GUI.SelectionGrid(new Rect(panel.x + 220, panel.y + 244, panel.width - 260, 38),
                    selectedQuality, qualityNames, Mathf.Min(qualityNames.Length, 3));
                if (quality != selectedQuality)
                {
                    selectedQuality = quality;
                    QualitySettings.SetQualityLevel(selectedQuality, true);
                    PlayerPrefs.SetInt("MotoSim.Quality", selectedQuality);
                }
            }
            GUI.backgroundColor = new Color(.75f, .025f, .04f);
            if (GUI.Button(new Rect(panel.x + 32, panel.y + panel.height - 76, 190, 50), "SALVAR E VOLTAR", button))
            {
                PlayerPrefs.Save();
                OpenMainMenu();
            }
            GUI.backgroundColor = Color.white;
        }

        private void DrawMenuButton(Rect rect, string label, bool highlighted, System.Action action)
        {
            Color accent = highlighted ? new Color(.88f, .025f, .035f) : new Color(.35f, .37f, .4f);
            Fill(rect, accent);
            Fill(new Rect(rect.x + 3, rect.y + 3, rect.width - 6, rect.height - 6),
                highlighted ? new Color(.12f, .018f, .022f, .97f) : new Color(.025f, .03f, .04f, .94f));
            GUI.backgroundColor = highlighted ? new Color(.72f, .018f, .025f, .98f) : new Color(.06f, .07f, .085f, .98f);
            if (GUI.Button(new Rect(rect.x + 4, rect.y + 4, rect.width - 8, rect.height - 8), label, menuButton)) action();
            GUI.backgroundColor = Color.white;
        }

        private void StartNewGame()
        {
            selectedIndex = 0;
            PlayerPrefs.SetInt("MotoSim.GarageSelection", 0);
            PlayerPrefs.SetInt("MotoSim.HasProgress", 0);
            PlayerPrefs.Save();
            OpenGarage();
        }

        private void OpenGarage()
        {
            screenMode = ScreenMode.Garage;
            ApplySelection();
        }

        private void OpenMainMenu()
        {
            screenMode = ScreenMode.MainMenu;
            ApplySelection();
        }

        private static void Stroke(Rect rect, Color color, float thickness)
        {
            Fill(new Rect(rect.x, rect.y, rect.width, thickness), color);
            Fill(new Rect(rect.x, rect.yMax - thickness, rect.width, thickness), color);
            Fill(new Rect(rect.x, rect.y, thickness, rect.height), color);
            Fill(new Rect(rect.xMax - thickness, rect.y, thickness, rect.height), color);
        }

        private void SaveSelection()
        {
            if (selectedIndex >= 0 && selectedIndex < bikeNames.Length)
            {
                PlayerPrefs.SetString("MotoSim.SelectedBike", bikeNames[selectedIndex]);
                PlayerPrefs.SetInt("MotoSim.GarageSelection", selectedIndex);
            }
            PlayerPrefs.Save();
        }

        private IEnumerator LoadSelectedScene()
        {
            if (selectedIndex < 0 || selectedIndex >= scenePaths.Length) yield break;
            SaveSelection();
            PlayerPrefs.SetInt("MotoSim.HasProgress", 1);
            PlayerPrefs.Save();
            loading = true; loadProgress = 0;
            AsyncOperation operation = SceneManager.LoadSceneAsync(scenePaths[selectedIndex]);
            if (operation == null) { loading = false; yield break; }
            operation.allowSceneActivation = false;
            while (operation.progress < .9f)
            { loadProgress = Mathf.Clamp01(operation.progress / .9f); yield return null; }
            loadProgress = 1; yield return null; operation.allowSceneActivation = true;
        }

        private void DrawLoading()
        {
            EnsureStyles();
            Rect screen = new Rect(0, 0, Screen.width, Screen.height);
            if (officialLoadingBackground != null)
                GUI.DrawTexture(screen, officialLoadingBackground, ScaleMode.ScaleAndCrop, false);
            else Fill(screen, new Color(.035f, .035f, .045f, 1));
            GUIStyle center = new GUIStyle(title)
            { alignment = TextAnchor.MiddleCenter, fontSize = Mathf.Clamp(Screen.height / 28, 20, 34), fontStyle = FontStyle.Bold };
            GUIStyle tip = new GUIStyle(body)
            { alignment = TextAnchor.MiddleLeft, fontSize = Mathf.Clamp(Screen.height / 62, 13, 22), fontStyle = FontStyle.Italic };
            float labelY = Screen.height * .735f;
            GUI.Label(new Rect(0, labelY, Screen.width, Screen.height * .055f), "C A R R E G A N D O . . .", center);
            Rect bar = new Rect(Screen.width * .24f, Screen.height * .805f, Screen.width * .52f, Mathf.Clamp(Screen.height * .037f, 20, 36));
            Fill(bar, new Color(.025f, .025f, .03f, .96f));
            Fill(new Rect(bar.x + 4, bar.y + 4, Mathf.Max(0, (bar.width - 8) * Mathf.Clamp01(loadProgress)), bar.height - 8), new Color(.91f, .025f, .035f));
            Fill(new Rect(bar.x, bar.y, bar.width, 2), new Color(.7f, .7f, .72f, .85f));
            GUI.Label(new Rect(Screen.width * .285f, bar.y + bar.height + 14, Screen.width * .43f, Screen.height * .075f),
                "DICA: MANTENHA O EQUILÍBRIO E A VELOCIDADE CONSTANTE\nNOS PERCURSOS DE PROVA.", tip);
        }

        private static void Fill(Rect rect, Color color)
        {
            Color old = GUI.color; GUI.color = color; GUI.DrawTexture(rect, Texture2D.whiteTexture); GUI.color = old;
        }
    }
}
