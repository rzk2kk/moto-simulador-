using System.Collections.Generic;
using System.Linq;
using System;
using UnityEngine;

namespace MotoSim.Unity
{
    /// <summary>Functional headlamp, brake lamp, and alternating turn signals.</summary>
    public sealed class MotorcycleLighting : MonoBehaviour
    {
        [SerializeField] private MotorcycleController motorcycle;
        [SerializeField] private Renderer headlamp;
        [SerializeField] private Renderer tailLamp;
        [SerializeField] private Renderer[] leftSignals = new Renderer[0];
        [SerializeField] private Renderer[] rightSignals = new Renderer[0];
        [SerializeField] private Transform steering;
        [SerializeField] private bool headlampOn = true;
        [SerializeField] private bool leftSignalOn;
        [SerializeField] private bool rightSignalOn;
        [SerializeField] private bool hazardsOn;
        private readonly Dictionary<Renderer, Material[]> materials = new Dictionary<Renderer, Material[]>();
        private readonly Dictionary<Renderer, float> lastEmission = new Dictionary<Renderer, float>();
        private Light headlampBeam;
        private Light brakeGlow;

        public bool HeadlampOn => headlampOn;
        public bool LeftSignalOn => leftSignalOn || hazardsOn;
        public bool RightSignalOn => rightSignalOn || hazardsOn;
        public bool HazardsOn => hazardsOn;

        public void Configure(GameObject model, Transform steeringPivot, MotorcycleController vehicle)
        {
            Renderer[] leftSignals = new[] { FindRenderer(model, "Lente_Seta_Dianteira_Esquerda"),
                FindRenderer(model, "Lente_Seta_Traseira_Esquerda"), FindRenderer(model, "Lampada_Seta_Dianteira_Esquerda"),
                FindRenderer(model, "Lampada_Seta_Traseira_Esquerda") }.Where(r => r != null).ToArray();
            Renderer[] rightSignals = new[] { FindRenderer(model, "Lente_Seta_Dianteira_Direita"),
                FindRenderer(model, "Lente_Seta_Traseira_Direita"), FindRenderer(model, "Lampada_Seta_Dianteira_Direita"),
                FindRenderer(model, "Lampada_Seta_Traseira_Direita") }.Where(r => r != null).ToArray();
            Configure(model, steeringPivot, vehicle, FindRenderer(model, "Lente_Farol"),
                FindRenderer(model, "Lente_Lanterna_Traseira"), leftSignals, rightSignals);
        }

        public void Configure(GameObject model, Transform steeringPivot, MotorcycleController vehicle,
            Renderer headlampRenderer, Renderer tailLampRenderer, Renderer[] leftSignalRenderers,
            Renderer[] rightSignalRenderers)
        {
            motorcycle = vehicle;
            steering = steeringPivot;
            headlamp = headlampRenderer;
            tailLamp = tailLampRenderer;
            leftSignals = (leftSignalRenderers ?? new Renderer[0]).Where(r => r != null).Distinct().ToArray();
            rightSignals = (rightSignalRenderers ?? new Renderer[0]).Where(r => r != null).Distinct().ToArray();
            if (headlamp == null || tailLamp == null || leftSignals.Length == 0 || rightSignals.Length == 0)
                throw new InvalidOperationException("Não foi possível vincular farol, lanterna ou setas ao modelo.");
            CacheMaterials();
            CreateHeadlampBeam(model != null ? model.transform : transform);
            CreateBrakeGlow(model.transform);
        }

        private void Awake()
        {
            CacheMaterials();
            if (headlampBeam == null)
                headlampBeam = GetComponentsInChildren<Light>(true).FirstOrDefault(l => l.name == "Feixe_Farol_Funcional");
            if (brakeGlow == null)
                brakeGlow = GetComponentsInChildren<Light>(true).FirstOrDefault(l => l.name == "Brilho_Freio_Traseiro");
            if (steering != null && headlamp != null && headlampBeam == null) CreateHeadlampBeam(transform);
        }

        public void ToggleHeadlamp() => headlampOn = !headlampOn;
        public void ToggleLeftSignal()
        {
            leftSignalOn = !leftSignalOn; rightSignalOn = false; hazardsOn = false;
        }
        public void ToggleRightSignal()
        {
            rightSignalOn = !rightSignalOn; leftSignalOn = false; hazardsOn = false;
        }
        public void ToggleHazards()
        {
            hazardsOn = !hazardsOn; leftSignalOn = false; rightSignalOn = false;
        }

        private void Update()
        {
            float blink = Mathf.Repeat(Time.time, .8f) < .4f ? 1 : 0;
            bool braking = motorcycle != null &&
                (motorcycle.FrontBrakeInput > .02f || motorcycle.RearBrakeInput > .02f);
            bool engineOn = motorcycle != null && motorcycle.Telemetry.EngineRunning;
            Apply(headlamp, new Color(1f, .78f, .48f), headlampOn ? 8f : 0);
            Apply(tailLamp, new Color(1f, .015f, .008f), braking ? 12f : engineOn ? 1.2f : 0);
            if (brakeGlow != null)
            {
                brakeGlow.enabled = braking;
                brakeGlow.intensity = braking ? 3.5f : 0;
            }
            ApplyGroup(leftSignals, new Color(1f, .25f, .015f), LeftSignalOn ? blink * 6f : 0);
            ApplyGroup(rightSignals, new Color(1f, .25f, .015f), RightSignalOn ? blink * 6f : 0);
            if (headlampBeam != null) headlampBeam.enabled = headlampOn;
        }

        private void CacheMaterials()
        {
            foreach (Renderer renderer in AllLamps())
            {
                if (renderer == null || materials.ContainsKey(renderer)) continue;
                Material[] copies = renderer.materials;
                foreach (Material material in copies)
                    if (material != null && material.HasProperty("_EmissionColor")) material.EnableKeyword("_EMISSION");
                materials.Add(renderer, copies);
                lastEmission.Add(renderer, -1);
            }
        }

        private IEnumerable<Renderer> AllLamps()
        {
            if (headlamp != null) yield return headlamp;
            if (tailLamp != null) yield return tailLamp;
            if (leftSignals != null) foreach (Renderer r in leftSignals) if (r != null) yield return r;
            if (rightSignals != null) foreach (Renderer r in rightSignals) if (r != null) yield return r;
        }

        private void ApplyGroup(Renderer[] group, Color color, float intensity)
        {
            if (group == null) return;
            foreach (Renderer renderer in group) Apply(renderer, color, intensity);
        }

        private void Apply(Renderer renderer, Color color, float intensity)
        {
            if (renderer == null || !materials.TryGetValue(renderer, out Material[] copies)) return;
            if (lastEmission[renderer] >= 0 && Mathf.Abs(lastEmission[renderer] - intensity) < .01f) return;
            foreach (Material material in copies)
                if (material != null && material.HasProperty("_EmissionColor"))
                    material.SetColor("_EmissionColor", color * intensity);
            lastEmission[renderer] = intensity;
        }

        private void CreateHeadlampBeam(Transform model)
        {
            if (headlamp == null || model == null || headlampBeam != null) return;
            var beamObject = new GameObject("Feixe_Farol_Funcional");
            beamObject.transform.SetParent(steering != null ? steering : model, true);
            beamObject.transform.position = headlamp.bounds.center + model.forward * .12f + model.up * .035f;
            // The mesh faces +Z. Pitch the beam down so it lights the road ahead,
            // rather than projecting a bright stripe into the sky.
            Vector3 aim = (model.forward - model.up * .18f).normalized;
            beamObject.transform.rotation = Quaternion.LookRotation(aim, model.up);
            headlampBeam = beamObject.AddComponent<Light>();
            headlampBeam.type = LightType.Spot;
            headlampBeam.color = new Color(1f, .82f, .62f);
            headlampBeam.intensity = 900f;
            headlampBeam.range = 42;
            headlampBeam.spotAngle = 48;
            headlampBeam.shadows = LightShadows.None;
        }

        private void CreateBrakeGlow(Transform model)
        {
            if (tailLamp == null || brakeGlow != null) return;
            var glow = new GameObject("Brilho_Freio_Traseiro");
            glow.transform.SetParent(tailLamp.transform, true);
            glow.transform.position = tailLamp.bounds.center;
            brakeGlow = glow.AddComponent<Light>();
            brakeGlow.type = LightType.Point;
            brakeGlow.color = new Color(1f, .015f, .008f);
            brakeGlow.range = 2.4f;
            brakeGlow.intensity = 0;
            brakeGlow.shadows = LightShadows.None;
            brakeGlow.enabled = false;
        }

        private static Renderer FindRenderer(GameObject model, string name) =>
            model.GetComponentsInChildren<Renderer>(true).FirstOrDefault(r => r.name == name);
    }
}
