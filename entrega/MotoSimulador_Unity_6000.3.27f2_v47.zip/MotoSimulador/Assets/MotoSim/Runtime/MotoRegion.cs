using UnityEngine;

namespace MotoSim.Unity
{
    /// <summary>Saved locale for menus, lessons and spoken-guide content.</summary>
    public static class MotoRegion
    {
        private const string Key = "MotoSim.Region";
        public static int Current
        {
            get => Mathf.Clamp(PlayerPrefs.GetInt(Key, 0), 0, 2);
            set { PlayerPrefs.SetInt(Key, Mathf.Clamp(value, 0, 2)); PlayerPrefs.Save(); }
        }
        public static string Label => Current == 1 ? "ENGLISH" : Current == 2 ? "ESPAÑOL" : "BRASIL";
        public static string T(string pt, string en, string es) => Current == 1 ? en : Current == 2 ? es : pt;
    }
}
