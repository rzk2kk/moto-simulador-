using UnityEngine;
using UnityEngine.SceneManagement;

namespace MotoSim.Unity
{
    /// <summary>Ordered full-course check with fall, speed and obstacle penalties.</summary>
    public sealed class PracticalRidingExam : MonoBehaviour
    {
        private static readonly Vector3[] Route = {
            new Vector3(0, 0, 45), new Vector3(0, 0, 88),
            new Vector3(0, 0, 135), new Vector3(0, 0, 190),
            new Vector3(8, 0, 235), new Vector3(56, 0, 245)
        };
        private static readonly Vector3 TrackOffset = new Vector3(1200f, 0f, 0f);
        [SerializeField] private MotorcycleController motorcycle;
        private int stage;
        private bool active, failed, complete;
        private GameObject marker;
        private float excessiveSpeedTime;
        private float offRoadTime;
        private GUIStyle labelStyle;

        public void Configure(MotorcycleController vehicle) => motorcycle = vehicle;

        private void Start()
        {
            active = SceneManager.GetActiveScene().path.EndsWith("Autoescola_ProvaPratica.unity") &&
                PlayerPrefs.GetInt("MotoSim.Career.PracticalActive", 0) == 1 &&
                PlayerPrefs.GetInt("MotoSim.Career.TheoryPassed", 0) == 1;
            if (active) CreateMarker();
        }

        private void Update()
        {
            if (!active || failed || complete || motorcycle == null) return;
            if (Vector3.Dot(motorcycle.transform.up, Vector3.up) < .45f) { Fail(); return; }
            excessiveSpeedTime = motorcycle.SpeedKph > 45f ? excessiveSpeedTime + Time.deltaTime : 0;
            if (excessiveSpeedTime > 2f) { Fail(); return; }
            offRoadTime = DistanceFromCourse(motorcycle.transform.position) > 14f ? offRoadTime + Time.deltaTime : 0f;
            if (offRoadTime > 3f) { Fail(); return; }
            Vector3 offset = motorcycle.transform.position - (Route[stage] + TrackOffset);
            offset.y = 0;
            if (offset.sqrMagnitude > 14f * 14f) return;
            stage++;
            if (marker != null) Destroy(marker);
            if (stage == Route.Length)
            {
                complete = true;
                PlayerPrefs.SetInt("MotoSim.Career.PracticalPassed", 1);
                PlayerPrefs.SetInt("MotoSim.Career.PracticalActive", 0);
                PlayerPrefs.Save();
                MotoCareerProgress.AddCredits(5000);
                MotoMissionBoard.SyncMilestones();
                MotoCareerSaveSlots.SaveActive();
            }
            else CreateMarker();
        }

        private void OnCollisionEnter(Collision collision)
        {
            if (!active || failed || complete) return;
            string part = collision.collider.name;
            if (part.StartsWith("Cone_") || part.StartsWith("Balizador_") || part.StartsWith("Marco_Oito_")) Fail();
        }

        private static float DistanceFromCourse(Vector3 position)
        {
            Vector3 previous = TrackOffset + new Vector3(0f, 0f, -5f);
            float nearest = float.MaxValue;
            foreach (Vector3 checkpoint in Route)
            {
                Vector3 next = checkpoint + TrackOffset;
                Vector3 direction = next - previous;
                float t = Mathf.Clamp01(Vector3.Dot(position - previous, direction) / direction.sqrMagnitude);
                Vector3 projection = previous + direction * t;
                nearest = Mathf.Min(nearest, Vector3.ProjectOnPlane(position - projection, Vector3.up).magnitude);
                previous = next;
            }
            return nearest;
        }

        private void Fail() { failed = true; if (marker != null) marker.SetActive(false); }

        private void CreateMarker()
        {
            marker = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            marker.name = "Proxima_Etapa_Pratico_" + (stage + 1);
            marker.transform.position = Route[stage] + TrackOffset + Vector3.up * 2.5f;
            marker.transform.localScale = Vector3.one * .8f;
            Collider collider = marker.GetComponent<Collider>();
            if (collider != null) Destroy(collider);
            Shader shader = Shader.Find("Universal Render Pipeline/Unlit") ?? Shader.Find("Unlit/Color");
            if (shader != null)
            {
                var material = new Material(shader) { color = new Color(1f, .72f, .04f) };
                marker.GetComponent<Renderer>().material = material;
            }
        }

        private void OnGUI()
        {
            if (!active) return;
            if (labelStyle == null) labelStyle = new GUIStyle(GUI.skin.label) {
                fontSize = 17, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleCenter,
                normal = { textColor = Color.white } };
            Rect panel = new Rect(Screen.width * .5f - 240, 52, 480, failed || complete ? 112 : 70);
            GUI.Box(panel, GUIContent.none);
            string message = failed ? MotoRegion.T("PROVA PRÁTICA REPROVADA", "PRACTICAL TEST FAILED", "PRUEBA PRÁCTICA REPROBADA") :
                complete ? MotoRegion.T("PROVA PRÁTICA APROVADA · CIDADE EM BREVE", "PRACTICAL TEST PASSED · CITY COMING SOON", "PRUEBA PRÁCTICA APROBADA · CIUDAD PRÓXIMAMENTE") :
                MotoRegion.T("PROVA PRÁTICA  ·  ETAPA ", "PRACTICAL TEST  ·  STAGE ", "PRUEBA PRÁCTICA  ·  ETAPA ") + (stage + 1).ToString() + "/" + Route.Length;
            GUI.Label(new Rect(panel.x + 8, panel.y + 6, panel.width - 16, 32), message, labelStyle);
            if (!failed && !complete)
                GUI.Label(new Rect(panel.x + 8, panel.y + 37, panel.width - 16, 23),
                    MotoRegion.T("Siga o marcador amarelo. Até 45 km/h, sem derrubar cones.", "Follow the yellow marker. Stay under 45 km/h and avoid cones.", "Sigue el marcador amarillo. Hasta 45 km/h, sin tocar conos."), labelStyle);
            if (failed && GUI.Button(new Rect(panel.x + 95, panel.y + 49, 290, 48),
                MotoRegion.T("REINICIAR PROVA", "RETRY TEST", "REPETIR PRUEBA")))
            {
                stage = 0; failed = false; excessiveSpeedTime = 0; offRoadTime = 0;
                motorcycle.ResetToStart(); CreateMarker();
            }
        }
    }
}
