using System.Collections;
using System.Collections.Generic;
using System;
using MotoSim.Core;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace MotoSim.Unity
{
    /// <summary>Simple responsive bike selector for the MotoSim garage and async loading overlay.</summary>
    public sealed class GarageSelectionScreen : MonoBehaviour
    {
        private enum ScreenMode { MainMenu, Garage, Settings, SaveSlots, Missions, SchoolIntro, Theory, TheoryFeedback, TheoryResult, PracticalIntro }

        [SerializeField] private GameObject[] displayModels = new GameObject[0];
        [SerializeField] private string[] bikeNames = new string[0];
        [SerializeField] private string[] scenePaths = new string[0];
        [SerializeField] private Texture2D officialLoadingBackground;
        [SerializeField] private Texture2D brandLogo;
        [SerializeField] private string practicalScenePath;
        private int selectedIndex;
        private int selectedPaint;
        private int introStep, questionIndex, correctAnswers;
        private int selectedAnswer;
        private int lessonCheckChoice = -1;
        private bool lessonCheckComplete;
        private bool theoryPassed;
        private float introStarted, theoryStarted;
        private AudioSource storyVoice;
        private AudioClip lessonClip;
        private SchoolStoryStage storyStage;
        private bool loading;
        private float loadProgress;
        private ScreenMode screenMode = ScreenMode.MainMenu;
        private ScreenMode slotsReturnMode = ScreenMode.MainMenu;
        private ScreenMode missionsReturnMode = ScreenMode.MainMenu;
        private bool slotsForNewGame;
        private int deleteConfirmationSlot = -1;
        private Vector2 missionsScroll;
        private int missionNoticeVersion;
        private float masterVolume = 1f;
        private int selectedQuality;
        private string noticeText;
        private float noticeUntil;
        private readonly Dictionary<int, float> buttonHover = new Dictionary<int, float>();
        private Texture2D roundedMask;
        [SerializeField, Min(1f)] private float previewSpinSeconds = 10f;
        private bool previewSpinning = true;
        private GUIStyle title, heading, body, small, button, card, menuButton, logo, redLogo;
        private GUIStyle storyBody;

        public void Configure(GameObject[] models, string[] names, string[] scenes, Texture2D loadingBackground, Texture2D logoImage, string practiceScene)
        {
            displayModels = models ?? new GameObject[0];
            bikeNames = names ?? new string[0];
            scenePaths = scenes ?? new string[0];
            officialLoadingBackground = loadingBackground;
            brandLogo = logoImage;
            practicalScenePath = practiceScene;
            MotoCareerProgress.EnsureInitialized();
            selectedIndex = Mathf.Clamp(PlayerPrefs.GetInt("MotoSim.GarageSelection", 0), 0, Mathf.Max(0, bikeNames.Length - 1));
            selectedPaint = MotoCareerProgress.PaintIndex(selectedIndex);
            masterVolume = PlayerPrefs.GetFloat("MotoSim.MasterVolume", 1f);
            selectedQuality = Mathf.Clamp(QualitySettings.GetQualityLevel(), 0, Mathf.Max(0, QualitySettings.names.Length - 1));
            ApplySelection();
        }

        private void Start()
        {
            MotoCareerSaveSlots.EnsureInitialized();
            MotoMissionBoard.SyncMilestones();
            missionNoticeVersion = MotoMissionBoard.NotificationVersion;
            storyStage = FindFirstObjectByType<SchoolStoryStage>();
            // A test ride never carries ownership or career rewards into the garage.
            PlayerPrefs.DeleteKey("MotoSim.TestRidePreview");
            storyVoice = gameObject.AddComponent<AudioSource>();
            storyVoice.playOnAwake = false;
            storyVoice.spatialBlend = 0f;
            MotoCareerProgress.EnsureInitialized();
            selectedIndex = Mathf.Clamp(PlayerPrefs.GetInt("MotoSim.GarageSelection", MotoCareerProgress.StarterBikeIndex),
                0, Mathf.Max(0, bikeNames.Length - 1));
            string saved = PlayerPrefs.GetString("MotoSim.SelectedBike", "");
            for (int i = 0; i < bikeNames.Length; i++)
                if (bikeNames[i] == saved) selectedIndex = i;
            masterVolume = PlayerPrefs.GetFloat("MotoSim.MasterVolume", 1f);
            AudioListener.volume = masterVolume;
            selectedQuality = Mathf.Clamp(PlayerPrefs.GetInt("MotoSim.Quality", QualitySettings.GetQualityLevel()),
                0, Mathf.Max(0, QualitySettings.names.Length - 1));
            if (QualitySettings.names.Length > 0) QualitySettings.SetQualityLevel(selectedQuality, true);
            selectedPaint = MotoCareerProgress.PaintIndex(selectedIndex);
            if (PlayerPrefs.GetInt("MotoSim.OpenGarageOnStart", 0) == 1)
            {
                screenMode = ScreenMode.Garage;
                PlayerPrefs.DeleteKey("MotoSim.OpenGarageOnStart");
                PlayerPrefs.Save();
            }
            ApplySelection();
        }

        private void Update()
        {
            if (loading) return;
            if (storyStage != null)
            {
                storyStage.SetPresentation(screenMode == ScreenMode.SchoolIntro, introStep);
                storyStage.SetSpeaking(storyVoice != null && storyVoice.isPlaying);
            }
            if (missionNoticeVersion != MotoMissionBoard.NotificationVersion)
            {
                missionNoticeVersion = MotoMissionBoard.NotificationVersion;
                int completed = MotoMissionBoard.LastCompletedIndex;
                if (completed >= 0)
                {
                    MissionDefinition mission = MotoMissionBoard.Mission(completed);
                    ShowNotice(MotoRegion.T(mission.TitlePt, mission.TitleEn, mission.TitleEs) +
                        "  + " + MotoCareerProgress.FormatCredits(mission.RewardCredits));
                }
            }
            if (screenMode == ScreenMode.Garage && selectedIndex >= 0 && selectedIndex < displayModels.Length)
            {
                GameObject selected = displayModels[selectedIndex];
                if (previewSpinning && selected != null && selected.activeInHierarchy)
                    selected.transform.Rotate(Vector3.up, 360f / Mathf.Max(1f, previewSpinSeconds) * Time.deltaTime, Space.World);
            }
            if (!string.IsNullOrEmpty(noticeText) && Time.unscaledTime >= noticeUntil) noticeText = null;
        }

        private void ApplySelection()
        {
            for (int i = 0; i < displayModels.Length; i++)
                if (displayModels[i] != null)
                {
                    displayModels[i].SetActive(screenMode == ScreenMode.Garage && i == selectedIndex);
                    MotorcyclePaint.Apply(displayModels[i], i);
                }
        }

        private void EnsureStyles()
        {
            if (title != null) return;
            title = new GUIStyle(GUI.skin.label) { fontSize = 27, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleLeft, normal = { textColor = Color.white } };
            heading = new GUIStyle(GUI.skin.label) { fontSize = 18, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleLeft, normal = { textColor = Color.white } };
            body = new GUIStyle(GUI.skin.label) { fontSize = 14, alignment = TextAnchor.MiddleLeft, wordWrap = true, normal = { textColor = new Color(.9f, .92f, .95f) } };
            storyBody = new GUIStyle(body) { fontSize = 19, alignment = TextAnchor.UpperLeft, richText = false };
            small = new GUIStyle(body) { fontSize = 11, normal = { textColor = new Color(.76f, .79f, .84f) } };
            button = new GUIStyle(GUI.skin.button) { fontSize = 15, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleCenter };
            card = new GUIStyle(GUI.skin.button) { fontSize = 14, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleLeft, padding = new RectOffset(15, 10, 8, 8), wordWrap = true };
            menuButton = new GUIStyle(GUI.skin.button) { fontSize = 20, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleLeft, padding = new RectOffset(20, 12, 8, 8) };
            logo = new GUIStyle(GUI.skin.label) { fontSize = 39, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleRight, normal = { textColor = Color.white } };
            redLogo = new GUIStyle(logo) { alignment = TextAnchor.MiddleLeft, normal = { textColor = new Color(.95f, .025f, .035f) } };
            foreach (GUIStyle style in new[] { button, card, menuButton })
            {
                style.normal.background = null; style.hover.background = null;
                style.active.background = null; style.focused.background = null;
                style.normal.textColor = Color.white; style.hover.textColor = Color.white;
                style.active.textColor = Color.white;
            }
        }

        private void OnGUI()
        {
            GUI.matrix = Matrix4x4.identity;
            GUI.color = Color.white;
            GUI.backgroundColor = Color.white;
            EnsureStyles();
            if (loading) { DrawLoading(); GUI.matrix = Matrix4x4.identity; return; }
            float w = Screen.width, h = Screen.height;
            float scale = Mathf.Clamp(Mathf.Min(w / 1440f, h / 900f), .68f, 1.35f);
            GUI.matrix = Matrix4x4.Scale(new Vector3(scale, scale, 1));
            w /= scale; h /= scale;

            if (screenMode == ScreenMode.MainMenu)
            {
                DrawMainMenu(w, h);
                GUI.matrix = Matrix4x4.identity;
                return;
            }
            if (screenMode == ScreenMode.Settings)
            {
                DrawSettings(w, h);
                GUI.matrix = Matrix4x4.identity;
                return;
            }
            if (screenMode == ScreenMode.SaveSlots)
            {
                DrawSaveSlots(w, h);
                GUI.matrix = Matrix4x4.identity;
                return;
            }
            if (screenMode == ScreenMode.Missions)
            {
                DrawMissions(w, h);
                GUI.matrix = Matrix4x4.identity;
                return;
            }

            if (screenMode != ScreenMode.Garage)
            {
                DrawSchool(w, h);
                GUI.matrix = Matrix4x4.identity;
                return;
            }

            DrawGarage(w, h);
            GUI.matrix = Matrix4x4.identity;
        }

        private void DrawMainMenu(float width, float height)
        {
            Fill(new Rect(0, 0, width, height), new Color(.008f, .012f, .02f, .26f));
            Fill(new Rect(0, 87, Mathf.Clamp(width * .29f, 342f, 420f), height - 87),
                new Color(.008f, .011f, .017f, .35f));
            Fill(new Rect(0, 87, 5, height - 87), new Color(.82f, .025f, .04f, .8f));
            Fill(new Rect(0, 0, width, 86), new Color(.012f, .015f, .02f, .82f));
            DrawCareerProfile(new Rect(width - 665, 14, 400, 60));
            DrawBrandLogo(new Rect(width - 250, 4, 225, 78));

            float left = 24, menuWidth = Mathf.Clamp(width * .25f, 300, 370);
            float buttonHeight = Mathf.Clamp(height * .065f, 53, 62);
            float gap = 8;
            float y = height * .24f;
            DrawMenuButton(new Rect(left, y, menuWidth, buttonHeight), "▶   " + MotoRegion.T("CONTINUAR", "CONTINUE", "CONTINUAR"), true, 1, ContinueCareer);
            y += buttonHeight + gap;
            DrawMenuButton(new Rect(left, y, menuWidth, buttonHeight), "◉   " + MotoRegion.T("NOVO JOGO", "NEW GAME", "NUEVO JUEGO"), false, 2, StartNewGame);
            y += buttonHeight + gap;
            DrawMenuButton(new Rect(left, y, menuWidth, buttonHeight), "▣   " + MotoRegion.T("CARREIRAS", "SAVE SLOTS", "PARTIDAS"), false, 3,
                () => OpenSlots(false));
            y += buttonHeight + gap;
            DrawMenuButton(new Rect(left, y, menuWidth, buttonHeight), "★   " + MotoRegion.T("MISSÕES", "MISSIONS", "MISIONES"), false, 4,
                OpenMissions);
            y += buttonHeight + gap;
            DrawMenuButton(new Rect(left, y, menuWidth, buttonHeight), "⌂   " + MotoRegion.T("GARAGEM", "GARAGE", "GARAJE"), false, 5, OpenGarage);
            y += buttonHeight + gap;
            DrawMenuButton(new Rect(left, y, menuWidth, buttonHeight), "⚙   " + MotoRegion.T("CONFIGURAÇÕES", "SETTINGS", "CONFIGURACIÓN"), false, 6,
                () => screenMode = ScreenMode.Settings);
            y += buttonHeight + gap;
            DrawMenuButton(new Rect(left, y, menuWidth, buttonHeight), "⇥   " + MotoRegion.T("SAIR", "QUIT", "SALIR"), false, 7, Application.Quit);

            DrawJourneyCard(new Rect(width * .51f, height * .64f, width * .44f, 174f));

            GUI.Label(new Rect(22, height - 42, 160, 24), "v1.0.0", small);
            if (DrawInteractiveButton(new Rect(width - 190, height - 52, 168, 36), MotoRegion.Label + "  ▾", 8, false, button))
            {
                MotoRegion.Current = (MotoRegion.Current + 1) % 3;
            }
            DrawNotice(width, height);
        }

        private void DrawJourneyCard(Rect rect)
        {
            DrawPanel(rect);
            bool theoryDone = PlayerPrefs.GetInt("MotoSim.Career.TheoryPassed", 0) == 1;
            bool practicalDone = PlayerPrefs.GetInt("MotoSim.Career.PracticalPassed", 0) == 1;
            int stage = practicalDone ? 3 : theoryDone ? 2 : 1;
            GUI.Label(new Rect(rect.x + 22, rect.y + 14, rect.width - 44, 25),
                MotoRegion.T("MODO CARREIRA  /  ETAPA ", "CAREER MODE  /  STAGE ", "MODO CARRERA  /  ETAPA ") +
                stage.ToString("00") + "/03", small);
            string next = practicalDone ? MotoRegion.T("Sua habilitação está pronta", "Your licence is ready", "Tu licencia está lista") :
                theoryDone ? MotoRegion.T("Próxima parada: pista prática", "Next stop: practical course", "Próxima parada: pista práctica") :
                MotoRegion.T("Próxima parada: autoescola", "Next stop: riding school", "Próxima parada: autoescuela");
            GUI.Label(new Rect(rect.x + 22, rect.y + 43, rect.width - 44, 42), next, title);
            GUI.Label(new Rect(rect.x + 24, rect.y + 90, rect.width - 48, 35),
                practicalDone ? MotoRegion.T("Treine na pista e amplie sua garagem.", "Ride the course and expand your garage.", "Practica en la pista y amplía tu garaje.") :
                theoryDone ? MotoRegion.T("A Start espera por você no circuito.", "The Start is waiting on the course.", "La Start te espera en el circuito.") :
                MotoRegion.T("Conheça Leo, estude e faça a prova teórica.", "Meet Leo, study and take the theory test.", "Conoce a Leo, estudia y haz el examen teórico."), body);
            float barW = (rect.width - 56f) / 3f;
            for (int i = 0; i < 3; i++)
                Fill(new Rect(rect.x + 22f + i * (barW + 6f), rect.yMax - 26f, barW, 7f),
                    i < stage ? new Color(.9f, .025f, .04f) : new Color(.27f, .29f, .32f));
        }

        private void BeginSchoolIntro(bool resume = false)
        {
            introStep = resume ? Mathf.Clamp(PlayerPrefs.GetInt("MotoSim.Career.LessonIndex", 0), 0,
                MotoSchoolQuestions.LessonCount) : 0;
            if (introStep >= MotoSchoolQuestions.LessonCount)
            {
                questionIndex = 0; correctAnswers = 0;
                theoryStarted = Time.unscaledTime;
                screenMode = ScreenMode.Theory;
                ApplySelection();
                return;
            }
            introStarted = Time.unscaledTime;
            lessonCheckChoice = -1;
            lessonCheckComplete = false;
            screenMode = ScreenMode.SchoolIntro;
            ApplySelection();
            PlayerPrefs.SetInt("MotoSim.Career.LessonIndex", introStep);
            PlayerPrefs.Save();
            MotoMissionBoard.SyncMilestones();
            MotoCareerSaveSlots.SaveActive();
            PlayLessonNarration();
        }

        private void AdvanceSchoolIntro()
        {
            introStep++;
            introStarted = Time.unscaledTime;
            lessonCheckChoice = -1;
            lessonCheckComplete = false;
            PlayerPrefs.SetInt("MotoSim.Career.LessonIndex", introStep);
            PlayerPrefs.Save();
            MotoMissionBoard.SyncMilestones();
            MotoCareerSaveSlots.SaveActive();
            if (introStep >= MotoSchoolQuestions.LessonCount)
            {
                StopLessonNarration();
                questionIndex = 0;
                correctAnswers = 0;
                theoryStarted = Time.unscaledTime;
                screenMode = ScreenMode.Theory;
            }
            else PlayLessonNarration();
        }

        private void PlayLessonNarration()
        {
            StopLessonNarration();
            string locale = MotoRegion.Current == 1 ? "en-US" : MotoRegion.Current == 2 ? "es-ES" : "pt-BR";
            lessonClip = Resources.Load<AudioClip>("MotoSim/Voice/" + locale + "/lesson_" + introStep.ToString("00"));
            if (lessonClip == null || storyVoice == null) return;
            storyVoice.clip = lessonClip;
            storyVoice.Play();
        }

        private void StopLessonNarration()
        {
            if (storyVoice != null) { storyVoice.Stop(); storyVoice.clip = null; }
            lessonClip = null;
        }

        private void DrawSchool(float width, float height)
        {
            if (screenMode == ScreenMode.SchoolIntro)
            {
                Fill(new Rect(0, 0, width, 84f), new Color(.008f, .012f, .02f, .89f));
                Fill(new Rect(0, height - 345f, width, 345f), new Color(.005f, .008f, .014f, .93f));
                Fill(new Rect(0, height - 345f, width, 3f), new Color(.9f, .035f, .045f));
                DrawBrandLogo(new Rect(width - 244, 4, 216, 76));
                GUI.Label(new Rect(36, 15, 430, 28), MotoRegion.T("AUTOESCOLA  /  AULA ", "RIDING SCHOOL  /  LESSON ", "AUTOESCUELA  /  CLASE ") +
                    (introStep + 1) + " / " + MotoSchoolQuestions.LessonCount, heading);
                GUI.Label(new Rect(width - 505, 48, 240, 24),
                    MotoRegion.T("V  •  MUDAR CÂMERA", "V  •  CHANGE CAMERA", "V  •  CAMBIAR CÁMARA"), small);
                float progressWidth = Mathf.Min(width * .47f, 555f);
                Fill(new Rect(38, 54, progressWidth, 7), new Color(.22f, .24f, .28f));
                Fill(new Rect(38, 54, progressWidth * (introStep + 1f) / MotoSchoolQuestions.LessonCount, 7), new Color(.92f, .035f, .045f));
                bool taughtTopic = introStep > 0 && introStep < MotoSchoolQuestions.LessonCount - 1;
                float leftWidth = taughtTopic ? width * .52f - 88f : width - 136f;
                GUI.Label(new Rect(65, height - 327, leftWidth, 43), MotoSchoolQuestions.LessonTitle(introStep), title);
                GUI.Label(new Rect(68, height - 278, leftWidth, 157), MotoSchoolQuestions.LessonNarration(introStep), storyBody);
                GUI.Label(new Rect(68, height - 113, leftWidth, 43), "◆  " + MotoSchoolQuestions.LessonTakeaway(introStep), body);
                if (taughtTopic)
                {
                    int topic = introStep - 1;
                    Rect practice = new Rect(width * .54f, height - 327f, width * .42f, 242f);
                    DrawPanel(practice);
                    GUI.Label(new Rect(practice.x + 15, practice.y + 10, practice.width - 30, 48),
                        MotoSchoolQuestions.Prompt(topic), body);
                    GUIStyle optionStyle = new GUIStyle(button) { fontSize = 13, wordWrap = true,
                        alignment = TextAnchor.MiddleCenter };
                    for (int choice = 0; choice < 3; choice++)
                    {
                        int selected = choice;
                        bool correct = lessonCheckComplete && choice == 0;
                        if (DrawInteractiveButton(new Rect(practice.x + 14, practice.y + 62 + choice * 52,
                            practice.width - 28, 44), MotoSchoolQuestions.Answer(topic, choice),
                            90 + choice, correct, optionStyle))
                        {
                            lessonCheckChoice = selected;
                            lessonCheckComplete = MotoSchoolQuestions.IsCorrect(selected);
                        }
                    }
                    if (lessonCheckChoice >= 0)
                        GUI.Label(new Rect(practice.x + 18, practice.y + 220, practice.width - 36, 20),
                            lessonCheckComplete ? MotoRegion.T("Boa decisão. Você pode continuar.", "Good decision. You can continue.", "Buena decisión. Puedes continuar.") :
                            MotoRegion.T("Pense na atitude mais segura e tente novamente.", "Choose the safest action and try again.", "Elige lo más seguro e inténtalo de nuevo."), small);
                }
                if (DrawActionButton(new Rect(65, height - 67, 165, 46),
                    MotoRegion.T("‹  VOLTAR", "‹  BACK", "‹  VOLVER"), false, 80))
                {
                    if (introStep == 0) OpenMainMenu();
                    else
                    {
                        introStep--;
                        introStarted = Time.unscaledTime;
                        lessonCheckChoice = -1;
                        lessonCheckComplete = false;
                        PlayerPrefs.SetInt("MotoSim.Career.LessonIndex", introStep);
                        PlayerPrefs.Save();
                        MotoCareerSaveSlots.SaveActive();
                        PlayLessonNarration();
                    }
                }
                if (lessonClip != null && DrawActionButton(new Rect(246, height - 67, 175, 46),
                    MotoRegion.T("↻  OUVIR", "↻  REPLAY", "↻  REPETIR"), false, 81)) PlayLessonNarration();
                GUI.enabled = !taughtTopic || lessonCheckComplete;
                bool nextLesson = DrawActionButton(new Rect(width - 315, height - 67, 245, 46),
                    introStep == MotoSchoolQuestions.LessonCount - 1 ? MotoRegion.T("FAZER A PROVA  ›", "TAKE THE TEST  ›", "HACER EL EXAMEN  ›") :
                    MotoRegion.T("PRÓXIMA AULA  ›", "NEXT LESSON  ›", "SIGUIENTE CLASE  ›"), true, 82);
                GUI.enabled = true;
                if (nextLesson) AdvanceSchoolIntro();
                return;
            }

            Fill(new Rect(0, 0, width, height), new Color(.008f, .012f, .019f, .78f));
            DrawBrandLogo(new Rect(width - 255, 12, 220, 78));
            Rect panel = new Rect(width * .17f, height * .13f, width * .66f, height * .74f);
            DrawPanel(panel);
            if (screenMode == ScreenMode.Theory)
            {
                GUI.Label(new Rect(panel.x + 34, panel.y + 28, panel.width - 68, 44),
                    MotoRegion.T("PROVA TEÓRICA", "THEORY TEST", "EXAMEN TEÓRICO"), title);
                int elapsedSeconds = Mathf.Max(0, Mathf.FloorToInt(Time.unscaledTime - theoryStarted));
                GUI.Label(new Rect(panel.x + 36, panel.y + 79, panel.width - 72, 28),
                    (questionIndex + 1) + "/" + MotoSchoolQuestions.Count + "   •   " +
                    MotoRegion.T("ACERTOS: ", "CORRECT: ", "ACIERTOS: ") + correctAnswers + "   •   " +
                    MotoRegion.T("TEMPO: ", "TIME: ", "TIEMPO: ") + (elapsedSeconds / 60).ToString("00") + ":" +
                    (elapsedSeconds % 60).ToString("00"), body);
                Fill(new Rect(panel.x + 35, panel.y + 116, panel.width - 70, 5), new Color(.24f, .25f, .28f));
                Fill(new Rect(panel.x + 35, panel.y + 116, (panel.width - 70) * questionIndex / MotoSchoolQuestions.Count, 5),
                    new Color(.9f, .035f, .045f));
                GUI.Label(new Rect(panel.x + 36, panel.y + 133, panel.width - 72, 90), MotoSchoolQuestions.Prompt(questionIndex), heading);
                for (int slot = 0; slot < 3; slot++)
                {
                    int answer = (slot + questionIndex) % 3;
                    if (DrawActionButton(new Rect(panel.x + 35, panel.y + 247 + slot * 86, panel.width - 70, 66),
                        MotoSchoolQuestions.Answer(questionIndex, answer), false, 100 + slot))
                    {
                        selectedAnswer = answer;
                        if (MotoSchoolQuestions.IsCorrect(answer)) correctAnswers++;
                        screenMode = ScreenMode.TheoryFeedback;
                        break;
                    }
                }
                return;
            }

            if (screenMode == ScreenMode.TheoryFeedback)
            {
                bool correct = MotoSchoolQuestions.IsCorrect(selectedAnswer);
                GUI.Label(new Rect(panel.x + 35, panel.y + 46, panel.width - 70, 64),
                    correct ? MotoRegion.T("RESPOSTA CERTA", "CORRECT ANSWER", "RESPUESTA CORRECTA") :
                    MotoRegion.T("VAMOS REVISAR", "LET'S REVIEW", "VAMOS A REPASAR"), title);
                Fill(new Rect(panel.x + 35, panel.y + 125, panel.width - 70, 4),
                    correct ? new Color(.17f, .8f, .42f) : new Color(.92f, .13f, .1f));
                GUI.Label(new Rect(panel.x + 35, panel.y + 156, panel.width - 70, 100),
                    MotoSchoolQuestions.Explanation(questionIndex), storyBody);
                GUI.Label(new Rect(panel.x + 35, panel.y + 279, panel.width - 70, 35),
                    MotoRegion.T("Resposta segura: ", "Safe answer: ", "Respuesta segura: ") +
                    MotoSchoolQuestions.Answer(questionIndex, 0), heading);
                if (DrawActionButton(new Rect(panel.x + 35, panel.yMax - 100, panel.width - 70, 60),
                    questionIndex == MotoSchoolQuestions.Count - 1 ? MotoRegion.T("VER RESULTADO  ›", "SEE RESULT  ›", "VER RESULTADO  ›") :
                    MotoRegion.T("PRÓXIMA QUESTÃO  ›", "NEXT QUESTION  ›", "SIGUIENTE PREGUNTA  ›"), true, 119))
                {
                    questionIndex++;
                    if (questionIndex == MotoSchoolQuestions.Count)
                    {
                        theoryPassed = correctAnswers >= MotoSchoolQuestions.PassingScore;
                        if (theoryPassed)
                        {
                            PlayerPrefs.SetInt("MotoSim.Career.TheoryPassed", 1);
                            PlayerPrefs.Save();
                            MotoMissionBoard.SyncMilestones();
                            MotoCareerSaveSlots.SaveActive();
                        }
                        screenMode = ScreenMode.TheoryResult;
                    }
                    else screenMode = ScreenMode.Theory;
                }
                return;
            }

            if (screenMode == ScreenMode.TheoryResult)
            {
                GUI.Label(new Rect(panel.x + 35, panel.y + 60, panel.width - 70, 70),
                    theoryPassed ? MotoRegion.T("APROVADO NA TEORIA", "THEORY TEST PASSED", "TEORÍA APROBADA") :
                    MotoRegion.T("REFAÇA A PROVA", "RETAKE THE TEST", "REPITE EL EXAMEN"), title);
                GUI.Label(new Rect(panel.x + 35, panel.y + 160, panel.width - 70, 70),
                    correctAnswers + "/" + MotoSchoolQuestions.Count + "  ·  " +
                    MotoRegion.T("Mínimo de acertos: ", "Minimum correct: ", "Aciertos mínimos: ") + MotoSchoolQuestions.PassingScore, heading);
                if (DrawActionButton(new Rect(panel.x + 35, panel.yMax - 100, panel.width - 70, 60),
                    theoryPassed ? MotoRegion.T("IR PARA A AULA PRÁTICA", "GO TO PRACTICAL LESSON", "IR A LA CLASE PRÁCTICA") :
                    MotoRegion.T("TENTAR NOVAMENTE", "TRY AGAIN", "INTENTAR DE NUEVO"), true, 120))
                {
                    if (theoryPassed) screenMode = ScreenMode.PracticalIntro;
                    else { questionIndex = 0; correctAnswers = 0; theoryStarted = Time.unscaledTime; screenMode = ScreenMode.Theory; }
                }
                return;
            }

            GUI.Label(new Rect(panel.x + 35, panel.y + 65, panel.width - 70, 66),
                MotoRegion.T("AULA PRÁTICA", "PRACTICAL LESSON", "CLASE PRÁCTICA"), title);
            GUI.Label(new Rect(panel.x + 35, panel.y + 152, panel.width - 70, 130),
                MotoRegion.T("Agora pilote a Start no circuito. Passe pelos seis marcadores em ordem, até 45 km/h, sem cair ou atingir os cones. Conclua a prova para obter sua habilitação no jogo.",
                    "Ride the Start through six markers in order, below 45 km/h. Do not fall or hit cones. Complete the test to earn your in-game licence.",
                    "Conduce la Start por seis marcadores en orden, hasta 45 km/h. No caigas ni toques los conos. Completa la prueba para obtener tu licencia en el juego."), body);
            if (DrawActionButton(new Rect(panel.x + 35, panel.yMax - 100, panel.width - 70, 60),
                MotoRegion.T("COMEÇAR PROVA PRÁTICA", "START PRACTICAL TEST", "EMPEZAR PRUEBA PRÁCTICA"), true, 121))
            {
                selectedIndex = MotoCareerProgress.StarterBikeIndex;
                PlayerPrefs.SetInt("MotoSim.Career.PracticalActive", 1);
                PlayerPrefs.Save();
                MotoCareerSaveSlots.SaveActive();
                StartCoroutine(LoadPracticeScene());
            }
        }

        private void DrawGarage(float width, float height)
        {
            Fill(new Rect(0, 0, width, height), new Color(.008f, .012f, .02f, .16f));
            Rect top = new Rect(0, 0, width, 82);
            Fill(top, new Color(.012f, .015f, .02f, .9f));
            if (DrawInteractiveButton(new Rect(18, 16, 142, 50), "‹  " + MotoRegion.T("VOLTAR", "BACK", "VOLVER"), 10, false, button)) OpenMainMenu();
            GUI.Label(new Rect(178, 13, 220, 52), MotoRegion.T("GARAGEM", "GARAGE", "GARAJE"), title);
            DrawCareerProfile(new Rect(width - 665, 12, 400, 60));
            DrawBrandLogo(new Rect(width - 250, 2, 225, 78));

            float margin = 22f;
            float leftX = margin, leftY = 106f, leftW = Mathf.Clamp(width * .235f, 300f, 360f);
            float panelH = Mathf.Min(height - 185f, height * .70f);
            Rect leftPanel = new Rect(leftX, leftY, leftW, panelH);
            DrawPanel(leftPanel);
            GUI.Label(new Rect(leftX + 18, leftY + 14, leftW - 36, 32), MotoRegion.T("ESCOLHA SUA MOTO", "CHOOSE YOUR BIKE", "ELIGE TU MOTO"), heading);
            GUI.Label(new Rect(leftX + 18, leftY + 45, leftW - 36, 24),
                "NÍVEL " + MotoCareerProgress.CareerLevel + "   •   " + MotoCareerProgress.FormatCredits(MotoCareerProgress.Balance), small);

            int count = Mathf.Min(bikeNames.Length, scenePaths.Length);
            float cardHeight = Mathf.Min(94f, (panelH - 170f) / Mathf.Max(1, count));
            for (int i = 0; i < count; i++)
            {
                float y = leftY + 82f + i * (cardHeight + 10f);
                bool owned = MotoCareerProgress.IsOwned(i);
                bool isSelected = i == selectedIndex;
                string state = owned ? (i == 0 ? MotoRegion.T("MOTO INICIAL  •  GRÁTIS", "STARTER BIKE  •  FREE", "MOTO INICIAL  •  GRATIS") :
                    MotoRegion.T("DESBLOQUEADA", "UNLOCKED", "DESBLOQUEADA")) :
                    MotoRegion.T("BLOQUEADA", "LOCKED", "BLOQUEADA") + "  •  " + MotoCareerProgress.FormatCredits(MotoCareerProgress.PriceFor(i));
                GUI.backgroundColor = isSelected ? new Color(.46f, .018f, .03f, .98f) : new Color(.035f, .04f, .05f, .94f);
                bool clicked = DrawInteractiveButton(new Rect(leftX + 12, y, leftW - 24, cardHeight),
                    bikeNames[i] + "\n" + state, 20 + i, isSelected, card);
                GUI.backgroundColor = Color.white;
                if (clicked)
                {
                    selectedIndex = i;
                    selectedPaint = MotoCareerProgress.PaintIndex(i);
                    PlayerPrefs.SetInt("MotoSim.GarageSelection", i);
                    ApplySelection();
                }
            }
            float utilityWidth = (leftW - 46f) * .5f;
            if (DrawInteractiveButton(new Rect(leftX + 18, leftPanel.yMax - 57f, utilityWidth, 40f),
                MotoRegion.T("▣ CARREIRAS", "▣ SAVES", "▣ PARTIDAS"), 11, false, button)) OpenSlots(false);
            if (DrawInteractiveButton(new Rect(leftX + 28 + utilityWidth, leftPanel.yMax - 57f, utilityWidth, 40f),
                MotoRegion.T("★ MISSÕES", "★ MISSIONS", "★ MISIONES"), 12, false, button)) OpenMissions();

            float rightW = Mathf.Clamp(width * .24f, 318f, 360f);
            float rightX = width - rightW - margin;
            Rect info = new Rect(rightX, leftY + 4, rightW, Mathf.Min(panelH - 10, 535f));
            DrawPanel(info);
            string name = selectedIndex < bikeNames.Length ? bikeNames[selectedIndex] : "Moto";
            GUI.Label(new Rect(rightX + 20, info.y + 18, rightW - 40, 58), name, title);
            bool selectedOwned = MotoCareerProgress.IsOwned(selectedIndex);
            string stateText = selectedOwned ? (selectedIndex == 0 ? MotoRegion.T("MOTO INICIAL  •  SEM CUSTO", "STARTER BIKE  •  FREE", "MOTO INICIAL  •  GRATIS") :
                MotoRegion.T("MOTO DESBLOQUEADA", "BIKE UNLOCKED", "MOTO DESBLOQUEADA")) : MotoRegion.T("MOTO BLOQUEADA", "BIKE LOCKED", "MOTO BLOQUEADA");
            GUI.Label(new Rect(rightX + 20, info.y + 75, rightW - 40, 28), stateText, heading);
            Fill(new Rect(rightX + 18, info.y + 112, rightW - 36, 2), new Color(.86f, .035f, .045f, .9f));
            GUI.Label(new Rect(rightX + 20, info.y + 126, rightW - 40, 24), MotoRegion.T("PREÇO DE COMPRA", "PURCHASE PRICE", "PRECIO DE COMPRA"), small);
            GUI.Label(new Rect(rightX + 20, info.y + 148, rightW - 40, 42),
                selectedIndex == MotoCareerProgress.StarterBikeIndex ? MotoRegion.T("GRÁTIS", "FREE", "GRATIS") : MotoCareerProgress.FormatCredits(MotoCareerProgress.PriceFor(selectedIndex)), title);
            GUI.Label(new Rect(rightX + 20, info.y + 194, rightW - 40, 25),
                MotoRegion.T("SALDO  ", "BALANCE  ", "SALDO  ") + MotoCareerProgress.FormatCredits(MotoCareerProgress.Balance), body);

            GUI.Label(new Rect(rightX + 20, info.y + 241, rightW - 40, 25), MotoRegion.T("PALETA DE CORES", "COLOR PALETTE", "PALETA DE COLORES"), heading);
            float paintX = rightX + 20f, paintW = rightW - 74f;
            for (int sample = 0; sample < 32; sample++)
                Fill(new Rect(paintX + sample * paintW / 32f, info.y + 274f, paintW / 32f + 1f, 20f), Color.HSVToRGB(sample / 32f, 1f, 1f));
            float hue = MotoCareerProgress.PaintHue(selectedIndex);
            float saturation = MotoCareerProgress.PaintSaturation(selectedIndex);
            float brightness = MotoCareerProgress.PaintBrightness(selectedIndex);
            float chosenHue = GUI.HorizontalSlider(new Rect(paintX, info.y + 303f, paintW, 17f), hue, 0f, 1f);
            GUI.Label(new Rect(paintX, info.y + 326f, paintW, 19f), MotoRegion.T("SATURAÇÃO", "SATURATION", "SATURACIÓN"), small);
            float chosenSaturation = GUI.HorizontalSlider(new Rect(paintX, info.y + 350f, paintW, 17f), saturation, 0f, 1f);
            GUI.Label(new Rect(paintX, info.y + 373f, paintW, 19f), MotoRegion.T("BRILHO", "BRIGHTNESS", "BRILLO"), small);
            float chosenBrightness = GUI.HorizontalSlider(new Rect(paintX, info.y + 397f, paintW, 17f), brightness, .15f, 1f);
            Fill(new Rect(rightX + rightW - 48f, info.y + 274f, 27f, 143f), Color.HSVToRGB(chosenHue, chosenSaturation, chosenBrightness));
            if (!Mathf.Approximately(chosenHue, hue) || !Mathf.Approximately(chosenSaturation, saturation) || !Mathf.Approximately(chosenBrightness, brightness))
            {
                MotoCareerProgress.SetCustomPaintColor(selectedIndex, chosenHue, chosenSaturation, chosenBrightness);
                if (selectedIndex >= 0 && selectedIndex < displayModels.Length)
                    MotorcyclePaint.Apply(displayModels[selectedIndex], selectedIndex);
            }
            GUI.Label(new Rect(rightX + 20, info.y + 435, rightW - 40, 45),
                MotoRegion.T("A cor acompanha a moto na pista.", "Your color follows the bike to the track.", "El color acompaña la moto en pista."), small);

            float previewX = leftX + leftW + 22f;
            float previewW = Mathf.Max(250f, rightX - previewX - 22f);
            Fill(new Rect(previewX, leftY + 4, previewW, 56f), new Color(.008f, .012f, .02f, .68f));
            GUIStyle previewTitle = new GUIStyle(heading) { alignment = TextAnchor.MiddleCenter, fontSize = 22 };
            GUI.Label(new Rect(previewX + 12, leftY + 7, previewW - 24, 30f), name, previewTitle);
            GUIStyle previewHint = new GUIStyle(small) { alignment = TextAnchor.MiddleCenter };
            GUI.Label(new Rect(previewX + 12, leftY + 36, previewW - 24, 18f),
                MotoRegion.T("VISUALIZAÇÃO 360°", "360° PREVIEW", "VISTA 360°"), previewHint);
            float controlY = height - 165f;
            float controlsX = previewX + (previewW - 346f) * .5f;
            if (DrawActionButton(new Rect(controlsX, controlY, 66f, 42f), "‹", false, 53)) RotatePreview(-24f);
            if (DrawActionButton(new Rect(controlsX + 75f, controlY, 196f, 42f),
                previewSpinning ? MotoRegion.T("Ⅱ  PAUSAR GIRO", "Ⅱ  PAUSE SPIN", "Ⅱ  PAUSAR GIRO") :
                MotoRegion.T("▶  GIRO AUTOMÁTICO", "▶  AUTO SPIN", "▶  GIRO AUTOMÁTICO"), false, 54))
                previewSpinning = !previewSpinning;
            if (DrawActionButton(new Rect(controlsX + 280f, controlY, 66f, 42f), "›", false, 55)) RotatePreview(24f);

            float actionY = height - 82f;
            float actionW = Mathf.Clamp(width * .19f, 220f, 270f);
            float gap = 18f;
            float actionX = (width - (actionW * 2f + gap)) * .5f;
            if (selectedOwned)
            {
                if (DrawActionButton(new Rect(actionX, actionY, actionW, 58), "✓   " + MotoRegion.T("SELECIONAR", "SELECT", "SELECCIONAR"), true, 60))
                { SaveSelection(); ShowNotice(name + " selecionada."); }
                if (DrawActionButton(new Rect(actionX + actionW + gap, actionY, actionW, 58), "▶   " + MotoRegion.T("TESTAR", "TEST RIDE", "PROBAR"), false, 61))
                    StartCoroutine(LoadSelectedScene(true));
            }
            else
            {
                bool canBuy = MotoCareerProgress.Balance >= MotoCareerProgress.PriceFor(selectedIndex);
                GUI.enabled = canBuy;
                bool buy = DrawActionButton(new Rect(actionX, actionY, actionW, 58), canBuy ? MotoRegion.T("R$   COMPRAR", "R$   BUY", "R$   COMPRAR") :
                    MotoRegion.T("SALDO INSUFICIENTE", "NOT ENOUGH CREDITS", "SALDO INSUFICIENTE"), true, 62);
                GUI.enabled = true;
                if (buy)
                {
                    if (MotoCareerProgress.TryPurchase(selectedIndex))
                    {
                        ShowNotice(name + " comprada e desbloqueada!");
                        SaveSelection();
                        ApplySelection();
                    }
                }
                if (DrawActionButton(new Rect(actionX + actionW + gap, actionY, actionW, 58), "▶   " + MotoRegion.T("TESTAR", "TEST RIDE", "PROBAR"), false, 63))
                    StartCoroutine(LoadSelectedScene(true));
            }
            DrawNotice(width, height);
        }

        private void RotatePreview(float angle)
        {
            previewSpinning = false;
            if (selectedIndex >= 0 && selectedIndex < displayModels.Length && displayModels[selectedIndex] != null)
                displayModels[selectedIndex].transform.Rotate(Vector3.up, angle, Space.World);
        }

        private void DrawCareerProfile(Rect rect)
        {
            DrawPanel(rect);
            GUI.Label(new Rect(rect.x + 16, rect.y + 4, 170, 24), "●  " + MotoRegion.T("JOGADOR", "PLAYER", "JUGADOR"), heading);
            GUI.Label(new Rect(rect.x + 18, rect.y + 30, 105, 19), MotoRegion.T("NÍVEL ", "LEVEL ", "NIVEL ") + MotoCareerProgress.CareerLevel, small);
            Fill(new Rect(rect.x + 120, rect.y + 37, 94, 8), new Color(.2f, .21f, .23f));
            Fill(new Rect(rect.x + 120, rect.y + 37, 94f * MotoCareerProgress.LevelProgress, 8), new Color(.9f, .025f, .04f));
            GUI.Label(new Rect(rect.x + 226, rect.y + 12, rect.width - 236, 34), MotoCareerProgress.FormatCredits(MotoCareerProgress.Balance), heading);
        }

        private void DrawBrandLogo(Rect rect)
        {
            if (brandLogo != null)
            {
                Color old = GUI.color;
                GUI.color = Color.white;
                GUI.DrawTexture(rect, brandLogo, ScaleMode.ScaleToFit, true);
                GUI.color = old;
            }
            else
            {
                GUI.Label(new Rect(rect.x, rect.y, rect.width * .45f, rect.height), "MOTO", logo);
                GUI.Label(new Rect(rect.x + rect.width * .45f, rect.y, rect.width * .55f, rect.height), "SIMULADOR", redLogo);
            }
        }

        private void DrawPanel(Rect rect)
        {
            Fill(new Rect(rect.x + 4, rect.y + 5, rect.width, rect.height), new Color(0, 0, 0, .45f));
            Fill(rect, new Color(.012f, .018f, .026f, .88f));
            Stroke(rect, new Color(.4f, .43f, .48f, .72f), 1.5f);
            Fill(new Rect(rect.x, rect.y, rect.width, 3), new Color(.86f, .025f, .04f, .86f));
        }

        private bool DrawPaintSwatch(Rect rect, int paintIndex, int animationId)
        {
            float hover = HoverAmount(rect, animationId);
            Fill(new Rect(rect.x - 2f, rect.y - 2f, rect.width + 4f, rect.height + 4f),
                new Color(.9f, .025f, .035f, paintIndex == selectedPaint ? .95f : .22f + hover * .55f));
            Fill(rect, MotoCareerProgress.PaintColor(paintIndex));
            Rect label = new Rect(rect.x - 4, rect.yMax + 3, rect.width + 8, 17);
            GUIStyle labelStyle = new GUIStyle(small) { alignment = TextAnchor.MiddleCenter, fontSize = 9 };
            GUI.Label(label, paintIndex == selectedPaint ? "✓" : MotoCareerProgress.PaintName(paintIndex), labelStyle);
            return GUI.Button(rect, GUIContent.none, GUIStyle.none);
        }

        private bool DrawActionButton(Rect rect, string label, bool highlighted, int id)
        {
            return DrawInteractiveButton(rect, label, id, highlighted, button);
        }

        private bool DrawInteractiveButton(Rect rect, string label, int id, bool highlighted, GUIStyle style)
        {
            float hover = HoverAmount(rect, id);
            float pulse = .5f + .5f * Mathf.Sin(Time.unscaledTime * 4.5f + id * .37f);
            if (roundedMask == null) CreateRoundedMask();
            Rect animated = new Rect(rect.x - hover * 2f, rect.y - hover * 2f,
                rect.width + hover * 4f, rect.height + hover * 4f);
            GUI.color = highlighted ? new Color(.9f, .04f + hover * .08f, .055f, .80f + .16f * pulse) :
                new Color(.17f + hover * .17f, .19f + hover * .16f, .22f + hover * .16f, .92f);
            GUI.DrawTexture(animated, roundedMask, ScaleMode.StretchToFill, true);
            GUI.color = Color.white;
            bool clicked = GUI.Button(rect, label, style);
            return clicked;
        }

        private void CreateRoundedMask()
        {
            roundedMask = new Texture2D(64, 64, TextureFormat.RGBA32, false);
            roundedMask.name = "MotoSim_Botao_Arredondado";
            for (int y = 0; y < 64; y++)
                for (int x = 0; x < 64; x++)
                {
                    float dx = Mathf.Max(16f - x, 0f, x - 47f);
                    float dy = Mathf.Max(16f - y, 0f, y - 47f);
                    float alpha = Mathf.Clamp01(16.5f - Mathf.Sqrt(dx * dx + dy * dy));
                    roundedMask.SetPixel(x, y, new Color(1f, 1f, 1f, alpha));
                }
            roundedMask.Apply();
        }

        private float HoverAmount(Rect rect, int id)
        {
            if (!buttonHover.TryGetValue(id, out float value)) value = 0;
            float target = rect.Contains(Event.current.mousePosition) ? 1f : 0f;
            value = Mathf.MoveTowards(value, target, Mathf.Max(.01f, Time.unscaledDeltaTime) * 7f);
            buttonHover[id] = value;
            return value;
        }

        private void DrawNotice(float width, float height)
        {
            if (string.IsNullOrEmpty(noticeText) || Time.unscaledTime >= noticeUntil) return;
            float alpha = Mathf.Clamp01(Mathf.Min((noticeUntil - Time.unscaledTime) * 2f, 1f));
            Rect rect = new Rect(width * .31f, height - 146f, width * .38f, 42f);
            Fill(rect, new Color(.02f, .025f, .03f, .9f * alpha));
            Stroke(rect, new Color(.92f, .03f, .045f, .9f * alpha), 2f);
            GUIStyle toast = new GUIStyle(heading) { alignment = TextAnchor.MiddleCenter, fontSize = 14,
                normal = { textColor = new Color(1f, 1f, 1f, alpha) } };
            GUI.Label(rect, noticeText, toast);
        }

        private void ShowNotice(string message)
        {
            noticeText = message;
            noticeUntil = Time.unscaledTime + 3.4f;
        }

        private void DrawSettings(float width, float height)
        {
            Fill(new Rect(0, 0, width, height), new Color(.01f, .012f, .018f, .64f));
            Rect panel = new Rect(width * .28f, height * .18f, width * .48f, height * .64f);
            Fill(panel, new Color(.025f, .03f, .04f, .97f));
            Stroke(panel, new Color(.75f, .025f, .04f), 2);
            GUI.Label(new Rect(panel.x + 28, panel.y + 20, panel.width - 56, 48), MotoRegion.T("CONFIGURAÇÕES", "SETTINGS", "CONFIGURACIÓN"), title);
            GUI.Label(new Rect(panel.x + 32, panel.y + 105, 180, 30), MotoRegion.T("Volume geral", "Master volume", "Volumen general"), body);
            float volume = GUI.HorizontalSlider(new Rect(panel.x + 220, panel.y + 112, panel.width - 265, 24), masterVolume, 0, 1);
            if (!Mathf.Approximately(volume, masterVolume))
            {
                masterVolume = volume;
                AudioListener.volume = masterVolume;
                PlayerPrefs.SetFloat("MotoSim.MasterVolume", masterVolume);
            }
            GUI.Label(new Rect(panel.x + 32, panel.y + 180, 180, 30), MotoRegion.T("Tela cheia", "Fullscreen", "Pantalla completa"), body);
            bool fullscreen = GUI.Toggle(new Rect(panel.x + 220, panel.y + 180, 160, 30), Screen.fullScreen,
                MotoRegion.T("Ativada", "Enabled", "Activada"));
            if (fullscreen != Screen.fullScreen) Screen.fullScreen = fullscreen;
            GUI.Label(new Rect(panel.x + 32, panel.y + 250, 180, 30), MotoRegion.T("Qualidade", "Quality", "Calidad"), body);
            string[] qualityNames = QualitySettings.names;
            if (qualityNames.Length > 0)
            {
                int quality = GUI.SelectionGrid(new Rect(panel.x + 220, panel.y + 244, panel.width - 260, 38),
                    selectedQuality, qualityNames, Mathf.Min(qualityNames.Length, 3));
                if (quality != selectedQuality)
                {
                    selectedQuality = quality;
                    QualitySettings.SetQualityLevel(selectedQuality, true);
                    PlayerPrefs.SetInt("MotoSim.Quality", selectedQuality);
                }
            }
            if (DrawActionButton(new Rect(panel.x + 32, panel.y + panel.height - 76, 210, 50),
                MotoRegion.T("SALVAR E VOLTAR", "SAVE AND BACK", "GUARDAR Y VOLVER"), true, 70))
            {
                PlayerPrefs.Save();
                OpenMainMenu();
            }
        }

        private void DrawMenuButton(Rect rect, string label, bool highlighted, int id, System.Action action)
        {
            if (DrawInteractiveButton(rect, label, id, highlighted, menuButton)) action();
        }

        private void OpenSlots(bool newGame)
        {
            StopLessonNarration();
            slotsReturnMode = screenMode;
            slotsForNewGame = newGame;
            deleteConfirmationSlot = -1;
            screenMode = ScreenMode.SaveSlots;
            ApplySelection();
        }

        private void ContinueCareer()
        {
            if (!MotoCareerSaveSlots.Exists(MotoCareerSaveSlots.ActiveSlot))
            {
                OpenSlots(false);
                return;
            }
            selectedIndex = Mathf.Clamp(PlayerPrefs.GetInt("MotoSim.GarageSelection", 0), 0,
                Mathf.Max(0, bikeNames.Length - 1));
            if (!MotoCareerProgress.IsOwned(selectedIndex)) selectedIndex = MotoCareerProgress.StarterBikeIndex;
            if (PlayerPrefs.GetInt("MotoSim.Career.PracticalActive", 0) == 1) StartCoroutine(LoadPracticeScene());
            else if (PlayerPrefs.GetInt("MotoSim.Career.PracticalPassed", 0) == 1)
                StartCoroutine(LoadSelectedScene());
            else if (PlayerPrefs.GetInt("MotoSim.Career.TheoryPassed", 0) == 1)
                screenMode = ScreenMode.PracticalIntro;
            else BeginSchoolIntro(true);
        }

        private void StartNewGame()
        {
            OpenSlots(true);
        }

        private void DrawSaveSlots(float width, float height)
        {
            Fill(new Rect(0, 0, width, height), new Color(.005f, .008f, .013f, .78f));
            Fill(new Rect(0, 0, width, 84), new Color(.01f, .014f, .02f, .94f));
            if (DrawActionButton(new Rect(26, 18, 144, 48),
                MotoRegion.T("‹  VOLTAR", "‹  BACK", "‹  VOLVER"), false, 130))
            {
                screenMode = slotsReturnMode;
                ApplySelection();
            }
            GUI.Label(new Rect(195, 17, width - 460, 50),
                slotsForNewGame ? MotoRegion.T("ESCOLHA ONDE SALVAR", "CHOOSE A SAVE SLOT", "ELIGE DÓNDE GUARDAR") :
                MotoRegion.T("SUAS CARREIRAS", "YOUR CAREERS", "TUS PARTIDAS"), title);
            DrawBrandLogo(new Rect(width - 250, 3, 225, 77));
            GUI.Label(new Rect(56, 104, width - 112, 42),
                MotoRegion.T("Três carreiras independentes. O progresso é salvo automaticamente durante o jogo.",
                    "Three independent careers. Your progress saves automatically as you play.",
                    "Tres partidas independientes. Tu progreso se guarda automáticamente mientras juegas."), heading);

            float gap = 20f;
            float cardWidth = (width - 112f - gap * 2f) / 3f;
            float cardHeight = Mathf.Min(500f, height - 240f);
            for (int slot = 0; slot < MotoCareerSaveSlots.SlotCount; slot++)
            {
                float x = 56f + slot * (cardWidth + gap);
                Rect card = new Rect(x, 165f, cardWidth, cardHeight);
                DrawPanel(card);
                bool occupied = MotoCareerSaveSlots.Exists(slot);
                bool active = occupied && slot == MotoCareerSaveSlots.ActiveSlot;
                GUI.Label(new Rect(x + 22, card.y + 20, cardWidth - 44, 46),
                    MotoRegion.T("CARREIRA ", "CAREER ", "PARTIDA ") + (slot + 1).ToString("00"), title);
                GUI.Label(new Rect(x + 23, card.y + 70, cardWidth - 46, 26),
                    !occupied ? MotoRegion.T("ESPAÇO VAZIO", "EMPTY SLOT", "ESPACIO VACÍO") :
                    active ? MotoRegion.T("●  CARREIRA ATIVA", "●  ACTIVE CAREER", "●  PARTIDA ACTIVA") :
                    MotoRegion.T("SALVAMENTO DISPONÍVEL", "SAVE AVAILABLE", "PARTIDA DISPONIBLE"), heading);
                Fill(new Rect(x + 21, card.y + 110, cardWidth - 42, 2), new Color(.9f, .04f, .06f));
                if (occupied)
                {
                    int theory = MotoCareerSaveSlots.GetInt(slot, "MotoSim.Career.TheoryPassed");
                    int practical = MotoCareerSaveSlots.GetInt(slot, "MotoSim.Career.PracticalPassed");
                    string stage = practical == 1 ? MotoRegion.T("HABILITADO", "LICENSED", "HABILITADO") :
                        theory == 1 ? MotoRegion.T("AULA PRÁTICA", "PRACTICAL LESSON", "CLASE PRÁCTICA") :
                        MotoRegion.T("AUTOESCOLA", "RIDING SCHOOL", "AUTOESCUELA");
                    GUI.Label(new Rect(x + 23, card.y + 132, cardWidth - 46, 35), stage, heading);
                    GUI.Label(new Rect(x + 23, card.y + 181, cardWidth - 46, 40),
                        MotoCareerProgress.FormatCredits(MotoCareerSaveSlots.GetInt(slot, "MotoSim.Career.Credits")), title);
                    float seconds = Mathf.Clamp(MotoCareerSaveSlots.GetFloat(slot, "MotoSim.Career.PlaySeconds"), 0f, 10000000f);
                    TimeSpan played = TimeSpan.FromSeconds(seconds);
                    GUI.Label(new Rect(x + 23, card.y + 235, cardWidth - 46, 28),
                        MotoRegion.T("TEMPO  ", "PLAY TIME  ", "TIEMPO  ") +
                        Mathf.FloorToInt((float)played.TotalHours).ToString("00") + "h " + played.Minutes.ToString("00") + "m", body);
                    long ticks;
                    if (long.TryParse(MotoCareerSaveSlots.LastSaved(slot), out ticks) &&
                        ticks >= DateTime.MinValue.Ticks && ticks <= DateTime.MaxValue.Ticks)
                        GUI.Label(new Rect(x + 23, card.y + 266, cardWidth - 46, 24),
                            MotoRegion.T("SALVO EM  ", "SAVED  ", "GUARDADO  ") +
                            new DateTime(ticks, DateTimeKind.Utc).ToLocalTime().ToString("dd/MM/yyyy HH:mm"), small);
                    if (DrawActionButton(new Rect(x + 20, card.yMax - 112, cardWidth - 40, 52),
                        MotoRegion.T("▶  CONTINUAR", "▶  CONTINUE", "▶  CONTINUAR"), true, 140 + slot))
                    {
                        MotoCareerSaveSlots.Load(slot);
                        deleteConfirmationSlot = -1;
                        ContinueCareer();
                    }
                    if (DrawActionButton(new Rect(x + 20, card.yMax - 52, cardWidth - 40, 35),
                        deleteConfirmationSlot == slot ? MotoRegion.T("CONFIRMAR EXCLUSÃO", "CONFIRM DELETE", "CONFIRMAR BORRADO") :
                        MotoRegion.T("EXCLUIR CARREIRA", "DELETE CAREER", "BORRAR PARTIDA"), false, 150 + slot))
                    {
                        if (deleteConfirmationSlot == slot)
                        {
                            MotoCareerSaveSlots.Delete(slot);
                            deleteConfirmationSlot = -1;
                        }
                        else deleteConfirmationSlot = slot;
                    }
                }
                else
                {
                    GUI.Label(new Rect(x + 23, card.y + 148, cardWidth - 46, 100),
                        MotoRegion.T("Comece pela autoescola. Dinheiro, motos e missões ficam guardados neste espaço.",
                            "Start at the riding school. Money, bikes and missions stay in this slot.",
                            "Empieza en la autoescuela. Dinero, motos y misiones se guardan aquí."), body);
                    if (DrawActionButton(new Rect(x + 20, card.yMax - 86, cardWidth - 40, 55),
                        MotoRegion.T("＋  CRIAR CARREIRA", "＋  NEW CAREER", "＋  CREAR PARTIDA"), true, 160 + slot) &&
                        MotoCareerSaveSlots.CreateNew(slot))
                    {
                        selectedIndex = MotoCareerProgress.StarterBikeIndex;
                        selectedPaint = MotoCareerProgress.PaintIndex(selectedIndex);
                        BeginSchoolIntro();
                    }
                }
            }
            DrawNotice(width, height);
        }

        private void OpenMissions()
        {
            missionsReturnMode = screenMode;
            screenMode = ScreenMode.Missions;
            missionsScroll = Vector2.zero;
            ApplySelection();
        }

        private void DrawMissions(float width, float height)
        {
            Fill(new Rect(0, 0, width, height), new Color(.005f, .008f, .013f, .86f));
            Fill(new Rect(0, 0, width, 84), new Color(.01f, .014f, .02f, .95f));
            if (DrawActionButton(new Rect(26, 18, 144, 48),
                MotoRegion.T("‹  VOLTAR", "‹  BACK", "‹  VOLVER"), false, 180))
            {
                screenMode = missionsReturnMode;
                ApplySelection();
            }
            GUI.Label(new Rect(195, 17, 490, 50), MotoRegion.T("MISSÕES DA CARREIRA", "CAREER MISSIONS", "MISIONES DE CARRERA"), title);
            DrawBrandLogo(new Rect(width - 250, 3, 225, 77));
            GUI.Label(new Rect(60, 102, width - 120, 38),
                MotoRegion.T("Ganhe créditos extras ao aprender e pilotar. Cada missão paga uma vez.",
                    "Earn extra credits by learning and riding. Each mission pays once.",
                    "Gana créditos extra al aprender y conducir. Cada misión paga una vez."), heading);
            GUI.Label(new Rect(60, 137, width - 120, 27),
                MotoMissionBoard.CompletedCount + " / " + MotoMissionBoard.Count + "  " +
                MotoRegion.T("MISSÕES CONCLUÍDAS", "MISSIONS COMPLETE", "MISIONES COMPLETADAS"), small);
            Rect viewport = new Rect(52, 171, width - 104, height - 205);
            int rows = (MotoMissionBoard.Count + 1) / 2;
            float gap = 16f, cardWidth = (viewport.width - 38f - gap) * .5f;
            missionsScroll = GUI.BeginScrollView(viewport, missionsScroll,
                new Rect(0, 0, viewport.width - 20, rows * 137f + 12f));
            for (int i = 0; i < MotoMissionBoard.Count; i++)
            {
                MissionDefinition mission = MotoMissionBoard.Mission(i);
                float x = (i % 2) * (cardWidth + gap);
                float y = (i / 2) * 137f;
                Rect card = new Rect(x + 2, y + 2, cardWidth, 123f);
                DrawPanel(card);
                bool complete = MotoMissionBoard.IsComplete(i);
                string tier = mission.Tier == MissionTier.Easy ? MotoRegion.T("FÁCIL", "EASY", "FÁCIL") :
                    mission.Tier == MissionTier.Medium ? MotoRegion.T("MÉDIA", "MEDIUM", "MEDIA") :
                    MotoRegion.T("DIFÍCIL", "HARD", "DIFÍCIL");
                GUI.Label(new Rect(card.x + 14, card.y + 8, card.width - 135, 27),
                    MotoRegion.T(mission.TitlePt, mission.TitleEn, mission.TitleEs), heading);
                GUI.Label(new Rect(card.xMax - 110, card.y + 10, 96, 22), tier, small);
                GUI.Label(new Rect(card.x + 14, card.y + 39, card.width - 28, 36),
                    MotoRegion.T(mission.DetailPt, mission.DetailEn, mission.DetailEs), body);
                int progress = Mathf.Min(MotoMissionBoard.Progress(i), mission.Goal);
                float fraction = complete ? 1f : progress / (float)mission.Goal;
                Fill(new Rect(card.x + 14, card.y + 81, card.width - 28, 7), new Color(.22f, .25f, .28f));
                Fill(new Rect(card.x + 14, card.y + 81, (card.width - 28) * fraction, 7),
                    complete ? new Color(.15f, .65f, .35f) : new Color(.9f, .04f, .06f));
                bool distanceMetric = mission.Metric == MissionMetric.CareerDistanceCm ||
                    mission.Metric == MissionMetric.HeadlightDistanceCm || mission.Metric == MissionMetric.SafeStreakCm;
                string count = distanceMetric ? (progress / 100).ToString() + " / " +
                    (mission.Goal / 100).ToString() + " m" : progress + " / " + mission.Goal;
                GUI.Label(new Rect(card.x + 14, card.y + 95, card.width * .50f, 21),
                    complete ? MotoRegion.T("✓ CONCLUÍDA", "✓ COMPLETE", "✓ COMPLETA") : count, small);
                GUIStyle reward = new GUIStyle(small) { alignment = TextAnchor.MiddleRight, fontSize = 12 };
                GUI.Label(new Rect(card.x + card.width * .48f, card.y + 93, card.width * .48f, 23),
                    "+ " + MotoCareerProgress.FormatCredits(mission.RewardCredits), reward);
            }
            GUI.EndScrollView();
            DrawNotice(width, height);
        }

        private void OpenGarage()
        {
            StopLessonNarration();
            screenMode = ScreenMode.Garage;
            selectedIndex = Mathf.Clamp(PlayerPrefs.GetInt("MotoSim.GarageSelection", MotoCareerProgress.StarterBikeIndex),
                0, Mathf.Max(0, bikeNames.Length - 1));
            selectedPaint = MotoCareerProgress.PaintIndex(selectedIndex);
            ApplySelection();
        }

        private void OpenMainMenu()
        {
            StopLessonNarration();
            screenMode = ScreenMode.MainMenu;
            ApplySelection();
        }

        private static void Stroke(Rect rect, Color color, float thickness)
        {
            Fill(new Rect(rect.x, rect.y, rect.width, thickness), color);
            Fill(new Rect(rect.x, rect.yMax - thickness, rect.width, thickness), color);
            Fill(new Rect(rect.x, rect.y, thickness, rect.height), color);
            Fill(new Rect(rect.xMax - thickness, rect.y, thickness, rect.height), color);
        }

        private void SaveSelection()
        {
            if (selectedIndex >= 0 && selectedIndex < bikeNames.Length && MotoCareerProgress.IsOwned(selectedIndex))
            {
                PlayerPrefs.SetString("MotoSim.SelectedBike", bikeNames[selectedIndex]);
                PlayerPrefs.SetInt("MotoSim.GarageSelection", selectedIndex);
                PlayerPrefs.Save();
            }
        }

        private IEnumerator LoadSelectedScene(bool preview = false)
        {
            if (selectedIndex < 0 || selectedIndex >= scenePaths.Length) yield break;
            if (!preview && !MotoCareerProgress.IsOwned(selectedIndex))
            {
                ShowNotice("Essa moto está bloqueada. Compre-a com os créditos da carreira.");
                yield break;
            }
            if (!preview)
            {
                SaveSelection();
                PlayerPrefs.SetInt("MotoSim.HasProgress", 1);
            }
            PlayerPrefs.SetInt("MotoSim.TestRidePreview", preview ? 1 : 0);
            PlayerPrefs.Save();
            yield return StartCoroutine(LoadScene(scenePaths[selectedIndex]));
        }

        private IEnumerator LoadPracticeScene()
        {
            if (string.IsNullOrEmpty(practicalScenePath)) yield break;
            selectedIndex = MotoCareerProgress.StarterBikeIndex;
            PlayerPrefs.SetInt("MotoSim.Career.PracticalActive", 1);
            PlayerPrefs.SetInt("MotoSim.HasProgress", 1);
            PlayerPrefs.Save();
            yield return StartCoroutine(LoadScene(practicalScenePath));
        }

        private IEnumerator LoadScene(string path)
        {
            StopLessonNarration();
            loading = true; loadProgress = 0;
            AsyncOperation operation = SceneManager.LoadSceneAsync(path);
            if (operation == null) { loading = false; yield break; }
            operation.allowSceneActivation = false;
            while (operation.progress < .9f)
            { loadProgress = Mathf.Clamp01(operation.progress / .9f); yield return null; }
            loadProgress = 1; yield return null; operation.allowSceneActivation = true;
        }

        private void DrawLoading()
        {
            EnsureStyles();
            Rect screen = new Rect(0, 0, Screen.width, Screen.height);
            if (officialLoadingBackground != null)
                GUI.DrawTexture(screen, officialLoadingBackground, ScaleMode.ScaleAndCrop, false);
            else Fill(screen, new Color(.035f, .035f, .045f, 1));
            GUIStyle center = new GUIStyle(title)
            { alignment = TextAnchor.MiddleCenter, fontSize = Mathf.Clamp(Screen.height / 28, 20, 34), fontStyle = FontStyle.Bold };
            GUIStyle tip = new GUIStyle(body)
            { alignment = TextAnchor.MiddleLeft, fontSize = Mathf.Clamp(Screen.height / 62, 13, 22), fontStyle = FontStyle.Italic };
            float labelY = Screen.height * .735f;
            GUI.Label(new Rect(0, labelY, Screen.width, Screen.height * .055f), "C A R R E G A N D O . . .", center);
            Rect bar = new Rect(Screen.width * .24f, Screen.height * .805f, Screen.width * .52f, Mathf.Clamp(Screen.height * .037f, 20, 36));
            Fill(bar, new Color(.025f, .025f, .03f, .96f));
            Fill(new Rect(bar.x + 4, bar.y + 4, Mathf.Max(0, (bar.width - 8) * Mathf.Clamp01(loadProgress)), bar.height - 8), new Color(.91f, .025f, .035f));
            Fill(new Rect(bar.x, bar.y, bar.width, 2), new Color(.7f, .7f, .72f, .85f));
            GUI.Label(new Rect(Screen.width * .285f, bar.y + bar.height + 14, Screen.width * .43f, Screen.height * .075f),
                "DICA: MANTENHA O EQUILÍBRIO E A VELOCIDADE CONSTANTE\nNOS PERCURSOS DE PROVA.", tip);
        }

        private static void Fill(Rect rect, Color color)
        {
            Color old = GUI.color; GUI.color = color; GUI.DrawTexture(rect, Texture2D.whiteTexture); GUI.color = old;
        }
    }
}
