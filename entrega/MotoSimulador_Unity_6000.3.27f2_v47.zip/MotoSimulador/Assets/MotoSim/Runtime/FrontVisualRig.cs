using UnityEngine;

namespace MotoSim.Unity
{
    /// <summary>Drives the imported steering and fork pivots from the physical front wheel.</summary>
    [DefaultExecutionOrder(-100)]
    public sealed class FrontVisualRig : MonoBehaviour
    {
        [SerializeField] private Transform steeringPivot;
        [SerializeField] private Transform suspensionPivot;
        [SerializeField] private WheelCollider frontWheel;
        [SerializeField] private Quaternion steeringRestRotation;
        [SerializeField] private Vector3 suspensionRestPosition;
        [SerializeField] private Vector3 axleRestInSuspension;
        [SerializeField] private bool configured;

        public void Configure(Transform steering, Transform suspension, WheelCollider wheel, Vector3 restWheelCenter)
        {
            steeringPivot = steering;
            suspensionPivot = suspension;
            frontWheel = wheel;
            steeringRestRotation = steering.localRotation;
            suspensionRestPosition = suspension.localPosition;
            axleRestInSuspension = suspension.InverseTransformPoint(restWheelCenter);
            configured = true;
        }

        private void LateUpdate()
        {
            if (!configured || steeringPivot == null || suspensionPivot == null || frontWheel == null) return;

            // WheelCollider.steerAngle is a yaw around the motorcycle's up axis.
            // Express that axis in the steering pivot's parent space; using the
            // parent's local Z/Y directly pitches some imported FBX orientations.
            Transform steeringParent = steeringPivot.parent;
            Vector3 steeringAxis = steeringParent == null
                ? transform.up.normalized
                : steeringParent.InverseTransformDirection(transform.up).normalized;
            steeringPivot.localRotation = Quaternion.AngleAxis(frontWheel.steerAngle, steeringAxis) *
                steeringRestRotation;

            frontWheel.GetWorldPose(out Vector3 wheelCenter, out _);
            suspensionPivot.localPosition = suspensionRestPosition;
            Vector3 predictedAxle = suspensionPivot.TransformPoint(axleRestInSuspension);
            // Move the lower fork to the actual physics axle in all three axes.
            // Partial travel and vertical-only projection detached the wheel
            // whenever the steering head yawed or the suspension compressed.
            suspensionPivot.position += wheelCenter - predictedAxle;
        }
    }
}
