using System;
using UnityEngine;
#if UNITY_STANDALONE_WIN || UNITY_EDITOR_WIN
using System.Diagnostics;
using System.Text;
#endif

namespace MotoSim.Unity
{
    /// <summary>Speaks localized school guidance with installed Windows language voices.</summary>
    public static class MotoSpeech
    {
        public static void Say(string pt, string en, string es)
        {
#if UNITY_STANDALONE_WIN || UNITY_EDITOR_WIN
            string language = MotoRegion.Current == 1 ? "en-US" : MotoRegion.Current == 2 ? "es-ES" : "pt-BR";
            string sentence = MotoRegion.T(pt, en, es).Replace("'", "''");
            string script = "Add-Type -AssemblyName System.Speech; " +
                "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer; " +
                "try { $s.SelectVoiceByHints([System.Speech.Synthesis.VoiceGender]::NotSet, " +
                "[System.Speech.Synthesis.VoiceAge]::NotSet, 0, " +
                "[System.Globalization.CultureInfo]::GetCultureInfo('" + language + "')) } catch { exit 0 }; " +
                "$s.Speak('" + sentence + "')";
            string encoded = Convert.ToBase64String(Encoding.Unicode.GetBytes(script));
            try
            {
                var info = new ProcessStartInfo("powershell.exe", "-NoProfile -NonInteractive -WindowStyle Hidden -EncodedCommand " + encoded)
                { UseShellExecute = false, CreateNoWindow = true };
                Process.Start(info);
            }
            catch (Exception error) { UnityEngine.Debug.LogWarning("MotoSim: voz indisponível: " + error.Message); }
#endif
        }
    }
}
