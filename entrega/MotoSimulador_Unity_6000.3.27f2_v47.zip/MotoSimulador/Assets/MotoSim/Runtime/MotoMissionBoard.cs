using MotoSim.Core;
using UnityEngine;

namespace MotoSim.Unity
{
    /// <summary>Persistent one-time mission rewards backed by the pure ride tracker.</summary>
    public static class MotoMissionBoard
    {
        private const string Prefix = "MotoSim.Missions.v1.";
        private static MissionRideTracker ride;
        private static float lastSaveTime;
        public static int NotificationVersion { get; private set; }
        public static int LastCompletedIndex { get; private set; } = -1;

        public static int Count => MissionCatalog.All.Length;
        public static MissionDefinition Mission(int index) => MissionCatalog.All[index];
        public static bool IsComplete(int index) =>
            PlayerPrefs.GetInt(Prefix + Mission(index).Id + ".Complete", 0) == 1;

        public static void Reset()
        {
            foreach (MissionDefinition mission in MissionCatalog.All)
                PlayerPrefs.DeleteKey(Prefix + mission.Id + ".Complete");
            foreach (string key in new[] { "DistanceCm", "HeadlightCm", "SafeBestCm", "SignalMask", "ControlledStops" })
                PlayerPrefs.DeleteKey(Prefix + key);
            PlayerPrefs.SetInt(Prefix + "Initialized", 1);
            ride = null;
            LastCompletedIndex = -1;
            NotificationVersion++;
        }

        private static void EnsureInitialized()
        {
            if (PlayerPrefs.GetInt(Prefix + "Initialized", 0) == 1) return;
            // Existing careers keep their earned riding distance when missions are introduced.
            int prior = PlayerPrefs.GetInt("MotoSim.Career.PracticalPassed", 0) == 1 ?
                PlayerPrefs.GetInt("MotoSim.Career.DistanceCm", 0) : 0;
            PlayerPrefs.SetInt(Prefix + "DistanceCm", Mathf.Max(0, prior));
            PlayerPrefs.SetInt(Prefix + "Initialized", 1);
            PlayerPrefs.Save();
        }

        public static void BeginRide()
        {
            EnsureInitialized();
            ride = new MissionRideTracker(
                PlayerPrefs.GetInt(Prefix + "DistanceCm", 0),
                PlayerPrefs.GetInt(Prefix + "HeadlightCm", 0),
                PlayerPrefs.GetInt(Prefix + "SafeBestCm", 0),
                PlayerPrefs.GetInt(Prefix + "SignalMask", 0),
                PlayerPrefs.GetInt(Prefix + "ControlledStops", 0));
            lastSaveTime = Time.unscaledTime;
            SyncMilestones();
        }

        public static void RecordRide(MissionRideSample sample)
        {
            if (PlayerPrefs.GetInt("MotoSim.Career.PracticalPassed", 0) != 1) return;
            if (ride == null) BeginRide();
            ride.Step(sample);
            StoreRide();
            SyncMilestones();
            if (Time.unscaledTime - lastSaveTime >= 2f)
            {
                PlayerPrefs.Save();
                lastSaveTime = Time.unscaledTime;
            }
        }

        public static void EndRide()
        {
            if (ride == null) return;
            StoreRide();
            PlayerPrefs.Save();
            ride = null;
        }

        private static void StoreRide()
        {
            PlayerPrefs.SetInt(Prefix + "DistanceCm", ride.CareerDistanceCm);
            PlayerPrefs.SetInt(Prefix + "HeadlightCm", ride.HeadlightDistanceCm);
            PlayerPrefs.SetInt(Prefix + "SafeBestCm", ride.BestSafeStreakCm);
            PlayerPrefs.SetInt(Prefix + "SignalMask", ride.SignalMask);
            PlayerPrefs.SetInt(Prefix + "ControlledStops", ride.ControlledStops);
        }

        public static int Progress(int index)
        {
            EnsureInitialized();
            MissionDefinition mission = Mission(index);
            switch (mission.Metric)
            {
                case MissionMetric.Lessons:
                    return PlayerPrefs.GetInt("MotoSim.Career.LessonIndex", 0);
                case MissionMetric.TheoryPassed:
                    return PlayerPrefs.GetInt("MotoSim.Career.TheoryPassed", 0);
                case MissionMetric.PracticalPassed:
                    return PlayerPrefs.GetInt("MotoSim.Career.PracticalPassed", 0);
                case MissionMetric.CareerDistanceCm:
                    return ride == null ? PlayerPrefs.GetInt(Prefix + "DistanceCm", 0) : ride.CareerDistanceCm;
                case MissionMetric.HeadlightDistanceCm:
                    return ride == null ? PlayerPrefs.GetInt(Prefix + "HeadlightCm", 0) : ride.HeadlightDistanceCm;
                case MissionMetric.SignalSides:
                    int mask = ride == null ? PlayerPrefs.GetInt(Prefix + "SignalMask", 0) : ride.SignalMask;
                    return (mask & 1) + ((mask >> 1) & 1);
                case MissionMetric.SafeStreakCm:
                    return ride == null ? PlayerPrefs.GetInt(Prefix + "SafeBestCm", 0) : ride.BestSafeStreakCm;
                case MissionMetric.ControlledStops:
                    return ride == null ? PlayerPrefs.GetInt(Prefix + "ControlledStops", 0) : ride.ControlledStops;
                case MissionMetric.StreetPurchased:
                    return PlayerPrefs.GetInt("MotoSim.Career.Owned.1", 0);
                case MissionMetric.AdventurePurchased:
                    return PlayerPrefs.GetInt("MotoSim.Career.Owned.2", 0);
                default: return 0;
            }
        }

        public static void SyncMilestones()
        {
            EnsureInitialized();
            for (int i = 0; i < Count; i++)
            {
                MissionDefinition mission = Mission(i);
                if (IsComplete(i) || Progress(i) < mission.Goal) continue;
                PlayerPrefs.SetInt(Prefix + mission.Id + ".Complete", 1);
                MotoCareerProgress.AddCredits(mission.RewardCredits);
                LastCompletedIndex = i;
                NotificationVersion++;
            }
        }

        public static int CompletedCount
        {
            get
            {
                int count = 0;
                for (int i = 0; i < Count; i++) if (IsComplete(i)) count++;
                return count;
            }
        }

        public static int NextOpenIndex
        {
            get
            {
                for (int i = 0; i < Count; i++) if (!IsComplete(i)) return i;
                return -1;
            }
        }
    }
}
