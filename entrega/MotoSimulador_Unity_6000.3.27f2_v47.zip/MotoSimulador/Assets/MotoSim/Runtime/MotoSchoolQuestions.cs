using System;
using UnityEngine;

namespace MotoSim.Unity
{
    /// <summary>One curriculum supplies both the narrated lessons and their original quiz items.</summary>
    public static class MotoSchoolQuestions
    {
        [Serializable] public sealed class LocalizedLine
        {
            public string pt, en, es;
            public string Current => MotoRegion.T(pt, en, es);
        }

        [Serializable] public sealed class Topic
        {
            public LocalizedLine title, narration, takeaway, prompt, explanation;
            public LocalizedLine[] answers;
            public int scene;
        }

        [Serializable] public sealed class Curriculum
        {
            public LocalizedLine arrivalTitle, arrival, arrivalTakeaway;
            public LocalizedLine examTitle, examIntro, examTakeaway;
            public Topic[] topics;
        }

        private static Curriculum cached;
        public static Curriculum Content
        {
            get
            {
                if (cached != null) return cached;
                TextAsset asset = Resources.Load<TextAsset>("MotoSim/School/Curriculum");
                if (asset == null) throw new InvalidOperationException("Curriculum.json não foi encontrado em Resources/MotoSim/School.");
                cached = JsonUtility.FromJson<Curriculum>(asset.text);
                if (cached == null || cached.topics == null || cached.topics.Length < 6)
                    throw new InvalidOperationException("O currículo da autoescola está incompleto.");
                foreach (Topic topic in cached.topics)
                    if (topic == null || topic.narration == null || topic.prompt == null || topic.answers == null || topic.answers.Length != 3)
                        throw new InvalidOperationException("Toda questão precisa da aula falada e de três respostas.");
                return cached;
            }
        }

        public static int Count => Content.topics.Length;
        public static int PassingScore => Mathf.CeilToInt(Count * .8f);
        public static int LessonCount => Count + 2;
        public static int SceneForLesson(int lesson) => lesson == 0 ? 0 : lesson == LessonCount - 1 ? 2 : Mathf.Clamp(Content.topics[lesson - 1].scene, 0, 2);
        public static string LessonTitle(int lesson) => lesson == 0 ? Content.arrivalTitle.Current :
            lesson == LessonCount - 1 ? Content.examTitle.Current : Content.topics[lesson - 1].title.Current;
        public static string LessonNarration(int lesson) => lesson == 0 ? Content.arrival.Current :
            lesson == LessonCount - 1 ? Content.examIntro.Current : Content.topics[lesson - 1].narration.Current;
        public static string LessonTakeaway(int lesson) => lesson == 0 ? Content.arrivalTakeaway.Current :
            lesson == LessonCount - 1 ? Content.examTakeaway.Current : Content.topics[lesson - 1].takeaway.Current;
        public static string Prompt(int index) => Content.topics[index].prompt.Current;
        public static string Answer(int index, int option) => Content.topics[index].answers[option].Current;
        public static string Explanation(int index) => Content.topics[index].explanation.Current;
        public static bool IsCorrect(int option) => option == 0;
    }
}
