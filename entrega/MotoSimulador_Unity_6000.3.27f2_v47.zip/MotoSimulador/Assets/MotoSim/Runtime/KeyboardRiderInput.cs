using System.Collections.Generic;
using UnityEngine;

namespace MotoSim.Unity
{
    [RequireComponent(typeof(MotorcycleController))]
    public sealed class KeyboardRiderInput : MonoBehaviour
    {
        private MotorcycleController motorcycle;
        private readonly HashSet<KeyCode> held = new HashSet<KeyCode>();
        private float touchThrottle, touchClutch, touchFrontBrake, touchRearBrake, touchSteering;
        private void Awake() => motorcycle = GetComponent<MotorcycleController>();

        public void SetTouchControls(float gas, float clutch, float frontBrake, float rearBrake, float steering)
        {
            touchThrottle = Mathf.Clamp01(gas);
            touchClutch = Mathf.Clamp01(clutch);
            touchFrontBrake = Mathf.Clamp01(frontBrake);
            touchRearBrake = Mathf.Clamp01(rearBrake);
            touchSteering = Mathf.Clamp(steering, -1f, 1f);
        }

        private void Update()
        {
            if (!motorcycle.IsReady) return;
#if ENABLE_LEGACY_INPUT_MANAGER
            ApplyControls(Input.GetKey(KeyCode.W) ? 1 : 0,
                Input.GetKey(KeyCode.LeftShift) ? 1 : 0, Input.GetKey(KeyCode.Space) ? 1 : 0,
                Input.GetKey(KeyCode.S) ? 1 : 0, (Input.GetKey(KeyCode.D) ? 1 : 0) - (Input.GetKey(KeyCode.A) ? 1 : 0));
            foreach (KeyCode key in new[] { KeyCode.I, KeyCode.E, KeyCode.Q, KeyCode.N, KeyCode.R,
                KeyCode.L, KeyCode.Z, KeyCode.X, KeyCode.H, KeyCode.B })
                if (Input.GetKeyDown(key)) Action(key);
#else
            // IMGUI input keeps this initial keyboard adapter usable in projects that select
            // the new Input System without adding a hard dependency on that package.
            ApplyControls(held.Contains(KeyCode.W) ? 1 : 0,
                held.Contains(KeyCode.LeftShift) ? 1 : 0, held.Contains(KeyCode.Space) ? 1 : 0,
                held.Contains(KeyCode.S) ? 1 : 0, (held.Contains(KeyCode.D) ? 1 : 0) - (held.Contains(KeyCode.A) ? 1 : 0));
#endif
        }
#if !ENABLE_LEGACY_INPUT_MANAGER
        private void OnGUI()
        {
            Event e = Event.current;
            if (e.type == EventType.KeyDown)
            {
                if (held.Add(e.keyCode) && motorcycle != null && motorcycle.IsReady) Action(e.keyCode);
                if (e.shift) held.Add(KeyCode.LeftShift);
            }
            else if (e.type == EventType.KeyUp)
            {
                held.Remove(e.keyCode);
                if (!e.shift) held.Remove(KeyCode.LeftShift);
            }
            if (motorcycle != null && motorcycle.IsReady && (e.type == EventType.KeyDown || e.type == EventType.KeyUp))
                ApplyControls(held.Contains(KeyCode.W) ? 1 : 0,
                    held.Contains(KeyCode.LeftShift) ? 1 : 0, held.Contains(KeyCode.Space) ? 1 : 0,
                    held.Contains(KeyCode.S) ? 1 : 0, (held.Contains(KeyCode.D) ? 1 : 0) - (held.Contains(KeyCode.A) ? 1 : 0));
        }
#endif

        private void ApplyControls(float gas, float clutch, float front, float rear, float steering)
        {
            motorcycle.SetControls(Mathf.Max(gas, touchThrottle), Mathf.Max(clutch, touchClutch),
                Mathf.Max(front, touchFrontBrake), Mathf.Max(rear, touchRearBrake),
                Mathf.Clamp(steering + touchSteering, -1f, 1f));
        }
        private void Action(KeyCode key)
        {
            if (key == KeyCode.E) motorcycle.RequestShift(1);
            if (key == KeyCode.Q) motorcycle.RequestShift(-1);
            if (key == KeyCode.N) motorcycle.RequestNeutral();
            if (key == KeyCode.I) motorcycle.RequestIgnitionToggle();
            if (key == KeyCode.R) motorcycle.ResetToStart();
            if (key == KeyCode.B) motorcycle.GetComponent<MotorcycleAudio>()?.PlayHorn();
            MotorcycleLighting lights = motorcycle.GetComponent<MotorcycleLighting>();
            if (lights == null) return;
            if (key == KeyCode.L) lights.ToggleHeadlamp();
            if (key == KeyCode.Z) lights.ToggleLeftSignal();
            if (key == KeyCode.X) lights.ToggleRightSignal();
            if (key == KeyCode.H) lights.ToggleHazards();
        }
        private void OnApplicationFocus(bool focused) { if (!focused) Clear(); }
        private void OnDisable() => Clear();
        private void Clear()
        {
            held.Clear();
            touchThrottle = touchClutch = touchFrontBrake = touchRearBrake = touchSteering = 0f;
            if (motorcycle != null) motorcycle.ClearInput();
        }
    }
}
