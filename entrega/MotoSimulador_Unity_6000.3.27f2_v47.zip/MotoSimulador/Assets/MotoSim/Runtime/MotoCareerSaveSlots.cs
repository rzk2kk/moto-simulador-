using System;
using MotoSim.Core;
using UnityEngine;

namespace MotoSim.Unity
{
    /// <summary>Three isolated career snapshots built on the game's existing PlayerPrefs keys.</summary>
    public static class MotoCareerSaveSlots
    {
        public const int SlotCount = 3;
        private const string Prefix = "MotoSim.SaveSlots.v1.";
        private const string ActiveKey = Prefix + "Active";
        private const string ReadyKey = Prefix + "Ready";
        private static bool booted;

        private static readonly string[] CoreInts = {
            "MotoSim.Career.Initialized.v1", "MotoSim.Career.Credits", "MotoSim.Career.DistanceCm",
            "MotoSim.Career.Owned.0", "MotoSim.Career.Owned.1", "MotoSim.Career.Owned.2",
            "MotoSim.Career.Paint.0", "MotoSim.Career.Paint.1", "MotoSim.Career.Paint.2",
            "MotoSim.GarageSelection", "MotoSim.HasProgress", "MotoSim.Career.TheoryPassed",
            "MotoSim.Career.PracticalPassed", "MotoSim.Career.PracticalActive", "MotoSim.Career.LessonIndex",
            "MotoSim.Missions.v1.Initialized", "MotoSim.Missions.v1.DistanceCm",
            "MotoSim.Missions.v1.HeadlightCm", "MotoSim.Missions.v1.SafeBestCm",
            "MotoSim.Missions.v1.SignalMask", "MotoSim.Missions.v1.ControlledStops"
        };

        private static string SlotKey(int slot, string key) => Prefix + slot + "." + key;
        public static int ActiveSlot => Mathf.Clamp(PlayerPrefs.GetInt(ActiveKey, -1), -1, SlotCount - 1);
        public static bool Exists(int slot) => slot >= 0 && slot < SlotCount &&
            PlayerPrefs.GetInt(Prefix + slot + ".Exists", 0) == 1;
        public static int GetInt(int slot, string key, int fallback = 0) =>
            PlayerPrefs.GetInt(SlotKey(slot, key), fallback);
        public static float GetFloat(int slot, string key, float fallback = 0f) =>
            PlayerPrefs.GetFloat(SlotKey(slot, key), fallback);
        public static string LastSaved(int slot) =>
            PlayerPrefs.GetString(Prefix + slot + ".SavedAt", "");

        public static void EnsureInitialized()
        {
            if (booted) return;
            booted = true;
            if (PlayerPrefs.GetInt(ReadyKey, 0) != 1)
            {
                bool legacy = PlayerPrefs.GetInt("MotoSim.HasProgress", 0) == 1 ||
                    PlayerPrefs.GetInt("MotoSim.Career.LessonIndex", 0) > 0 ||
                    PlayerPrefs.GetInt("MotoSim.Career.Credits", 0) > 0 ||
                    PlayerPrefs.GetInt("MotoSim.Career.PracticalPassed", 0) == 1 ||
                    PlayerPrefs.GetInt("MotoSim.Career.Owned.1", 0) == 1 ||
                    PlayerPrefs.GetInt("MotoSim.Career.Owned.2", 0) == 1;
                if (legacy)
                {
                    PlayerPrefs.SetInt(Prefix + "0.Exists", 1);
                    PlayerPrefs.SetInt(ActiveKey, 0);
                    CopyLiveToSlot(0);
                }
                else PlayerPrefs.SetInt(ActiveKey, -1);
                PlayerPrefs.SetInt(ReadyKey, 1);
                PlayerPrefs.Save();
            }
            int active = ActiveSlot;
            if (Exists(active)) RestoreToLive(active);
        }

        public static bool CreateNew(int slot)
        {
            EnsureInitialized();
            if (slot < 0 || slot >= SlotCount || Exists(slot)) return false;
            SaveActive();
            PlayerPrefs.SetInt(ActiveKey, slot);
            MotoCareerProgress.StartNewCareer();
            PlayerPrefs.SetFloat("MotoSim.Career.PlaySeconds", 0f);
            PlayerPrefs.SetInt(Prefix + slot + ".Exists", 1);
            SaveActive();
            return true;
        }

        public static bool Load(int slot)
        {
            EnsureInitialized();
            if (!Exists(slot)) return false;
            if (slot != ActiveSlot)
            {
                MotoMissionBoard.EndRide();
                SaveActive();
                PlayerPrefs.SetInt(ActiveKey, slot);
                RestoreToLive(slot);
                PlayerPrefs.Save();
            }
            return true;
        }

        public static void SaveActive()
        {
            EnsureInitialized();
            int active = ActiveSlot;
            if (!Exists(active)) return;
            CopyLiveToSlot(active);
            PlayerPrefs.SetString(Prefix + active + ".SavedAt", DateTime.UtcNow.Ticks.ToString());
            PlayerPrefs.Save();
        }

        public static bool Delete(int slot)
        {
            EnsureInitialized();
            if (!Exists(slot)) return false;
            if (slot == ActiveSlot) MotoMissionBoard.EndRide();
            foreach (string key in CoreInts) PlayerPrefs.DeleteKey(SlotKey(slot, key));
            foreach (MissionDefinition mission in MissionCatalog.All)
                PlayerPrefs.DeleteKey(SlotKey(slot, "MotoSim.Missions.v1." + mission.Id + ".Complete"));
            foreach (string key in new[] { "MotoSim.SelectedBike", "MotoSim.Career.PlaySeconds" })
                PlayerPrefs.DeleteKey(SlotKey(slot, key));
            for (int bike = 0; bike < 3; bike++)
                foreach (string part in new[] { ".H", ".S", ".V" })
                    PlayerPrefs.DeleteKey(SlotKey(slot, "MotoSim.Career.CustomPaint." + bike + part));
            PlayerPrefs.DeleteKey(Prefix + slot + ".Exists");
            PlayerPrefs.DeleteKey(Prefix + slot + ".SavedAt");
            if (slot == ActiveSlot)
            {
                PlayerPrefs.SetInt(ActiveKey, -1);
                MotoCareerProgress.StartNewCareer();
                PlayerPrefs.SetFloat("MotoSim.Career.PlaySeconds", 0f);
            }
            PlayerPrefs.Save();
            return true;
        }

        private static void CopyLiveToSlot(int slot)
        {
            foreach (string key in CoreInts) CopyInt(key, SlotKey(slot, key));
            foreach (MissionDefinition mission in MissionCatalog.All)
            {
                string key = "MotoSim.Missions.v1." + mission.Id + ".Complete";
                CopyInt(key, SlotKey(slot, key));
            }
            CopyString("MotoSim.SelectedBike", SlotKey(slot, "MotoSim.SelectedBike"));
            CopyFloat("MotoSim.Career.PlaySeconds", SlotKey(slot, "MotoSim.Career.PlaySeconds"));
            for (int bike = 0; bike < 3; bike++)
                foreach (string part in new[] { ".H", ".S", ".V" })
                {
                    string key = "MotoSim.Career.CustomPaint." + bike + part;
                    CopyFloat(key, SlotKey(slot, key));
                }
        }

        private static void RestoreToLive(int slot)
        {
            foreach (string key in CoreInts) CopyInt(SlotKey(slot, key), key);
            foreach (MissionDefinition mission in MissionCatalog.All)
            {
                string key = "MotoSim.Missions.v1." + mission.Id + ".Complete";
                CopyInt(SlotKey(slot, key), key);
            }
            CopyString(SlotKey(slot, "MotoSim.SelectedBike"), "MotoSim.SelectedBike");
            CopyFloat(SlotKey(slot, "MotoSim.Career.PlaySeconds"), "MotoSim.Career.PlaySeconds");
            for (int bike = 0; bike < 3; bike++)
                foreach (string part in new[] { ".H", ".S", ".V" })
                {
                    string key = "MotoSim.Career.CustomPaint." + bike + part;
                    CopyFloat(SlotKey(slot, key), key);
                }
            PlayerPrefs.Save();
        }

        private static void CopyInt(string source, string destination)
        {
            if (PlayerPrefs.HasKey(source)) PlayerPrefs.SetInt(destination, PlayerPrefs.GetInt(source));
            else PlayerPrefs.DeleteKey(destination);
        }
        private static void CopyFloat(string source, string destination)
        {
            if (PlayerPrefs.HasKey(source)) PlayerPrefs.SetFloat(destination, PlayerPrefs.GetFloat(source));
            else PlayerPrefs.DeleteKey(destination);
        }
        private static void CopyString(string source, string destination)
        {
            if (PlayerPrefs.HasKey(source)) PlayerPrefs.SetString(destination, PlayerPrefs.GetString(source));
            else PlayerPrefs.DeleteKey(destination);
        }
    }

    public sealed class MotoCareerAutoSave : MonoBehaviour
    {
        private static MotoCareerAutoSave instance;
        private float nextSave;

        private void Awake()
        {
            if (instance != null && instance != this) { Destroy(gameObject); return; }
            instance = this;
            DontDestroyOnLoad(gameObject);
            MotoCareerSaveSlots.EnsureInitialized();
            nextSave = Time.unscaledTime + 3f;
        }

        private void Update()
        {
            if (MotoCareerSaveSlots.ActiveSlot < 0 || PlayerPrefs.GetInt("MotoSim.TestRidePreview", 0) == 1) return;
            PlayerPrefs.SetFloat("MotoSim.Career.PlaySeconds",
                PlayerPrefs.GetFloat("MotoSim.Career.PlaySeconds", 0f) + Time.unscaledDeltaTime);
            if (Time.unscaledTime < nextSave) return;
            MotoCareerSaveSlots.SaveActive();
            nextSave = Time.unscaledTime + 3f;
        }

        private void OnApplicationPause(bool paused) { if (paused) MotoCareerSaveSlots.SaveActive(); }
        private void OnApplicationQuit() => MotoCareerSaveSlots.SaveActive();
    }
}
