using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace MotoSim.Editor
{
    /// <summary>Builds a single continuous, one-way motorcycle training course for the riding test scene.</summary>
    internal static class TrainingCourseBuilder
    {
        private const string Generated = "Assets/MotoSim/Generated";
        private const string Materials = Generated + "/Materials";
        private const float RoadWidth = 4.4f;
        private static Material groundMaterial, roadMaterial, lineMaterial, yellowMaterial, coneMaterial, beamMaterial;
        private static Material shoulderMaterial;

        internal static void Build()
        {
            // Free riding is a simple, enclosed place to feel each motorcycle.
            // The marked examination course is created only in PrepareSchoolProject.
            EnclosedMotorcycleSite.BuildTestLot();
        }

        private static void ScaleGeneratedCourse(Scene scene, HashSet<GameObject> originalRoots)
        {
            const float horizontalScale = 3f;
            Vector3 origin = new Vector3(0f, 0f, -3f);
            foreach (GameObject root in scene.GetRootGameObjects())
            {
                if (originalRoots.Contains(root)) continue;
                Transform[] transforms = root.GetComponentsInChildren<Transform>(true);
                var originalPositions = new Vector3[transforms.Length];
                for (int i = 0; i < transforms.Length; i++) originalPositions[i] = transforms[i].position;
                for (int i = 0; i < transforms.Length; i++)
                {
                    Transform item = transforms[i];
                    Vector3 position = originalPositions[i];
                    item.position = origin + new Vector3(
                        (position.x - origin.x) * horizontalScale,
                        position.y - origin.y,
                        (position.z - origin.z) * horizontalScale);

                    if (!IsTrackSurface(item.name)) continue;
                    Vector3 scale = item.localScale;
                    item.localScale = new Vector3(scale.x * horizontalScale, scale.y, scale.z * horizontalScale);
                    MeshCollider meshCollider = item.GetComponent<MeshCollider>();
                    if (meshCollider != null)
                    {
                        Mesh mesh = meshCollider.sharedMesh;
                        meshCollider.sharedMesh = null;
                        meshCollider.sharedMesh = mesh;
                    }
                }
            }
            Debug.Log("MotoSim: pista ampliada 3x na horizontal; objetos e alturas mantidos na escala original.");
        }

        private static bool IsTrackSurface(string name) =>
            name == "Pavimento_Amplo_Da_Autoescola" || name == "Pista_Continua_Mao_Unica" ||
            name == "Terreno_Grama_Ondulado" || name == "Superficie_Rodagem_Asfalto_Continua" ||
            name.StartsWith("Acostamentos_") || name == "Faixas_Borda_Brancas" ||
            name.StartsWith("Faixa_Borda_") || name.StartsWith("Faixa_Rampa_Amarela_") ||
            name.StartsWith("Marca_Frenagem_") || name.StartsWith("Faixa_Frenagem_") ||
            name.StartsWith("Seta_Unica_") || name == "Seta_Sentido_Unico";

        private static bool CreateDetailedBlenderCourse()
        {
            const string modelPath = "Assets/MotoSim/Art/Pista_Autoescola_Detalhada.fbx";
            ModelImporter importer = AssetImporter.GetAtPath(modelPath) as ModelImporter;
            if (importer != null && !importer.isReadable)
            {
                importer.isReadable = true;
                importer.SaveAndReimport();
            }
            GameObject model = AssetDatabase.LoadAssetAtPath<GameObject>(modelPath);
            if (model == null)
            {
                Debug.LogWarning("Pista Blender não encontrada; usando a pista procedural básica.");
                return false;
            }

            var course = PrefabUtility.InstantiatePrefab(model, SceneManager.GetActiveScene()) as GameObject;
            if (course == null) throw new System.InvalidOperationException("Não foi possível instanciar a pista do Blender.");
            course.name = "Circuito_Autoescola_Blender_Detalhado";
            course.transform.SetPositionAndRotation(Vector3.zero, Quaternion.identity);
            course.transform.localScale = Vector3.one;

            bool hasRoad = false, hasTerrain = false;
            foreach (MeshFilter filter in course.GetComponentsInChildren<MeshFilter>(true))
            {
                if (filter.sharedMesh == null) continue;
                string part = filter.gameObject.name;
                if (part == "Superficie_Rodagem_Asfalto_Continua") EnsureRoadFacesPointUp(filter);
                MeshRenderer renderer = filter.GetComponent<MeshRenderer>();
                Material material = CourseMaterial(part);
                if (renderer != null && material != null)
                {
                    var materials = new Material[Mathf.Max(1, renderer.sharedMaterials.Length)];
                    for (int i = 0; i < materials.Length; i++) materials[i] = material;
                    renderer.sharedMaterials = materials;
                }

                bool colliderSurface = part == "Terreno_Grama_Ondulado" ||
                    part == "Superficie_Rodagem_Asfalto_Continua" || part == "Faixa_Equilibrio_Continua" ||
                    part.StartsWith("Acostamentos_");
                bool isCone = part.StartsWith("Cone_") || part.StartsWith("Marco_Oito_");
                bool solidProp = part.StartsWith("Portal_") || part.StartsWith("Travessa_Portal_") ||
                    part.StartsWith("Balizador_") || part.StartsWith("Placa_Terreno_");
                if (colliderSurface || isCone || solidProp)
                {
                    MeshCollider collider = filter.GetComponent<MeshCollider>();
                    if (collider == null) collider = filter.gameObject.AddComponent<MeshCollider>();
                    collider.sharedMesh = filter.sharedMesh;
                    collider.convex = !colliderSurface;
                    if (isCone)
                    {
                        // Slalom markers can be hit and toppled instead of acting as
                        // immovable triangle-mesh walls.
                        Rigidbody marker = filter.GetComponent<Rigidbody>();
                        if (marker == null) marker = filter.gameObject.AddComponent<Rigidbody>();
                        marker.mass = .35f;
                        marker.interpolation = RigidbodyInterpolation.Interpolate;
                        marker.collisionDetectionMode = CollisionDetectionMode.Continuous;
                    }
                }
                hasRoad |= part == "Superficie_Rodagem_Asfalto_Continua";
                hasTerrain |= part == "Terreno_Grama_Ondulado";
            }
            if (!hasRoad || !hasTerrain)
                throw new System.InvalidOperationException("A pista Blender está sem malha de asfalto ou terreno físico.");
            return true;
        }

        private static void EnsureRoadFacesPointUp(MeshFilter filter)
        {
            Mesh source = filter.sharedMesh;
            Vector3[] vertices = source.vertices;
            float upwardArea = 0f, downwardArea = 0f;
            for (int submesh = 0; submesh < source.subMeshCount; submesh++)
            {
                int[] triangles = source.GetTriangles(submesh);
                for (int i = 0; i < triangles.Length; i += 3)
                {
                    Vector3 a = filter.transform.TransformPoint(vertices[triangles[i]]);
                    Vector3 b = filter.transform.TransformPoint(vertices[triangles[i + 1]]);
                    Vector3 c = filter.transform.TransformPoint(vertices[triangles[i + 2]]);
                    float verticalArea = Vector3.Cross(b - a, c - a).y;
                    if (verticalArea > 0f) upwardArea += verticalArea;
                    else downwardArea -= verticalArea;
                }
            }
            if (downwardArea <= upwardArea * 2f) return;

            Mesh corrected = Object.Instantiate(source);
            corrected.name = "Pista_Asfalto_Faces_Cima";
            for (int submesh = 0; submesh < corrected.subMeshCount; submesh++)
            {
                int[] triangles = corrected.GetTriangles(submesh);
                for (int i = 0; i < triangles.Length; i += 3)
                {
                    int second = triangles[i + 1];
                    triangles[i + 1] = triangles[i + 2];
                    triangles[i + 2] = second;
                }
                corrected.SetTriangles(triangles, submesh, false);
            }
            corrected.RecalculateNormals();
            corrected.RecalculateBounds();
            filter.sharedMesh = SaveMesh(corrected, Generated + "/Pista_Asfalto_Faces_Cima.asset");
            Debug.Log("MotoSim: corrigi as faces invertidas do asfalto para a roda ter contato físico com a pista.");
        }

        private static Material CourseMaterial(string part)
        {
            if (part == "Terreno_Grama_Ondulado") return groundMaterial;
            if (part == "Superficie_Rodagem_Asfalto_Continua") return roadMaterial;
            if (part.StartsWith("Acostamentos_"))
                return shoulderMaterial;
            if (part == "Faixa_Equilibrio_Continua") return beamMaterial;
            if (part.StartsWith("Cone_") || part.StartsWith("Marco_Oito_")) return coneMaterial;
            if (part.StartsWith("Faixa_Rampa_Amarela") || part.StartsWith("Balizador_") ||
                part.StartsWith("Portal_") || part.StartsWith("Travessa_Portal_")) return yellowMaterial;
            if (part.StartsWith("Faixas_Borda_") || part.StartsWith("Seta_Unica_") ||
                part.StartsWith("Marca_Frenagem_")) return lineMaterial;
            if (part.StartsWith("Placa_Terreno_")) return roadMaterial;
            if (part.StartsWith("Etapa_") || part == "Titulo_Circuito") return lineMaterial;
            return null;
        }

        private static List<Vector3> BuildCenterline()
        {
            var points = new List<Vector3>();
            AppendLine(points, new Vector3(0, 0, -3), new Vector3(0, 0, 29), 16);

            // The figure-eight is a real continuous line in the route. Its arrows follow
            // the path tangent; it is not a second lane or a two-way loop.
            const float radius = 4.8f;
            const float centerZ = 38f;
            float rotation = -Mathf.Atan(.5f);
            for (int i = 0; i <= 160; i++)
            {
                float t = i / 160f * Mathf.PI * 2f;
                float localX = radius * Mathf.Sin(t);
                float localZ = radius * Mathf.Sin(2f * t);
                float x = Mathf.Cos(rotation) * localX + Mathf.Sin(rotation) * localZ;
                float z = -Mathf.Sin(rotation) * localX + Mathf.Cos(rotation) * localZ;
                AddPoint(points, new Vector3(x, 0, centerZ + z));
            }

            AppendLine(points, new Vector3(0, 0, centerZ), new Vector3(0, 0, 72), 32);

            // Broad quarter turn from northbound to eastbound, then one-way finish straight.
            const float turnRadius = 8f;
            for (int i = 1; i <= 40; i++)
            {
                float angle = i / 40f * Mathf.PI * .5f;
                AddPoint(points, new Vector3(turnRadius * (1f - Mathf.Cos(angle)), 0,
                    72f + turnRadius * Mathf.Sin(angle)));
            }
            AppendLine(points, new Vector3(8, 0, 80), new Vector3(23, 0, 80), 12);
            return points;
        }

        private static void CreateGround()
        {
            var ground = new GameObject("Pavimento_Amplo_Da_Autoescola");
            var mesh = new Mesh { name = "Pavimento_Amplo_Da_Autoescola" };
            mesh.vertices = new[] { new Vector3(-30, 0, -18), new Vector3(-30, 0, 98),
                new Vector3(30, 0, 98), new Vector3(30, 0, -18) };
            mesh.triangles = new[] { 0, 1, 2, 0, 2, 3 };
            mesh.uv = new[] { Vector2.zero, Vector2.up, Vector2.one, Vector2.right };
            mesh.RecalculateNormals(); mesh.RecalculateBounds();
            mesh = SaveMesh(mesh, Generated + "/Pavimento_Autoescola.asset");
            ground.AddComponent<MeshFilter>().sharedMesh = mesh;
            ground.AddComponent<MeshRenderer>().sharedMaterial = groundMaterial;
            var collider = ground.AddComponent<BoxCollider>();
            collider.center = new Vector3(0, -.1f, 40);
            collider.size = new Vector3(60, .2f, 116);
        }

        private static void CreateRibbon(string name, List<Vector3> path, float width, float y, Material material)
        {
            var vertices = new Vector3[path.Count * 2];
            var uv = new Vector2[vertices.Length];
            var triangles = new int[(path.Count - 1) * 6];
            float distance = 0;
            for (int i = 0; i < path.Count; i++)
            {
                Vector3 tangent = Tangent(path, i);
                Vector3 side = Vector3.Cross(Vector3.up, tangent).normalized;
                Vector3 center = path[i] + Vector3.up * y;
                vertices[i * 2] = center - side * (width * .5f);
                vertices[i * 2 + 1] = center + side * (width * .5f);
                if (i > 0) distance += Vector3.Distance(path[i - 1], path[i]);
                uv[i * 2] = new Vector2(0, distance);
                uv[i * 2 + 1] = new Vector2(1, distance);
            }
            int ti = 0;
            for (int i = 0; i < path.Count - 1; i++)
            {
                int a = i * 2, b = a + 1, c = a + 2, d = a + 3;
                triangles[ti++] = a; triangles[ti++] = c; triangles[ti++] = d;
                triangles[ti++] = a; triangles[ti++] = d; triangles[ti++] = b;
            }
            var mesh = new Mesh { name = name };
            mesh.vertices = vertices; mesh.uv = uv; mesh.triangles = triangles;
            mesh.RecalculateNormals(); mesh.RecalculateBounds();
            mesh = SaveMesh(mesh, Generated + "/" + name + ".asset");
            var obj = new GameObject(name);
            obj.AddComponent<MeshFilter>().sharedMesh = mesh;
            obj.AddComponent<MeshRenderer>().sharedMaterial = material;
        }

        private static void CreateEdgeLine(string name, List<Vector3> path, float sideOffset, float width, float y)
        {
            var vertices = new Vector3[path.Count * 2];
            var uv = new Vector2[vertices.Length];
            var triangles = new int[(path.Count - 1) * 6];
            float distance = 0;
            for (int i = 0; i < path.Count; i++)
            {
                Vector3 side = Vector3.Cross(Vector3.up, Tangent(path, i)).normalized;
                Vector3 center = path[i] + side * sideOffset + Vector3.up * y;
                vertices[i * 2] = center - side * (width * .5f);
                vertices[i * 2 + 1] = center + side * (width * .5f);
                if (i > 0) distance += Vector3.Distance(path[i - 1], path[i]);
                uv[i * 2] = new Vector2(0, distance);
                uv[i * 2 + 1] = new Vector2(1, distance);
            }
            int ti = 0;
            for (int i = 0; i < path.Count - 1; i++)
            {
                int a = i * 2;
                triangles[ti++] = a; triangles[ti++] = a + 2; triangles[ti++] = a + 3;
                triangles[ti++] = a; triangles[ti++] = a + 3; triangles[ti++] = a + 1;
            }
            var mesh = new Mesh { name = name };
            mesh.vertices = vertices; mesh.uv = uv; mesh.triangles = triangles;
            mesh.RecalculateNormals(); mesh.RecalculateBounds();
            mesh = SaveMesh(mesh, Generated + "/" + name + ".asset");
            var obj = new GameObject(name);
            obj.AddComponent<MeshFilter>().sharedMesh = mesh;
            obj.AddComponent<MeshRenderer>().sharedMaterial = lineMaterial;
        }

        private static void CreateForwardArrows(List<Vector3> path)
        {
            // Repeated simple arrows aid route reading. Each one uses the forward tangent,
            // including around the eight and the final bend.
            float nextDistance = 5f, distance = 0;
            int arrowIndex = 0;
            for (int i = 1; i < path.Count - 1; i++)
            {
                distance += Vector3.Distance(path[i - 1], path[i]);
                if (distance < nextDistance) continue;
                nextDistance += 5f;
                Vector3 direction = Tangent(path, i);
                Vector3 side = Vector3.Cross(Vector3.up, direction).normalized;
                Vector3 center = path[i] + Vector3.up * .035f;
                Vector3 tip = center + direction * .48f;
                Vector3 rear = center - direction * .25f;
                Vector3[] v = { tip, rear + side * .2f, rear + direction * .08f,
                    rear - side * .2f, rear + direction * .08f };
                int[] tris = { 0, 1, 2, 0, 2, 3, 0, 3, 4 };
                var mesh = new Mesh { name = "Seta_Sentido_Unico" };
                mesh.vertices = v; mesh.triangles = tris; mesh.RecalculateNormals();
                mesh = SaveMesh(mesh, Generated + "/Seta_Sentido_Unico_" + arrowIndex.ToString("000") + ".asset");
                var arrow = new GameObject("Seta_Sentido_Unico");
                arrow.AddComponent<MeshFilter>().sharedMesh = mesh;
                arrow.AddComponent<MeshRenderer>().sharedMaterial = lineMaterial;
                arrowIndex++;
            }
        }

        private static void CreateSlalomCones()
        {
            // The straight course stays straight; cones form one straight visual row along
            // its inside edge, leaving a clear rideable line beside them.
            for (int i = 0; i < 8; i++) CreateCone(new Vector3(-1.45f, .015f, 2.5f + i * 2.15f), "Cone_Slalom_" + (i + 1));
        }

        private static void CreateBalanceBeam()
        {
            var beam = GameObject.CreatePrimitive(PrimitiveType.Cube);
            beam.name = "Faixa_Equilibrio_Estreita";
            beam.transform.position = new Vector3(0, .065f, 25.5f);
            beam.transform.localScale = new Vector3(.78f, .12f, 6f);
            beam.GetComponent<Renderer>().sharedMaterial = beamMaterial;
            beam.GetComponent<Collider>().sharedMaterial = null;
        }

        private static void CreateEightMarkers()
        {
            CreateCone(new Vector3(-2.2f, .015f, 38f), "Marco_Oito_Esquerdo");
            CreateCone(new Vector3(2.2f, .015f, 38f), "Marco_Oito_Direito");
        }

        private static void CreateBrakingMarkers()
        {
            for (int i = 0; i < 4; i++)
            {
                var stripe = GameObject.CreatePrimitive(PrimitiveType.Cube);
                stripe.name = "Faixa_Frenagem_" + (i + 1);
                stripe.transform.position = new Vector3(0, .032f, 53f + i * .42f);
                stripe.transform.localScale = new Vector3(RoadWidth - .2f, .025f, .12f);
                stripe.GetComponent<Renderer>().sharedMaterial = lineMaterial;
                UnityEngine.Object.DestroyImmediate(stripe.GetComponent<Collider>());
            }
        }

        private static void CreateRamp()
        {
            // A shallow speed-control hump spans the entire lane, inline with travel.
            float[] z = { 61.4f, 62.0f, 63.0f, 64.0f, 64.6f };
            float[] y = { .015f, .09f, .16f, .09f, .015f };
            var vertices = new Vector3[z.Length * 2];
            var triangles = new int[(z.Length - 1) * 6];
            for (int i = 0; i < z.Length; i++)
            {
                vertices[i * 2] = new Vector3(-RoadWidth * .5f, y[i], z[i]);
                vertices[i * 2 + 1] = new Vector3(RoadWidth * .5f, y[i], z[i]);
            }
            int ti = 0;
            for (int i = 0; i < z.Length - 1; i++)
            {
                int a = i * 2;
                triangles[ti++] = a; triangles[ti++] = a + 2; triangles[ti++] = a + 3;
                triangles[ti++] = a; triangles[ti++] = a + 3; triangles[ti++] = a + 1;
            }
            var mesh = new Mesh { name = "Rampa_Baixa_Inline" };
            mesh.vertices = vertices; mesh.triangles = triangles; mesh.RecalculateNormals(); mesh.RecalculateBounds();
            mesh = SaveMesh(mesh, Generated + "/Rampa_Baixa_Inline.asset");
            var ramp = new GameObject("Rampa_Baixa_Atravessando_A_Pista");
            ramp.AddComponent<MeshFilter>().sharedMesh = mesh;
            ramp.AddComponent<MeshRenderer>().sharedMaterial = yellowMaterial;
            ramp.AddComponent<MeshCollider>().sharedMesh = mesh;
        }

        private static void CreateStartFinish()
        {
            CreateGate("PORTAO_INICIO", new Vector3(0, 0, -2.5f));
            CreateGate("PORTAO_CHEGADA", new Vector3(23, 0, 80), true);
        }

        private static void CreateGate(string name, Vector3 center, bool eastbound = false)
        {
            for (int side = -1; side <= 1; side += 2)
            {
                var post = GameObject.CreatePrimitive(PrimitiveType.Cube);
                post.name = name + (side < 0 ? "_E" : "_D");
                post.transform.position = center + (eastbound ? new Vector3(0, .55f, side * 2.15f) : new Vector3(side * 2.15f, .55f, 0));
                post.transform.localScale = new Vector3(.14f, 1.1f, .14f);
                post.GetComponent<Renderer>().sharedMaterial = yellowMaterial;
                UnityEngine.Object.DestroyImmediate(post.GetComponent<Collider>());
            }
        }

        private static void CreateCourseSigns()
        {
            CreateSign("01  INÍCIO", new Vector3(3.3f, 1.1f, -2.5f));
            CreateSign("02  SLALOM", new Vector3(3.3f, 1.1f, 8));
            CreateSign("03  EQUILÍBRIO", new Vector3(3.3f, 1.1f, 25));
            CreateSign("04  OITO", new Vector3(6.3f, 1.1f, 38));
            CreateSign("05  FRENAGEM", new Vector3(3.3f, 1.1f, 53));
            CreateSign("06  RAMPA", new Vector3(3.3f, 1.1f, 63));
            CreateSign("07  CURVA CONTROLADA", new Vector3(12f, 1.1f, 84));
            CreateSign("08  CHEGADA", new Vector3(23f, 1.1f, 84));
        }

        private static void CreateSign(string text, Vector3 position)
        {
            var sign = new GameObject("Placa_" + text.Replace(' ', '_'));
            sign.transform.position = position;
            sign.transform.rotation = Quaternion.Euler(0, 180, 0);
            var tm = sign.AddComponent<TextMesh>();
            tm.text = text; tm.characterSize = .22f; tm.fontSize = 48;
            tm.anchor = TextAnchor.MiddleCenter; tm.alignment = TextAlignment.Center;
            tm.color = Color.white;
        }

        private static void CreateCone(Vector3 position, string name)
        {
            const int segments = 12;
            const float baseRadius = .16f, middleRadius = .095f, height = .44f;
            var vertices = new Vector3[segments * 2 + 2];
            for (int i = 0; i < segments; i++)
            {
                float angle = i / (float)segments * Mathf.PI * 2f;
                vertices[i] = new Vector3(Mathf.Cos(angle) * baseRadius, 0, Mathf.Sin(angle) * baseRadius);
                vertices[segments + i] = new Vector3(Mathf.Cos(angle) * middleRadius, height * .55f, Mathf.Sin(angle) * middleRadius);
            }
            vertices[segments * 2] = new Vector3(0, height, 0);
            vertices[segments * 2 + 1] = Vector3.zero;
            var triangles = new List<int>();
            for (int i = 0; i < segments; i++)
            {
                int next = (i + 1) % segments;
                triangles.Add(i); triangles.Add(next); triangles.Add(segments + next);
                triangles.Add(i); triangles.Add(segments + next); triangles.Add(segments + i);
                triangles.Add(segments + i); triangles.Add(segments + next); triangles.Add(segments * 2);
                triangles.Add(segments * 2 + 1); triangles.Add(next); triangles.Add(i);
            }
            var mesh = new Mesh { name = name + "_Mesh" };
            mesh.vertices = vertices; mesh.triangles = triangles.ToArray(); mesh.RecalculateNormals(); mesh.RecalculateBounds();
            mesh = SaveMesh(mesh, Generated + "/" + name + "_Mesh.asset");
            var cone = new GameObject(name); cone.transform.position = position;
            cone.AddComponent<MeshFilter>().sharedMesh = mesh;
            cone.AddComponent<MeshRenderer>().sharedMaterial = coneMaterial;
            // Practice markers are visual-only so a missed cone cannot launch the bike.
        }

        private static void AppendLine(List<Vector3> points, Vector3 from, Vector3 to, int count)
        {
            for (int i = points.Count == 0 ? 0 : 1; i <= count; i++)
                AddPoint(points, Vector3.Lerp(from, to, i / (float)count));
        }

        private static void AddPoint(List<Vector3> points, Vector3 point)
        {
            if (points.Count == 0 || (points[points.Count - 1] - point).sqrMagnitude > .0001f) points.Add(point);
        }

        private static Vector3 Tangent(List<Vector3> path, int i)
        {
            Vector3 delta = path[Mathf.Min(path.Count - 1, i + 1)] - path[Mathf.Max(0, i - 1)];
            delta.y = 0;
            return delta.sqrMagnitude < .000001f ? Vector3.forward : delta.normalized;
        }

        private static void EnsureMaterials()
        {
            groundMaterial = Material("Pista_Base_Grafite", new Color(.12f, .13f, .14f), .08f);
            roadMaterial = Material("Pista_Asfalto_Concreto", new Color(.2f, .21f, .22f), .12f);
            shoulderMaterial = Material("Pista_Acostamento_Terra", new Color(.31f, .26f, .18f), .92f);
            SetTexture(groundMaterial, "Assets/MotoSim/Art/Textures/Pista_Grama.png");
            SetTexture(roadMaterial, "Assets/MotoSim/Art/Textures/Pista_Asfalto.png");
            SetTexture(shoulderMaterial, "Assets/MotoSim/Art/Textures/Pista_Terra.png");
            lineMaterial = Material("Pista_Marcacao_Branca", new Color(.92f, .94f, .95f), .18f);
            yellowMaterial = Material("Pista_Sinalizacao_Amarela", new Color(1f, .66f, .03f), .25f);
            coneMaterial = Material("Pista_Cone_Laranja", new Color(1f, .22f, .025f), .22f);
            beamMaterial = Material("Pista_Equilibrio_Metal", new Color(.62f, .46f, .12f), .48f);
        }

        private static void SetTexture(Material material, string path)
        {
            Texture2D texture = AssetDatabase.LoadAssetAtPath<Texture2D>(path);
            if (texture != null && material.HasProperty("_BaseMap"))
            {
                material.SetTexture("_BaseMap", texture);
                material.SetTextureScale("_BaseMap", Vector2.one);
            }
        }

        private static Material Material(string name, Color color, float smoothness)
        {
            string path = Materials + "/" + name + ".mat";
            Material material = AssetDatabase.LoadAssetAtPath<Material>(path);
            if (material != null) return material;
            Shader shader = Shader.Find("Universal Render Pipeline/Lit");
            if (shader == null) shader = Shader.Find("Standard");
            material = new Material(shader) { name = name };
            if (material.HasProperty("_BaseColor")) material.SetColor("_BaseColor", color);
            else material.color = color;
            if (material.HasProperty("_Smoothness")) material.SetFloat("_Smoothness", smoothness);
            AssetDatabase.CreateAsset(material, path);
            return material;
        }

        private static Mesh SaveMesh(Mesh mesh, string path)
        {
            Mesh existing = AssetDatabase.LoadAssetAtPath<Mesh>(path);
            if (existing == null)
            {
                AssetDatabase.CreateAsset(mesh, path);
                return mesh;
            }
            else
            {
                EditorUtility.CopySerialized(mesh, existing);
                UnityEngine.Object.DestroyImmediate(mesh);
                EditorUtility.SetDirty(existing);
                return existing;
            }
        }
    }
}
