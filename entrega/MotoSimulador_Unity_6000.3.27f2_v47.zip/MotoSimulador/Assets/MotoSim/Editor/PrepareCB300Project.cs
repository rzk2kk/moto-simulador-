using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using MotoSim.Core;
using MotoSim.Unity;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.SceneManagement;

namespace MotoSim.Editor
{
    /// <summary>Creates the CB300 Twister riding scene using the same MotoSim input, camera, audio and physics systems.</summary>
    public static class PrepareCB300Project
    {
        internal const string ScenePath = "Assets/MotoSim/Generated/CB300_Twister_TesteFisico.unity";
        private const string ModelPath = "Assets/MotoSim/Art/CB300_Twister_MotoSim.fbx";
        private const string Generated = "Assets/MotoSim/Generated";
        private const string SessionKey = "MotoSim.CB300SetupAttempted_v1";
        private static string Root => Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
        private static string Completion => Path.Combine(Root, "ProjectSettings/MotoSimCB300Setup.json");

        internal static void TryAutomaticSetup()
        {
            if (File.Exists(Completion) && AssetDatabase.LoadAssetAtPath<SceneAsset>(ScenePath) != null)
            {
                var active = SceneManager.GetActiveScene();
                if (active.IsValid() && !active.isDirty && string.IsNullOrEmpty(active.path))
                    PrepareInspectionProject.OpenPreparedScene(ScenePath);
                return;
            }
            if (SessionState.GetBool(SessionKey, false)) return;
            SessionState.SetBool(SessionKey, true);
            RunSetup();
        }

        [MenuItem("MotoSim/Abrir Honda CB 300 Twister")]
        public static void RunSetup()
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode || EditorApplication.isCompiling || EditorApplication.isUpdating)
            {
                EditorApplication.isPlaying = false;
                EditorApplication.delayCall += RunSetup;
                return;
            }
            try
            {
                PrepareInspectionProject.EnsureFolder("Assets/MotoSim", "Generated");
                PrepareInspectionProject.EnsureFolder(Generated, "Materials");
                PrepareInspectionProject.ConfigurePipeline();
                if (AssetDatabase.LoadAssetAtPath<SceneAsset>(ScenePath) == null) CreateScene();
                else PrepareInspectionProject.OpenPreparedScene(ScenePath);
                Scene scene = SceneManager.GetSceneByPath(ScenePath);
                if (!PrepareInspectionProject.HasGameCamera(scene))
                    throw new InvalidOperationException("A cena da CB 300 não tem uma câmera de jogo ativa.");
                AssetDatabase.SaveAssets();
                File.WriteAllText(Completion, "{\"scenePrepared\":true,\"bike\":\"CB300 Twister\",\"referenceCalibration\":false}");
                Debug.Log("MotoSim: cena da Honda CB 300 Twister criada com o sistema de pilotagem existente. Testar aceleração, luzes e direção em Play.");
            }
            catch (Exception error)
            {
                Debug.LogException(error);
                File.WriteAllText(Path.Combine(Root, "MotoSim_CB300_Setup_Error.txt"), error.ToString());
                if (!Application.isBatchMode)
                    EditorUtility.DisplayDialog("MotoSim — CB 300", error.Message, "OK");
            }
        }

        private static void CreateScene()
        {
            GameObject model = AssetDatabase.LoadAssetAtPath<GameObject>(ModelPath);
            if (model == null) throw new InvalidOperationException("O FBX da CB 300 ainda não foi importado pelo Unity: " + ModelPath);

            // These are adjustable test values for a 300-class bike, not a factory-certified calibration.
            var profile = new BikePhysicsProfile
            {
                WheelbaseMetres = 1.41f,
                BikeMassKg = 147f,
                RiderMassKg = 75f,
                FrontWeightFraction = .48f,
                SuspensionTravelMetres = .12f,
                SuspensionFrequencyHz = 3f,
                SuspensionDampingRatio = .82f,
                CenterOfMassHeightMetres = .34f,
                TrainingSpeedLimitKph = 160f,
                GearSpeedLimitsKph = new[] { 30f, 55f, 85f, 120f, 160f },
                ClutchPullPerSecond = 16f,
                ClutchReleasePerSecond = 8f,
                ReferenceVerified = false,
                ReferenceNote = "Ajuste inicial de teste para o modelo CB300 importado; confirmar ano e especificações antes de calibrar.",
                ReferenceUrl = ""
            };
            profile.Validate();

            var recovered = PrepareInspectionProject.PreserveUnnamedScenes();
            Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Additive);
            SceneManager.SetActiveScene(scene);
            var root = new GameObject("CB300_Twister_Fisica");
            var visual = PrefabUtility.InstantiatePrefab(model, scene) as GameObject;
            if (visual == null) throw new InvalidOperationException("O modelo FBX da CB 300 não pôde ser instanciado.");
            visual.name = "Modelo_CB300_Twister";
            visual.transform.SetParent(root.transform, true);

            Transform front = Find(visual, "Eixo_Roda_Dianteira");
            Transform rear = Find(visual, "Eixo_Roda_Traseira");
            Vector3 direction = Vector3.ProjectOnPlane(front.position - rear.position, Vector3.up);
            if (direction.sqrMagnitude < .000001f) throw new InvalidOperationException("Os eixos das rodas da CB 300 estão sobrepostos.");
            visual.transform.rotation = Quaternion.FromToRotation(direction.normalized, Vector3.forward) * visual.transform.rotation;
            float measuredWheelbase = Vector3.ProjectOnPlane(front.position - rear.position, Vector3.up).magnitude;
            float scale = VehicleCalibration.UniformScale(measuredWheelbase, profile.WheelbaseMetres);
            visual.transform.localScale *= scale;
            Bounds tyreBounds = BoundsOf(FindRenderers(visual, "Pneu_"));
            visual.transform.position += new Vector3(-rear.position.x, -tyreBounds.min.y, -rear.position.z);

            Vector3 frontCenter = front.position;
            Vector3 rearCenter = rear.position;
            float frontRadius = TyreRadius(Find(visual, "Pneu_Dianteiro"));
            float rearRadius = TyreRadius(Find(visual, "Pneu_Traseiro"));
            float calibratedBase = Vector3.ProjectOnPlane(frontCenter - rearCenter, Vector3.up).magnitude;
            if (Mathf.Abs(calibratedBase - profile.WheelbaseMetres) > .025f)
                throw new InvalidOperationException("O entre-eixos importado não bate com a escala calibrada.");

            foreach (Renderer renderer in visual.GetComponentsInChildren<Renderer>(true))
            {
                Material[] materials = renderer.sharedMaterials;
                for (int i = 0; i < materials.Length; i++)
                    materials[i] = PrepareInspectionProject.PrepareMaterial(materials[i], renderer.name);
                renderer.sharedMaterials = materials;
            }

            var bodyCollider = root.AddComponent<BoxCollider>();
            bodyCollider.center = new Vector3(0f, .60f, .64f);
            bodyCollider.size = new Vector3(.48f, .54f, 1.12f);
            var body = root.AddComponent<Rigidbody>();
            body.mass = profile.TotalMassKg;
            body.centerOfMass = new Vector3(0f, profile.CenterOfMassHeightMetres, profile.WheelbaseMetres * profile.FrontWeightFraction);
            body.interpolation = RigidbodyInterpolation.Interpolate;
            body.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
            body.solverIterations = 16;
            body.solverVelocityIterations = 8;
            body.maxAngularVelocity = 5f;

            WheelCollider frontWheel = MakeWheel(root, "RodaFisica_CB300_Dianteira", frontCenter, frontRadius,
                profile.TotalMassKg * profile.FrontWeightFraction, profile);
            WheelCollider rearWheel = MakeWheel(root, "RodaFisica_CB300_Traseira", rearCenter, rearRadius,
                profile.TotalMassKg * (1f - profile.FrontWeightFraction), profile);
            var controller = root.AddComponent<MotorcycleController>();
            controller.Configure(frontWheel, rearWheel, profile);
            controller.ConfigureBalance(100f, 34f, 150f);
            root.AddComponent<MotorcycleAudio>().Configure(controller);
            root.AddComponent<KeyboardRiderInput>();
            root.AddComponent<RiderControlVisuals>().Configure(null, null, null, null, controller);
            root.AddComponent<MotorcyclePaint>().Configure(visual, 1);

            Transform steering = FindOptional(visual, "CTRL_Direcao_PROVISORIO");
            Transform suspension = FindOptional(visual, "CTRL_Suspensao_Dianteira");
            if (steering != null && suspension != null)
            {
                AttachLowerForkParts(steering, suspension, frontCenter);
                root.AddComponent<FrontVisualRig>().Configure(steering, suspension, frontWheel, frontCenter);
                controller.ConfigureSteeringAnchor(steering);
            }

            Renderer headlamp = FindRendererByMaterial(visual, "FarolCB");
            Renderer tailLamp = FindRendererByMaterial(visual, "LanternaCB");
            Renderer[] signals = FindRenderersByMaterial(visual, "PiscaAlertaCB");
            if (headlamp == null || tailLamp == null || signals.Length == 0)
                throw new InvalidOperationException("Não encontrei no CB300 as lentes identificadas de farol, lanterna e setas.");
            SeparateSignalsBySide(visual, signals, out Renderer[] leftSignals, out Renderer[] rightSignals);
            var lighting = root.AddComponent<MotorcycleLighting>();
            lighting.Configure(visual, steering, controller, headlamp, tailLamp, leftSignals, rightSignals);
            root.AddComponent<WheelPoseBinding>().Configure(frontWheel, front, frontCenter);
            root.AddComponent<WheelPoseBinding>().Configure(rearWheel, rear, rearCenter);

            root.transform.position = new Vector3(0f, 0f, -3.8f);
            body.ResetInertiaTensor();
            TrainingCourseBuilder.Build();

            var cameraObject = new GameObject("Camera_Acompanhamento_CB300");
            cameraObject.tag = "MainCamera";
            var camera = cameraObject.AddComponent<Camera>(); camera.fieldOfView = 55f; camera.nearClipPlane = .05f;
            camera.farClipPlane = 500f; camera.clearFlags = CameraClearFlags.SolidColor;
            camera.backgroundColor = new Color(.25f, .34f, .45f);
            cameraObject.AddComponent<AudioListener>();
            var rideCamera = cameraObject.AddComponent<RideCamera>(); rideCamera.Configure(root.transform);
            cameraObject.AddComponent<RideTelemetry>().Configure(controller, rideCamera, lighting);
            var rider = root.AddComponent<RiderAvatar>();
            rider.Configure(visual, controller, rideCamera);
            rider.SetHumanModel(SchoolWorldBuilder.Actor("Jogador", "Jogador_Game.fbx"),
                SchoolWorldBuilder.Clip("m_sit_chair_idle_neutral_01.max.fbx"));
            rider.SetFirstPersonArms(SchoolWorldBuilder.Actor("Jogador", "Jogador_Bracos1P.fbx"));
            root.AddComponent<PracticalRidingExam>().Configure(controller);

            var sunObject = new GameObject("Luz_Solar_CB300");
            var sun = sunObject.AddComponent<Light>(); sun.type = LightType.Directional; sun.intensity = 1.5f; sun.shadows = LightShadows.Soft;
            sunObject.transform.rotation = Quaternion.Euler(45f, -35f, 0f);
            RenderSettings.sun = sun; RenderSettings.ambientMode = AmbientMode.Trilight;
            RenderSettings.ambientSkyColor = new Color(.55f, .62f, .7f);
            RenderSettings.ambientEquatorColor = new Color(.3f, .32f, .35f);
            RenderSettings.ambientGroundColor = new Color(.15f, .14f, .13f);

            if (!EditorSceneManager.SaveScene(scene, ScenePath)) throw new IOException("Não foi possível salvar a cena de teste da CB 300.");
            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
            PrepareInspectionProject.CloseRecoveredScenes(recovered);
            File.WriteAllText(Path.Combine(Root, "ProjectSettings/MotoSimCB300Calibration.json"),
                "{\"wheelbaseMetres\":" + F(profile.WheelbaseMetres) + ",\"scaleApplied\":" + F(scale) +
                ",\"frontRadiusMetres\":" + F(frontRadius) + ",\"rearRadiusMetres\":" + F(rearRadius) +
                ",\"totalMassKg\":" + F(profile.TotalMassKg) + ",\"referenceVerified\":false}");
        }

        private static void AttachLowerForkParts(Transform steering, Transform suspension, Vector3 axleCenter)
        {
            // The supplied CB FBX has a suspension marker but no children under it.
            // Move only the lower fork and fender pieces, preserving their world pose.
            int attached = 0;
            foreach (Transform part in steering.Cast<Transform>().ToArray())
            {
                Renderer renderer = part.GetComponent<Renderer>();
                if (renderer == null || renderer.bounds.center.y > suspension.position.y + .12f) continue;
                Vector3 horizontal = Vector3.ProjectOnPlane(renderer.bounds.center - axleCenter, Vector3.up);
                if (horizontal.magnitude > .4f) continue;
                part.SetParent(suspension, true);
                attached++;
            }
            if (attached < 2)
                throw new InvalidOperationException("As peças inferiores do garfo da Street não foram encontradas no FBX.");
        }

        private static WheelCollider MakeWheel(GameObject root, string name, Vector3 center, float radius, float supportedMass, BikePhysicsProfile p)
        {
            var wheelObject = new GameObject(name);
            wheelObject.transform.SetParent(root.transform, false);
            wheelObject.transform.position = center + Vector3.up * p.SuspensionTravelMetres * .5f;
            var wheel = wheelObject.AddComponent<WheelCollider>();
            wheel.radius = radius; wheel.mass = 10f; wheel.sprungMass = supportedMass;
            wheel.suspensionDistance = p.SuspensionTravelMetres; wheel.forceAppPointDistance = .04f; wheel.wheelDampingRate = .4f;
            float spring = VehicleCalibration.SpringRate(supportedMass, p.SuspensionFrequencyHz * .82f);
            wheel.suspensionSpring = new JointSpring
            {
                spring = spring,
                damper = VehicleCalibration.DamperRate(supportedMass, spring, Mathf.Max(1.05f, p.SuspensionDampingRatio)),
                targetPosition = .5f
            };
            WheelFrictionCurve forward = wheel.forwardFriction;
            forward.extremumSlip = .18f; forward.extremumValue = 1f; forward.asymptoteSlip = .38f;
            forward.asymptoteValue = .82f; forward.stiffness = 1.2f; wheel.forwardFriction = forward;
            WheelFrictionCurve sideways = wheel.sidewaysFriction;
            sideways.extremumSlip = .3f; sideways.extremumValue = .85f; sideways.asymptoteSlip = .65f;
            sideways.asymptoteValue = .68f; sideways.stiffness = .82f; wheel.sidewaysFriction = sideways;
            wheel.ConfigureVehicleSubsteps(100f, 16, 16);
            return wheel;
        }

        private static float TyreRadius(Transform tyre)
        {
            Renderer renderer = tyre.GetComponent<Renderer>() ?? tyre.GetComponentInChildren<Renderer>(true);
            if (renderer == null) throw new InvalidOperationException("O pneu não tem Renderer: " + tyre.name);
            float radius = renderer.bounds.extents.y;
            if (radius < .15f || radius > .6f) throw new InvalidOperationException("Raio de pneu fora da faixa: " + radius);
            return radius;
        }

        private static Bounds BoundsOf(Renderer[] renderers)
        {
            if (renderers == null || renderers.Length == 0) throw new InvalidOperationException("Não encontrei os dois pneus da CB 300.");
            Bounds bounds = renderers[0].bounds;
            foreach (Renderer renderer in renderers) bounds.Encapsulate(renderer.bounds);
            return bounds;
        }

        private static Renderer[] FindRenderers(GameObject model, string prefix) =>
            model.GetComponentsInChildren<Renderer>(true).Where(r => r.name.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)).ToArray();

        private static Renderer FindRendererByMaterial(GameObject model, string token) =>
            model.GetComponentsInChildren<Renderer>(true).FirstOrDefault(r => r.sharedMaterials.Any(m =>
                m != null && m.name.IndexOf(token, StringComparison.OrdinalIgnoreCase) >= 0));

        private static Renderer[] FindRenderersByMaterial(GameObject model, string token) =>
            model.GetComponentsInChildren<Renderer>(true).Where(r => r.sharedMaterials.Any(m =>
                m != null && m.name.IndexOf(token, StringComparison.OrdinalIgnoreCase) >= 0)).ToArray();

        private static void SeparateSignalsBySide(GameObject model, Renderer[] sources,
            out Renderer[] leftSignals, out Renderer[] rightSignals)
        {
            var left = new List<Renderer>();
            var right = new List<Renderer>();
            PrepareInspectionProject.EnsureFolder(Generated, "Meshes");
            foreach (Renderer source in sources)
            {
                MeshFilter filter = source.GetComponent<MeshFilter>();
                Mesh sourceMesh = filter != null ? filter.sharedMesh : null;
                if (sourceMesh == null)
                {
                    left.Add(source); right.Add(source);
                    continue;
                }

                Vector3[] vertices = sourceMesh.vertices;
                var leftTriangles = new List<int>[sourceMesh.subMeshCount];
                var rightTriangles = new List<int>[sourceMesh.subMeshCount];
                int leftCount = 0, rightCount = 0;
                for (int submesh = 0; submesh < sourceMesh.subMeshCount; submesh++)
                {
                    leftTriangles[submesh] = new List<int>();
                    rightTriangles[submesh] = new List<int>();
                    int[] triangles = sourceMesh.GetTriangles(submesh);
                    for (int i = 0; i + 2 < triangles.Length; i += 3)
                    {
                        int a = triangles[i], b = triangles[i + 1], c = triangles[i + 2];
                        Vector3 localCenter = (vertices[a] + vertices[b] + vertices[c]) / 3f;
                        float side = model.transform.InverseTransformPoint(filter.transform.TransformPoint(localCenter)).x;
                        List<int> destination = side < 0 ? leftTriangles[submesh] : rightTriangles[submesh];
                        destination.Add(a); destination.Add(b); destination.Add(c);
                        if (side < 0) leftCount += 3; else rightCount += 3;
                    }
                }
                if (leftCount == 0 || rightCount == 0)
                {
                    left.Add(source); right.Add(source);
                    continue;
                }

                string safeName = source.name.Replace('/', '_').Replace('\\', '_');
                Mesh leftMesh = CreateSignalSideMesh(sourceMesh, leftTriangles, "CB300_Setas_Esquerda_" + safeName);
                Mesh rightMesh = CreateSignalSideMesh(sourceMesh, rightTriangles, "CB300_Setas_Direita_" + safeName);
                leftMesh = SaveSignalMesh(leftMesh);
                rightMesh = SaveSignalMesh(rightMesh);
                left.Add(CreateSignalRenderer(source, filter, leftMesh, "_Esquerda"));
                right.Add(CreateSignalRenderer(source, filter, rightMesh, "_Direita"));
                source.enabled = false;
            }
            leftSignals = left.ToArray();
            rightSignals = right.ToArray();
        }

        private static Mesh CreateSignalSideMesh(Mesh source, List<int>[] triangles, string name)
        {
            var mesh = new Mesh { name = name, indexFormat = source.indexFormat };
            mesh.vertices = source.vertices;
            mesh.normals = source.normals;
            mesh.tangents = source.tangents;
            mesh.colors = source.colors;
            mesh.uv = source.uv; mesh.uv2 = source.uv2; mesh.uv3 = source.uv3; mesh.uv4 = source.uv4;
            mesh.subMeshCount = source.subMeshCount;
            for (int submesh = 0; submesh < source.subMeshCount; submesh++)
                mesh.SetTriangles(triangles[submesh], submesh, false);
            mesh.RecalculateBounds();
            return mesh;
        }

        private static Mesh SaveSignalMesh(Mesh mesh)
        {
            string assetPath = Generated + "/Meshes/" + mesh.name + ".asset";
            Mesh existing = AssetDatabase.LoadAssetAtPath<Mesh>(assetPath);
            if (existing == null) AssetDatabase.CreateAsset(mesh, assetPath);
            else
            {
                EditorUtility.CopySerialized(mesh, existing);
                UnityEngine.Object.DestroyImmediate(mesh);
                mesh = existing;
            }
            return mesh;
        }

        private static Renderer CreateSignalRenderer(Renderer source, MeshFilter sourceFilter, Mesh mesh, string suffix)
        {
            var piece = new GameObject(source.name + suffix);
            Transform sourceTransform = source.transform;
            piece.transform.SetParent(sourceTransform.parent, false);
            piece.transform.localPosition = sourceTransform.localPosition;
            piece.transform.localRotation = sourceTransform.localRotation;
            piece.transform.localScale = sourceTransform.localScale;
            piece.layer = source.gameObject.layer;
            piece.AddComponent<MeshFilter>().sharedMesh = mesh;
            MeshRenderer renderer = piece.AddComponent<MeshRenderer>();
            renderer.sharedMaterials = source.sharedMaterials;
            renderer.shadowCastingMode = source.shadowCastingMode;
            renderer.receiveShadows = source.receiveShadows;
            renderer.lightProbeUsage = source.lightProbeUsage;
            renderer.reflectionProbeUsage = source.reflectionProbeUsage;
            return renderer;
        }

        private static Transform Find(GameObject model, string name) => FindOptional(model, name) ??
            throw new InvalidOperationException("Locator funcional não encontrado no FBX: " + name);

        private static Transform FindOptional(GameObject model, string name) =>
            model.GetComponentsInChildren<Transform>(true).FirstOrDefault(t => t.name == name);

        private static string F(float value) => value.ToString("R", System.Globalization.CultureInfo.InvariantCulture);
    }
}
