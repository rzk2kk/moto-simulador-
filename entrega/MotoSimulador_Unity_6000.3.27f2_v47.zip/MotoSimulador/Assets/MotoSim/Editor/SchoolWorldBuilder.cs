using System;
using MotoSim.Unity;
using UnityEditor;
using UnityEngine;

namespace MotoSim.Editor
{
    /// <summary>Creates playable 3D school scenes with licensed human characters.</summary>
    internal static class SchoolWorldBuilder
    {
        private const string Art = "Assets/MotoSim/Art/Characters/Rocketbox/";
        private const string Materials = "Assets/MotoSim/Generated/Materials/";

        internal static SchoolStoryStage Build(Camera camera)
        {
            GameObject door = new GameObject("Autoescola_Entrada_3D");
            GameObject classroom = new GameObject("Autoescola_SalaDeAula_3D");
            GameObject yard = new GameObject("Autoescola_PatioDemonstracao_3D");
            GameObject exam = new GameObject("Autoescola_SalaDeProva_3D");
            Material wall = Mat("Escola_Parede", new Color(.62f, .64f, .63f));
            Material floor = Mat("Escola_Piso", new Color(.19f, .21f, .22f));
            Material wood = Mat("Escola_Madeira", new Color(.24f, .13f, .075f));
            Material red = Mat("Escola_Vermelho", new Color(.72f, .035f, .055f));
            Material board = Mat("Escola_Quadro", new Color(.025f, .065f, .065f));

            Room(door.transform, 45, false, floor, wall);
            Cube(door.transform, "Fachada", new Vector3(0, 2.4f, 51), new Vector3(14, 4.8f, .4f), wall);
            Cube(door.transform, "Portal_Entrada", new Vector3(0, 2f, 50.6f), new Vector3(3.3f, 4f, .25f), red);
            Cube(door.transform, "Porta_Vidro", new Vector3(0, 1.8f, 50.4f), new Vector3(2.7f, 3.4f, .15f), board);
            Cube(door.transform, "Placa_Autoescola", new Vector3(0, 4.2f, 50.3f), new Vector3(7, .7f, .15f), red);

            Room(classroom.transform, 95, true, floor, wall);
            Cube(classroom.transform, "Quadro_De_Aula", new Vector3(0, 2.2f, 100.8f), new Vector3(7, 2.2f, .10f), board);
            Cube(classroom.transform, "Faixa_Quadro", new Vector3(0, 3.3f, 100.7f), new Vector3(7.3f, .08f, .12f), red);
            for (int row = 0; row < 2; row++)
                for (int side = -1; side <= 1; side += 2)
                    Desk(classroom.transform, new Vector3(side * 2.2f, 0, 91.5f + row * 3f), wood, floor);
            Cube(classroom.transform, "Maquete_Via", new Vector3(-4.7f, 1.2f, 98.3f), new Vector3(1.7f, .1f, 1.7f), floor);
            Cube(classroom.transform, "Faixa_Pedestre_Maquete", new Vector3(-4.7f, 1.27f, 98.3f), new Vector3(1.5f, .02f, .32f), wall);
            Cube(classroom.transform, "Placa_Limite", new Vector3(4.8f, 2.4f, 99.9f), new Vector3(1.1f, 1.1f, .08f), red);

            Room(yard.transform, 185, false, floor, wall);
            Cube(yard.transform, "Asfalto_Exercicio", new Vector3(0, .015f, 187), new Vector3(8, .03f, 8), floor);
            for (int i = 0; i < 5; i++)
                Cube(yard.transform, "Faixa_Pedestre_" + i,
                    new Vector3(-3.4f + i * 1.7f, .045f, 188.8f), new Vector3(.9f, .02f, 1.5f), wall);
            Cube(yard.transform, "Poste_Sinal", new Vector3(4.5f, 1.4f, 188.5f), new Vector3(.12f, 2.8f, .12f), floor);
            Cube(yard.transform, "Semaforo_Caixa", new Vector3(4.5f, 3.2f, 188.5f), new Vector3(.6f, 1.1f, .4f), board);
            Cube(yard.transform, "Sinal_Vermelho", new Vector3(4.5f, 3.50f, 188.27f), new Vector3(.3f, .3f, .05f), red);
            Cube(yard.transform, "Placa_Parada", new Vector3(-4.8f, 2.4f, 190), new Vector3(1.2f, 1.2f, .12f), red);
            Cube(yard.transform, "Bancada_Equipamentos", new Vector3(-3.6f, .8f, 185), new Vector3(2.2f, .15f, 1.1f), wood);
            for (int i = 0; i < 3; i++)
                Cube(yard.transform, "Cone_Demonstracao_" + i,
                    new Vector3(-2f + i * 2f, .35f, 191), new Vector3(.35f, .7f, .35f), red);

            Room(exam.transform, 140, true, floor, wall);
            Cube(exam.transform, "Mesa_Prova", new Vector3(0, .78f, 138), new Vector3(3.1f, .12f, 1.5f), wood);
            Cube(exam.transform, "Caderno_Questoes", new Vector3(0, .87f, 138), new Vector3(.7f, .04f, .9f), wall);
            Cube(exam.transform, "Relogio_Prova", new Vector3(0, 2.9f, 145.8f), new Vector3(.65f, .65f, .10f), board);

            GameObject learner = Actor("Jogador", "Jogador_Game.fbx");
            GameObject teacher = Actor("Instrutor_Leo", "Instrutor_Leo_Game.fbx");
            SchoolStoryStage stage = new GameObject("Direcao_Historia_3D").AddComponent<SchoolStoryStage>();
            stage.Configure(camera, learner, teacher, door, classroom, yard, exam,
                Clip("m_walk_neutral.max.fbx"), Clip("m_idle_neutral_01.max.fbx"),
                Clip("m_gestic_talk_neutral_01.max.fbx"), Clip("m_sit_chair_idle_neutral_01.max.fbx"));
            return stage;
        }

        internal static GameObject Actor(string label, string modelFile)
        {
            GameObject prefab = AssetDatabase.LoadAssetAtPath<GameObject>(Art + modelFile);
            if (prefab == null) throw new InvalidOperationException("Personagem Rocketbox ausente: " + modelFile);
            GameObject actor = PrefabUtility.InstantiatePrefab(prefab) as GameObject;
            if (actor == null) throw new InvalidOperationException("Falha ao criar personagem: " + modelFile);
            actor.name = label;
            foreach (Renderer renderer in actor.GetComponentsInChildren<Renderer>(true))
            {
                Material[] current = renderer.sharedMaterials;
                for (int i = 0; i < current.Length; i++)
                {
                    string source = current[i] == null ? "" : current[i].name.ToLowerInvariant();
                    string kind = source.Contains("head") ? "head_color" :
                        source.Contains("opacity") ? "opacity_color" : "body_color";
                    Material colored = Mat("Rocketbox_" + label + "_" + kind, Color.white);
                    Texture2D texture = AssetDatabase.LoadAssetAtPath<Texture2D>(Art + label + "_" + kind + ".png");
                    if (texture != null)
                    {
                        if (colored.HasProperty("_BaseMap")) colored.SetTexture("_BaseMap", texture);
                        if (colored.HasProperty("_MainTex")) colored.SetTexture("_MainTex", texture);
                    }
                    if (kind == "opacity_color" && colored.HasProperty("_AlphaClip"))
                    {
                        colored.SetFloat("_AlphaClip", 1f);
                        colored.SetFloat("_Cutoff", .45f);
                        colored.EnableKeyword("_ALPHATEST_ON");
                    }
                    current[i] = colored;
                }
                renderer.sharedMaterials = current;
            }
            return actor;
        }

        internal static AnimationClip Clip(string file)
        {
            foreach (UnityEngine.Object asset in AssetDatabase.LoadAllAssetsAtPath(Art + file))
                if (asset is AnimationClip clip && clip.name != "__preview__") return clip;
            Debug.LogWarning("Animação Rocketbox não encontrada: " + file);
            return null;
        }

        private static void Room(Transform parent, float z, bool inside, Material floor, Material wall)
        {
            Cube(parent, "Piso", new Vector3(0, -.12f, z), new Vector3(16, .24f, 16), floor);
            Cube(parent, "Parede_Direita", new Vector3(8, 2.3f, z), new Vector3(.3f, 4.6f, 16), wall);
            Cube(parent, "Parede_Esquerda", new Vector3(-8, 2.3f, z), new Vector3(.3f, 4.6f, 16), wall);
            if (!inside) return;
            Cube(parent, "Parede_Fundo", new Vector3(0, 2.3f, z + 8), new Vector3(16, 4.6f, .3f), wall);
            Cube(parent, "Teto", new Vector3(0, 4.8f, z), new Vector3(16, .25f, 16), floor);
            GameObject lamp = new GameObject("Luz_Sala"); lamp.transform.SetParent(parent);
            lamp.transform.position = new Vector3(0, 4.1f, z);
            Light light = lamp.AddComponent<Light>(); light.type = LightType.Point;
            light.range = 20; light.intensity = 600; light.color = new Color(1f, .91f, .77f);
        }

        private static void Desk(Transform parent, Vector3 position, Material wood, Material metal)
        {
            Cube(parent, "Carteira_Tampo", position + new Vector3(0, .78f, 0), new Vector3(1.7f, .10f, 1.05f), wood);
            foreach (int side in new[] { -1, 1 })
                Cube(parent, "Carteira_Per", position + new Vector3(side * .72f, .39f, 0), new Vector3(.07f, .78f, .8f), metal);
        }

        private static void Cube(Transform parent, string name, Vector3 position, Vector3 scale, Material material)
        {
            GameObject obj = GameObject.CreatePrimitive(PrimitiveType.Cube);
            obj.name = name; obj.transform.SetParent(parent, true);
            obj.transform.position = position; obj.transform.localScale = scale;
            obj.GetComponent<Renderer>().sharedMaterial = material;
        }

        private static Material Mat(string name, Color color)
        {
            string path = Materials + name + ".mat";
            Material result = AssetDatabase.LoadAssetAtPath<Material>(path);
            if (result == null)
            {
                Shader shader = Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Standard");
                result = new Material(shader) { name = name };
                AssetDatabase.CreateAsset(result, path);
            }
            if (result.HasProperty("_BaseColor")) result.SetColor("_BaseColor", color);
            if (result.HasProperty("_Color")) result.SetColor("_Color", color);
            return result;
        }
    }
}
