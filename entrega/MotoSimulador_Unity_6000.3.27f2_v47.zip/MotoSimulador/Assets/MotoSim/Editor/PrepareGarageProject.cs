using System;
using System.IO;
using MotoSim.Unity;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace MotoSim.Editor
{
    /// <summary>Generates the garage hub and registers each available motorcycle scene.</summary>
    public static class PrepareGarageProject
    {
        internal const string ScenePath = "Assets/MotoSim/Generated/Garagem_Motos.unity";
        private const string Generated = "Assets/MotoSim/Generated";
        private const string ModelPath = "Assets/MotoSim/Art/";
        private const string SplashLogoPath = "Assets/MotoSim/Art/Splash/MotoSimuladorSplash.png";
        private const string GarageBackgroundPath = "Assets/MotoSim/Art/Garage/MotoSimGarageBackground.png";
        private const string BrandLogoPath = "Assets/MotoSim/Art/Textures/Logo_MotoSim_Placa.png";
        private const string SessionKey = "MotoSim.GarageSetupAttempted";
        private static string Root => Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
        private static string Completion => Path.Combine(Root, "ProjectSettings", "MotoSimGarageSetup.json");

        internal static void TryAutomaticSetup()
        {
            if (File.Exists(Completion) &&
                File.ReadAllText(Completion).Contains("\"sceneVersion\":47") &&
                AssetDatabase.LoadAssetAtPath<SceneAsset>(ScenePath) != null)
            {
                Scene active = SceneManager.GetActiveScene();
                if (active.IsValid() && !active.isDirty && string.IsNullOrEmpty(active.path)) RunSetup();
                return;
            }
            if (SessionState.GetBool(SessionKey, false)) return;
            SessionState.SetBool(SessionKey, true);
            RunSetup();
        }

        [MenuItem("MotoSim/Abrir Garagem")]
        public static void RunSetup()
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode || EditorApplication.isCompiling || EditorApplication.isUpdating)
            { EditorApplication.delayCall += RunSetup; return; }
            try
            {
                RebuildGeneratedScenesWhenOutdated();
                PrepareInspectionProject.EnsureFolder("Assets/MotoSim", "Generated");
                PrepareInspectionProject.ConfigurePipeline();
                ConfigureSplashScreen();
                PrepareInspectionProject.EnsureFolder(Generated, "Materials");
                PrepareRocketboxAnimations();

                EnsureScene(PrepareRidingProject.ScenePath, PrepareRidingProject.RunSetup);
                EnsureScene(PrepareSchoolProject.ScenePath, PrepareSchoolProject.RunSetup);
                EnsureScene(PrepareCB300Project.ScenePath, PrepareCB300Project.RunSetup);
                EnsureScene(PrepareAfricaTwinProject.ScenePath, PrepareAfricaTwinProject.RunSetup);
                if (AssetDatabase.LoadAssetAtPath<SceneAsset>(ScenePath) == null) CreateScene();
                else PrepareInspectionProject.OpenPreparedScene(ScenePath);

                EditorBuildSettings.scenes = new[] {
                    new EditorBuildSettingsScene(ScenePath, true),
                    new EditorBuildSettingsScene(PrepareRidingProject.ScenePath, true),
                    new EditorBuildSettingsScene(PrepareSchoolProject.ScenePath, true),
                    new EditorBuildSettingsScene(PrepareCB300Project.ScenePath, true),
                    new EditorBuildSettingsScene(PrepareAfricaTwinProject.ScenePath, true)
                };
                AssetDatabase.SaveAssets();
                File.WriteAllText(Completion, "{\"scenePrepared\":true,\"motorcycles\":3,\"sceneVersion\":47}");
                Debug.Log("MotoSim: garagem pronta com CG 160, CB 300 Twister e Africa Twin.");
            }
            catch (Exception error)
            {
                Debug.LogException(error);
                File.WriteAllText(Path.Combine(Root, "MotoSim_Garage_Setup_Error.txt"), error.ToString());
                if (!Application.isBatchMode)
                    EditorUtility.DisplayDialog("MotoSim — Garagem", error.Message, "OK");
            }
        }

        private static void ConfigureSplashScreen()
        {
            PrepareInspectionProject.EnsureFolder("Assets/MotoSim/Art", "Splash");
            AssetDatabase.Refresh();
            TextureImporter importer = AssetImporter.GetAtPath(SplashLogoPath) as TextureImporter;
            if (importer == null) throw new InvalidOperationException("A logo para a abertura não foi encontrada: " + SplashLogoPath);
            if (importer.textureType != TextureImporterType.Sprite || importer.spriteImportMode != SpriteImportMode.Single)
            {
                importer.textureType = TextureImporterType.Sprite;
                importer.spriteImportMode = SpriteImportMode.Single;
                importer.mipmapEnabled = false;
                importer.SaveAndReimport();
            }

            Sprite motoSimLogo = AssetDatabase.LoadAssetAtPath<Sprite>(SplashLogoPath);
            if (motoSimLogo == null) throw new InvalidOperationException("A logo da MotoSimulador não pôde ser importada como Sprite.");

            PlayerSettings.SplashScreen.show = true;
            PlayerSettings.SplashScreen.showUnityLogo = false;
            PlayerSettings.SplashScreen.animationMode = PlayerSettings.SplashScreen.AnimationMode.Dolly;
            PlayerSettings.SplashScreen.backgroundColor = Color.black;
            PlayerSettings.SplashScreen.logos = new[]
            {
                PlayerSettings.SplashScreenLogo.Create(2f, motoSimLogo)
            };
        }

        private static void RebuildGeneratedScenesWhenOutdated()
        {
            if (File.Exists(Completion) && File.ReadAllText(Completion).Contains("\"sceneVersion\":47")) return;

            string[] generatedScenes = {
                ScenePath, PrepareRidingProject.ScenePath, PrepareSchoolProject.ScenePath,
                PrepareCB300Project.ScenePath, PrepareAfricaTwinProject.ScenePath
            };
            foreach (string path in generatedScenes)
            {
                Scene loaded = SceneManager.GetSceneByPath(path);
                if (loaded.IsValid() && loaded.isLoaded) EditorSceneManager.CloseScene(loaded, true);
                AssetDatabase.DeleteAsset(path);
            }
            foreach (string marker in new[] {
                "MotoSimGarageSetup.json", "MotoSimRidingSetup.json",
                "MotoSimCB300Setup.json", "MotoSimAfricaTwinSetup.json"
            })
            {
                string markerPath = Path.Combine(Root, "ProjectSettings", marker);
                if (File.Exists(markerPath)) File.Delete(markerPath);
            }
            AssetDatabase.Refresh();
        }

        private static void EnsureScene(string path, Action build)
        {
            if (AssetDatabase.LoadAssetAtPath<SceneAsset>(path) != null) return;
            build();
            // Individual scene builders open their result. Save this completed scene before the
            // next builder changes the active scene, so the garage can be created afterwards.
            Scene built = SceneManager.GetSceneByPath(path);
            if (built.IsValid() && built.isLoaded) EditorSceneManager.SaveScene(built, path);
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            if (AssetDatabase.LoadAssetAtPath<SceneAsset>(path) == null)
                throw new InvalidOperationException("A preparação não gerou a cena necessária para a garagem: " + path);
        }

        private static void PrepareRocketboxAnimations()
        {
            const string path = "Assets/MotoSim/Art/Characters/Rocketbox/";
            foreach (string file in new[] {
                "Jogador_Game.fbx", "Jogador_Bracos1P.fbx", "Instrutor_Leo_Game.fbx",
                "m_walk_neutral.max.fbx", "m_idle_neutral_01.max.fbx",
                "m_gestic_talk_neutral_01.max.fbx", "m_sit_chair_idle_neutral_01.max.fbx"
            })
            {
                ModelImporter importer = AssetImporter.GetAtPath(path + file) as ModelImporter;
                if (importer == null) throw new InvalidOperationException("Modelo ou animação Rocketbox ausente: " + file);
                if (importer.animationType == ModelImporterAnimationType.Legacy && importer.importAnimation) continue;
                importer.animationType = ModelImporterAnimationType.Legacy;
                importer.importAnimation = true;
                importer.SaveAndReimport();
            }
        }

        private static void CreateScene()
        {
            var recovered = PrepareInspectionProject.PreserveUnnamedScenes();
            Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Additive);
            SceneManager.SetActiveScene(scene);

            var camGo = new GameObject("Camera_Garagem"); camGo.tag = "MainCamera";
            var cam = camGo.AddComponent<Camera>(); cam.clearFlags = CameraClearFlags.SolidColor; cam.backgroundColor = new Color(.025f, .03f, .04f);
            cam.fieldOfView = 48; cam.nearClipPlane = .1f; cam.farClipPlane = 100;
            camGo.transform.position = new Vector3(0, 2.3f, -10.6f); camGo.transform.LookAt(new Vector3(0, 1.05f, 0));
            camGo.AddComponent<AudioListener>();
            CreateGarageBackdrop(cam);
            SchoolWorldBuilder.Build(cam);
            new GameObject("Salvamento_Automatico_Da_Carreira").AddComponent<MotoCareerAutoSave>();

            var stage = new GameObject("Suporte_Modelos");
            GameObject[] models = {
                InstantiateBike("CG160", ModelPath + "CG160_neutra_unidades_originais.fbx", stage.transform, 0),
                InstantiateBike("CB300_Twister", ModelPath + "CB300_Twister_MotoSim.fbx", stage.transform, 1),
                InstantiateBike("Honda_Africa_Twin", ModelPath + "Honda_Africa_Twin_MotoSim.fbx", stage.transform, 2)
            };
            var screen = new GameObject("Interface_Garagem").AddComponent<GarageSelectionScreen>();
            screen.Configure(models,
                new[] { "Rota 160 Start", "Rota 300 Street", "Rota 1000 Adventure" },
                new[] { PrepareRidingProject.ScenePath, PrepareCB300Project.ScenePath, PrepareAfricaTwinProject.ScenePath },
                AssetDatabase.LoadAssetAtPath<Texture2D>(SplashLogoPath),
                AssetDatabase.LoadAssetAtPath<Texture2D>(BrandLogoPath),
                PrepareSchoolProject.ScenePath);

            var sunGo = new GameObject("Luz_Garagem"); var sun = sunGo.AddComponent<Light>(); sun.type = LightType.Directional; sun.intensity = 1.2f; sun.shadows = LightShadows.Soft;
            sunGo.transform.rotation = Quaternion.Euler(48, -28, 0); RenderSettings.sun = sun;
            RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Trilight;
            RenderSettings.ambientSkyColor = new Color(.35f,.37f,.4f); RenderSettings.ambientEquatorColor = new Color(.2f,.2f,.22f); RenderSettings.ambientGroundColor = new Color(.08f,.08f,.09f);

            if (!EditorSceneManager.SaveScene(scene, ScenePath)) throw new IOException("Não foi possível salvar a garagem.");
            PrepareInspectionProject.CloseRecoveredScenes(recovered);
        }

        private static void CreateGarageBackdrop(Camera camera)
        {
            Texture2D image = AssetDatabase.LoadAssetAtPath<Texture2D>(GarageBackgroundPath);
            if (image == null) throw new InvalidOperationException("A arte de fundo da garagem não foi encontrada: " + GarageBackgroundPath);
            const string materialPath = Generated + "/Materials/Garage_Backdrop.mat";
            Material material = AssetDatabase.LoadAssetAtPath<Material>(materialPath);
            if (material == null)
            {
                Shader shader = Shader.Find("Universal Render Pipeline/Unlit") ?? Shader.Find("Unlit/Texture");
                if (shader == null) throw new InvalidOperationException("Shader sem iluminação não encontrado para o fundo da garagem.");
                material = new Material(shader) { name = "Garage_Backdrop" };
                AssetDatabase.CreateAsset(material, materialPath);
            }
            if (material.HasProperty("_BaseMap")) material.SetTexture("_BaseMap", image);
            if (material.HasProperty("_MainTex")) material.SetTexture("_MainTex", image);
            if (material.HasProperty("_BaseColor")) material.SetColor("_BaseColor", Color.white);
            if (material.HasProperty("_Color")) material.SetColor("_Color", Color.white);
            if (material.HasProperty("_Cull")) material.SetFloat("_Cull", 0);
            EditorUtility.SetDirty(material);

            const float distance = 24f;
            var backdrop = GameObject.CreatePrimitive(PrimitiveType.Quad);
            backdrop.name = "Cenario_Garagem_Fotografico";
            UnityEngine.Object.DestroyImmediate(backdrop.GetComponent<Collider>());
            backdrop.transform.position = camera.transform.position + camera.transform.forward * distance;
            backdrop.transform.rotation = Quaternion.LookRotation(camera.transform.forward, camera.transform.up);
            float height = 2f * distance * Mathf.Tan(camera.fieldOfView * .5f * Mathf.Deg2Rad);
            backdrop.transform.localScale = new Vector3(height * camera.aspect * 1.3f, height * 1.3f, 1f);
            backdrop.GetComponent<Renderer>().sharedMaterial = material;
        }

        private static GameObject InstantiateBike(string name, string path, Transform parent, int index)
        {
            GameObject prefab = AssetDatabase.LoadAssetAtPath<GameObject>(path);
            if (prefab == null) throw new InvalidOperationException("Modelo da garagem ausente: " + path);
            var instance = PrefabUtility.InstantiatePrefab(prefab) as GameObject;
            if (instance == null) throw new InvalidOperationException("Não foi possível abrir o modelo: " + path);
            instance.name = "Exibicao_" + name; instance.transform.SetParent(parent, true);
            if (name == "Honda_Africa_Twin")
                foreach (Renderer renderer in instance.GetComponentsInChildren<Renderer>(true))
                {
                    Material[] materials = renderer.sharedMaterials;
                    for (int i = 0; i < materials.Length; i++)
                        materials[i] = PrepareAfricaTwinProject.PrepareAfricaMaterial(materials[i], renderer.name);
                    renderer.sharedMaterials = materials;
                }
            MotorcyclePaint.Apply(instance, index);
            Bounds bounds = BoundsOf(instance);
            float scale = 2.3f / Mathf.Max(.01f, bounds.size.y);
            instance.transform.localScale *= scale;
            bounds = BoundsOf(instance);
            instance.transform.position += new Vector3(-bounds.center.x, -bounds.min.y, -bounds.center.z);
            instance.transform.position += new Vector3(0, -.20f, -1.5f + index * .01f);
            bounds = BoundsOf(instance);
            var pivot = new GameObject("Pivo_Central_" + name);
            pivot.transform.SetParent(parent, false);
            pivot.transform.position = bounds.center;
            instance.transform.SetParent(pivot.transform, true);
            instance.SetActive(true);
            pivot.SetActive(index == 0);
            return pivot;
        }

        private static Bounds BoundsOf(GameObject root)
        {
            Renderer[] renderers = root.GetComponentsInChildren<Renderer>(true);
            if (renderers.Length == 0) throw new InvalidOperationException("Modelo sem malhas renderizáveis: " + root.name);
            Bounds b = renderers[0].bounds; foreach (Renderer r in renderers) b.Encapsulate(r.bounds); return b;
        }

        private static Material MakeMaterial(string name, Color color)
        {
            string path = Generated + "/Materials/" + name + ".mat";
            Material material = AssetDatabase.LoadAssetAtPath<Material>(path);
            if (material == null)
            {
                Shader shader = Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Standard");
                material = new Material(shader); AssetDatabase.CreateAsset(material, path);
            }
            if (material.HasProperty("_BaseColor")) material.SetColor("_BaseColor", color);
            if (material.HasProperty("_Color")) material.SetColor("_Color", color);
            return material;
        }

        private static void Cube(string name, Vector3 position, Vector3 size, Material material)
        {
            var cube = GameObject.CreatePrimitive(PrimitiveType.Cube); cube.name = name;
            cube.transform.position = position; cube.transform.localScale = size;
            cube.GetComponent<Renderer>().sharedMaterial = material;
            if (name == "Area_Centro") UnityEngine.Object.DestroyImmediate(cube.GetComponent<Collider>());
        }
    }
}
