using UnityEditor;
using UnityEngine;

namespace MotoSim.Editor
{
    /// <summary>Physical test lot and visual barriers for the two separate riding scenes.</summary>
    internal static class EnclosedMotorcycleSite
    {
        internal const string TestLotName = "Area_Teste_Livre";
        private const string Folder = "Assets/MotoSim/Generated/Materials";

        internal static void BuildTestLot()
        {
            GameObject lot = new GameObject(TestLotName);
            Material asphalt = Material("Teste_Asfalto", new Color(.16f, .18f, .20f));
            Material paint = Material("Teste_Linhas", new Color(.93f, .70f, .08f));
            Cube(lot.transform, "Pavimento_Teste", new Vector3(0, -.20f, 43), new Vector3(140, .4f, 175), asphalt);
            // Only a start guide and open pavement: no old examination obstacles.
            Cube(lot.transform, "Linha_Saida_Teste", new Vector3(0, .015f, 0), new Vector3(12, .02f, .16f), paint, false);
            Cube(lot.transform, "Linha_Retorno_Teste", new Vector3(0, .015f, 110), new Vector3(12, .02f, .16f), paint, false);
            BuildPerimeter(lot.transform, new Vector3(0, 0, 43), 140, 175);
        }

        internal static void BuildPerimeter(Transform parent, Vector3 center, float width, float length)
        {
            Material concrete = Material("Pista_Muro", new Color(.27f, .29f, .31f));
            Material windows = Material("Pista_Predio", new Color(.08f, .13f, .18f));
            const float wallHeight = 18f;
            Cube(parent, "Muro_Norte", center + new Vector3(0, wallHeight * .5f, length * .5f),
                new Vector3(width + 2, wallHeight, 2), concrete);
            Cube(parent, "Muro_Sul", center + new Vector3(0, wallHeight * .5f, -length * .5f),
                new Vector3(width + 2, wallHeight, 2), concrete);
            Cube(parent, "Muro_Leste", center + new Vector3(width * .5f, wallHeight * .5f, 0),
                new Vector3(2, wallHeight, length + 2), concrete);
            Cube(parent, "Muro_Oeste", center + new Vector3(-width * .5f, wallHeight * .5f, 0),
                new Vector3(2, wallHeight, length + 2), concrete);
            for (int side = -1; side <= 1; side += 2)
                for (int i = 0; i < 4; i++)
                {
                    float z = center.z - length * .35f + i * length * .23f;
                    float height = 24f + (i % 3) * 5f;
                    Cube(parent, "Predio_" + side + "_" + i,
                        new Vector3(center.x + side * (width * .5f + 11f), height * .5f, z),
                        new Vector3(15, height, 20), windows, false);
                }
        }

        private static GameObject Cube(Transform parent, string name, Vector3 position, Vector3 scale, Material material, bool collider = true)
        {
            GameObject obj = GameObject.CreatePrimitive(PrimitiveType.Cube);
            obj.name = name;
            obj.transform.SetParent(parent, false);
            obj.transform.localPosition = position;
            obj.transform.localScale = scale;
            obj.GetComponent<Renderer>().sharedMaterial = material;
            if (!collider) Object.DestroyImmediate(obj.GetComponent<Collider>());
            return obj;
        }

        private static Material Material(string name, Color color)
        {
            PrepareInspectionProject.EnsureFolder("Assets/MotoSim/Generated", "Materials");
            string path = Folder + "/" + name + ".mat";
            Material material = AssetDatabase.LoadAssetAtPath<Material>(path);
            if (material == null)
            {
                Shader shader = Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Standard");
                material = new Material(shader) { name = name };
                AssetDatabase.CreateAsset(material, path);
            }
            if (material.HasProperty("_BaseColor")) material.SetColor("_BaseColor", color);
            if (material.HasProperty("_Color")) material.SetColor("_Color", color);
            EditorUtility.SetDirty(material);
            return material;
        }
    }
}
