using System;

namespace MotoSim.Core
{
    public enum MissionMetric
    {
        Lessons, TheoryPassed, PracticalPassed, CareerDistanceCm, HeadlightDistanceCm,
        SignalSides, SafeStreakCm, ControlledStops, StreetPurchased, AdventurePurchased
    }

    public enum MissionTier { Easy, Medium, Hard }

    public sealed class MissionDefinition
    {
        public readonly string Id;
        public readonly MissionTier Tier;
        public readonly MissionMetric Metric;
        public readonly int Goal;
        public readonly int RewardCredits;
        public readonly string TitlePt, TitleEn, TitleEs;
        public readonly string DetailPt, DetailEn, DetailEs;

        public MissionDefinition(string id, MissionTier tier, MissionMetric metric, int goal, int reward,
            string titlePt, string titleEn, string titleEs, string detailPt, string detailEn, string detailEs)
        {
            Id = id; Tier = tier; Metric = metric; Goal = goal; RewardCredits = reward;
            TitlePt = titlePt; TitleEn = titleEn; TitleEs = titleEs;
            DetailPt = detailPt; DetailEn = detailEn; DetailEs = detailEs;
        }
    }

    /// <summary>One-time career challenges ordered from easy to hard.</summary>
    public static class MissionCatalog
    {
        public static readonly MissionDefinition[] All =
        {
            new MissionDefinition("first_lessons", MissionTier.Easy, MissionMetric.Lessons, 2, 500,
                "Primeiras lições", "First lessons", "Primeras lecciones",
                "Conclua 2 etapas da autoescola.", "Complete 2 school lessons.", "Completa 2 lecciones de la autoescuela."),
            new MissionDefinition("half_school", MissionTier.Easy, MissionMetric.Lessons, 6, 750,
                "Aluno dedicado", "Dedicated student", "Alumno dedicado",
                "Conclua 6 etapas da autoescola.", "Complete 6 school lessons.", "Completa 6 lecciones de la autoescuela."),
            new MissionDefinition("theory", MissionTier.Easy, MissionMetric.TheoryPassed, 1, 2000,
                "Teoria aprovada", "Theory passed", "Teoría aprobada",
                "Passe na prova teórica.", "Pass the theory test.", "Aprueba el examen teórico."),
            new MissionDefinition("practical", MissionTier.Easy, MissionMetric.PracticalPassed, 1, 3500,
                "Primeira conquista", "First achievement", "Primer logro",
                "Passe na prova prática.", "Pass the practical test.", "Aprueba la prueba práctica."),
            new MissionDefinition("ride_250", MissionTier.Easy, MissionMetric.CareerDistanceCm, 25000, 750,
                "Primeiros 250 metros", "First 250 metres", "Primeros 250 metros",
                "Pilote 250 m na carreira.", "Ride 250 m in career mode.", "Conduce 250 m en el modo carrera."),
            new MissionDefinition("headlight_300", MissionTier.Medium, MissionMetric.HeadlightDistanceCm, 30000, 1000,
                "Visibilidade", "Visibility", "Visibilidad",
                "Pilote 300 m com o farol ligado.", "Ride 300 m with the headlight on.", "Conduce 300 m con la luz encendida."),
            new MissionDefinition("signals", MissionTier.Medium, MissionMetric.SignalSides, 2, 1000,
                "Sinalize os dois lados", "Signal both ways", "Señaliza ambos lados",
                "Use as setas esquerda e direita em movimento.", "Use left and right turn signals while moving.", "Usa los intermitentes izquierdo y derecho en marcha."),
            new MissionDefinition("ride_1000", MissionTier.Medium, MissionMetric.CareerDistanceCm, 100000, 1800,
                "Primeiro quilômetro", "First kilometre", "Primer kilómetro",
                "Some 1 km pilotado na carreira.", "Ride 1 km in career mode.", "Acumula 1 km en el modo carrera."),
            new MissionDefinition("clean_500", MissionTier.Medium, MissionMetric.SafeStreakCm, 50000, 2500,
                "Condução tranquila", "Smooth riding", "Conducción tranquila",
                "Pilote 500 m na mesma saída sem cair nem passar de 45 km/h.",
                "Ride 500 m in one session without falling or exceeding 45 km/h.",
                "Conduce 500 m en una sesión sin caerte ni superar los 45 km/h."),
            new MissionDefinition("brake", MissionTier.Medium, MissionMetric.ControlledStops, 1, 2000,
                "Frenagem controlada", "Controlled stop", "Frenado controlado",
                "Reduza de 20 km/h para até 5 km/h usando os dois freios, sem cair.",
                "Slow from 20 km/h to 5 km/h using both brakes without falling.",
                "Reduce de 20 km/h a 5 km/h con ambos frenos sin caerte."),
            new MissionDefinition("ride_3000", MissionTier.Hard, MissionMetric.CareerDistanceCm, 300000, 5000,
                "Rota de 3 km", "Three-kilometre route", "Ruta de 3 km",
                "Some 3 km pilotados na carreira.", "Ride 3 km in career mode.", "Acumula 3 km en el modo carrera."),
            new MissionDefinition("street", MissionTier.Hard, MissionMetric.StreetPurchased, 1, 3000,
                "Garagem maior", "Growing garage", "Garaje más grande",
                "Compre a Rota 300 Street.", "Buy the Rota 300 Street.", "Compra la Rota 300 Street."),
            new MissionDefinition("clean_1000", MissionTier.Hard, MissionMetric.SafeStreakCm, 100000, 7000,
                "Viagem sem erros", "Flawless ride", "Viaje sin errores",
                "Pilote 1 km na mesma saída sem cair nem passar de 45 km/h.",
                "Ride 1 km in one session without falling or exceeding 45 km/h.",
                "Conduce 1 km en una sesión sin caerte ni superar los 45 km/h."),
            new MissionDefinition("ride_10000", MissionTier.Hard, MissionMetric.CareerDistanceCm, 1000000, 15000,
                "Experiência na estrada", "Road experience", "Experiencia en ruta",
                "Some 10 km pilotados na carreira.", "Ride 10 km in career mode.", "Acumula 10 km en el modo carrera."),
            new MissionDefinition("adventure", MissionTier.Hard, MissionMetric.AdventurePurchased, 1, 12000,
                "Coleção completa", "Complete collection", "Colección completa",
                "Compre a Rota 1000 Adventure.", "Buy the Rota 1000 Adventure.", "Compra la Rota 1000 Adventure.")
        };
    }

    public struct MissionRideSample
    {
        public int DistanceCm;
        public float SpeedKph;
        public float DeltaSeconds;
        public bool EngineOn, HeadlightOn, LeftSignalOn, RightSignalOn, HazardsOn;
        public bool Fallen, Teleported, FrontBrakeOn, RearBrakeOn;
    }

    /// <summary>Pure ride counters: rejects preview mileage at the caller and resets unsafe streaks.</summary>
    public sealed class MissionRideTracker
    {
        public int CareerDistanceCm { get; private set; }
        public int HeadlightDistanceCm { get; private set; }
        public int SafeStreakCm { get; private set; }
        public int BestSafeStreakCm { get; private set; }
        public int SignalMask { get; private set; }
        public int ControlledStops { get; private set; }
        private bool braking;
        private bool usedFront, usedRear;
        private float brakeSeconds;

        public MissionRideTracker(int careerDistanceCm, int headlightDistanceCm, int bestSafeStreakCm,
            int signalMask, int controlledStops)
        {
            CareerDistanceCm = Math.Max(0, careerDistanceCm);
            HeadlightDistanceCm = Math.Max(0, headlightDistanceCm);
            BestSafeStreakCm = Math.Max(0, bestSafeStreakCm);
            SignalMask = signalMask & 3;
            ControlledStops = Math.Max(0, controlledStops);
        }

        public void Step(MissionRideSample sample)
        {
            int distance = sample.EngineOn && sample.SpeedKph > 1f && !sample.Fallen && !sample.Teleported ?
                Math.Min(500, Math.Max(0, sample.DistanceCm)) : 0;
            CareerDistanceCm = SaturatingAdd(CareerDistanceCm, distance);
            if (sample.HeadlightOn) HeadlightDistanceCm = SaturatingAdd(HeadlightDistanceCm, distance);

            bool safe = !sample.Fallen && !sample.Teleported && sample.SpeedKph <= 45f;
            SafeStreakCm = safe ? SaturatingAdd(SafeStreakCm, distance) : 0;
            BestSafeStreakCm = Math.Max(BestSafeStreakCm, SafeStreakCm);

            bool left = sample.LeftSignalOn && !sample.HazardsOn;
            bool right = sample.RightSignalOn && !sample.HazardsOn;
            if (sample.EngineOn && sample.SpeedKph >= 5f && sample.SpeedKph <= 45f && !sample.Fallen)
            {
                if (left) SignalMask |= 1;
                if (right) SignalMask |= 2;
            }

            if (sample.Fallen || sample.Teleported || sample.SpeedKph > 45f || !sample.EngineOn)
            {
                braking = false; usedFront = usedRear = false; brakeSeconds = 0;
                return;
            }
            if (!braking && sample.SpeedKph >= 20f && (sample.FrontBrakeOn || sample.RearBrakeOn))
            {
                braking = true; usedFront = usedRear = false; brakeSeconds = 0;
            }
            if (!braking) return;
            brakeSeconds += Math.Max(0f, sample.DeltaSeconds);
            usedFront |= sample.FrontBrakeOn;
            usedRear |= sample.RearBrakeOn;
            if (brakeSeconds > 12f)
            {
                braking = false; return;
            }
            if (sample.SpeedKph <= 5f)
            {
                if (usedFront && usedRear) ControlledStops = SaturatingAdd(ControlledStops, 1);
                braking = false;
            }
        }

        private static int SaturatingAdd(int a, int b) => b > int.MaxValue - a ? int.MaxValue : a + b;
    }
}
