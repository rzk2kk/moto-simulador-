# Personagens e animações Rocketbox

Origem: https://github.com/microsoft/Microsoft-Rocketbox

Personagens Male_Adult_01 e Male_Adult_02, com as texturas de corpo, rosto e opacidade. As animações vêm da pasta Assets/Animations do mesmo repositório. Os modelos *_Game.fbx foram preparados no Blender; Jogador_Bracos1P.fbx contém somente as mangas e os antebraços para a câmera interna. As texturas foram convertidas de TGA para PNG.

Licença: MIT, © 2020 Microsoft. O texto integral está em LICENSE.md e deve acompanhar os arquivos em redistribuições.

Estes personagens são uma base para evolução visual. A pose sobre cada moto, os encaixes de mãos nos controles e a reprodução das animações devem ser revisados no Unity Editor antes de considerar a apresentação final.
