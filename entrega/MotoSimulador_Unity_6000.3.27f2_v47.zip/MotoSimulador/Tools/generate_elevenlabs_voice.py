"""Generate offline school-story clips with ElevenLabs; never ship an API key in Unity.

Set ELEVENLABS_API_KEY in the environment and pass a voice ID from your account.
The game loads lesson_00..lesson_11 by locale from Assets/Resources/MotoSim/Voice.
"""
import argparse
import json
import os
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

root = Path(__file__).resolve().parent.parent
project = root / "unity" if (root / "unity/Assets/Resources/MotoSim/School/Curriculum.json").exists() else root
curriculum = json.loads((project / "Assets/Resources/MotoSim/School/Curriculum.json").read_text(encoding="utf-8"))
parser = argparse.ArgumentParser()
parser.add_argument("--voice-id", help="ElevenLabs voice ID; one voice is used across all languages")
parser.add_argument("--language", choices=["all", "pt-BR", "en-US", "es-ES"], default="all")
parser.add_argument("--force", action="store_true", help="Regenerate existing clips")
parser.add_argument("--dry-run", action="store_true", help="Validate the curriculum without API access")
args = parser.parse_args()

lessons = [curriculum["arrival"]] + [topic["narration"] for topic in curriculum["topics"]] + [curriculum["examIntro"]]
assert len(lessons) == len(curriculum["topics"]) + 2
locales = {"pt-BR": "pt", "en-US": "en", "es-ES": "es"}
selected = locales if args.language == "all" else {args.language: locales[args.language]}
for index, lesson in enumerate(lessons):
    for locale, field in selected.items():
        if not lesson.get(field, "").strip():
            raise SystemExit(f"Missing text for lesson {index:02d}, {locale}")

if args.dry_run:
    print(f"Validated {len(lessons)} lessons × {len(selected)} languages; no audio generated.")
    raise SystemExit(0)

api_key = os.environ.get("ELEVENLABS_API_KEY")
if not api_key:
    raise SystemExit("ELEVENLABS_API_KEY is not configured. Configure it as a secret, not in the project or chat.")
if not args.voice_id:
    raise SystemExit("Pass --voice-id with a voice from your ElevenLabs account.")

endpoint = "https://api.elevenlabs.io/v1/text-to-speech/" + urllib.parse.quote(args.voice_id, safe="") + "?output_format=mp3_44100_128"
for locale, field in selected.items():
    folder = project / "Assets/Resources/MotoSim/Voice" / locale
    folder.mkdir(parents=True, exist_ok=True)
    for index, lesson in enumerate(lessons):
        target = folder / f"lesson_{index:02d}.mp3"
        if target.exists() and not args.force:
            print(f"Keeping {locale}/lesson_{index:02d}.mp3")
            continue
        payload = json.dumps({
            "text": lesson[field],
            "model_id": "eleven_multilingual_v2",
            "voice_settings": {"stability": 0.55, "similarity_boost": 0.75, "style": 0.15, "use_speaker_boost": True},
        }).encode("utf-8")
        request = urllib.request.Request(endpoint, data=payload, method="POST", headers={
            "xi-api-key": api_key,
            "Content-Type": "application/json",
            "Accept": "audio/mpeg",
        })
        try:
            with urllib.request.urlopen(request, timeout=90) as response:
                audio = response.read()
        except urllib.error.HTTPError as error:
            try:
                detail = json.loads(error.read(4096)).get("detail", {})
                reason = detail.get("status", "unknown") if isinstance(detail, dict) else "unknown"
            except (ValueError, OSError):
                reason = "unknown"
            raise SystemExit(f"ElevenLabs returned HTTP {error.code} ({reason}) for {locale}/lesson_{index:02d}.") from None
        if len(audio) < 1000 or not audio.startswith((b"ID3", b"\xff\xfb", b"\xff\xf3", b"\xff\xf2")):
            raise SystemExit(f"Invalid MP3 data for {locale}/lesson_{index:02d}; the file was not written.")
        temporary = target.with_suffix(".tmp")
        temporary.write_bytes(audio)
        temporary.replace(target)
        print(f"Generated {locale}/lesson_{index:02d}.mp3 ({len(audio)} bytes)")
