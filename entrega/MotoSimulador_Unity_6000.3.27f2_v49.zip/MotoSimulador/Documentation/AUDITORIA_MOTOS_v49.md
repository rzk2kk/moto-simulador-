# Auditoria das motos — v49

Medição offline dos três FBX com Blender 4.3.2 e revisão dos construtores de cena. O Unity Editor e o PhysX não estão disponíveis neste ambiente; comportamento em tempo real ainda precisa ser conferido no jogo.

| Moto no jogo | Entre-eixos no FBX | Escala aplicada | Diferença entre pontos mais baixos dos pneus após escala |
| --- | ---: | ---: | ---: |
| Rota 160 Start | 4,89670 unidades | 0,26855 | 0,003 m |
| Rota 300 Street | 1,26463 unidades | 1,11495 | 0,061 m |
| Rota 1000 Adventure | 1,65961 unidades | 1,00004 | 0,004 m |

Na Street, o pneu traseiro começava cerca de 6 cm acima do contato dianteiro. A construção da cena agora corrige a inclinação do modelo antes de criar os dois WheelColliders e rejeita a preparação se restar mais de 1,5 cm de desnível. Isso trata o apoio inicial; a estabilidade em aceleração, curva e frenagem ainda precisa de teste no Unity.

Na Adventure, o garfo importado tem nove malhas chamadas `forks_l`; várias atravessam tanto a parte alta quanto a baixa da suspensão. A regra anterior usava o centro da malha e levava tubos altos junto com a roda. Agora só move as malhas que terminam abaixo do ponto de separação. Os materiais da Adventure recebem nomes estáveis e dão prioridade às texturas externas incluídas no projeto, pois algumas referências do FBX apontam para diretórios `.fbm` ausentes. Essa correção também permite que a paleta identifique as superfícies pintáveis.

Na Start, os marcadores de direção, suspensão, eixo, embreagem, freio e acelerador estão separados no FBX; o desnível de pneus medido é pequeno. A Street e a Adventure não têm pivôs independentes de manete e acelerador nos modelos fornecidos: os seus `RiderControlVisuals` ainda recebem referências nulas. Portanto, a animação individual desses comandos **não está pronta** nessas duas motos. Será preciso separar as peças das malhas, definir pivôs corretos e testar mãos, curso e direção das animações. Também é necessário conferir no Unity o contato das rodas, a direção visual e física, a textura final e a pilotagem das três motos.

As medidas são geométricas e não substituem calibração de massa, pneus, suspensão ou motor em teste real no Editor.

## Iluminação da v49

As cenas externas compartilham sol mais quente, céu procedural, névoa de distância, 22 nuvens suaves e três faixas visuais discretas de luz. A distância das sombras principais passou de 20 m para 120 m e a resolução de 1024 para 2048; o URP agora usa HDR. A garagem recebeu luz de destaque quente e preenchimento frio para mostrar a pintura e o relevo das motos. As faixas de luz são um efeito visual simples, não iluminação volumétrica física. É preciso verificar cor, transparência, desempenho e sombras no Editor Windows antes de considerá-los finais.
