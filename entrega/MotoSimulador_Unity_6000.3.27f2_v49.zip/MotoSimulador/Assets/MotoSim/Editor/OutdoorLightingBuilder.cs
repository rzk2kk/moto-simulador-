using System;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.SceneManagement;

namespace MotoSim.Editor
{
    /// <summary>Shared daylight, atmosphere and distant visual clouds for riding scenes.</summary>
    internal static class OutdoorLightingBuilder
    {
        private const string Folder = "Assets/MotoSim/Generated/Materials";
        private const string CloudRootName = "Nuvens_Exterior";

        internal static void Configure(Light sun, Vector3 siteCenter)
        {
            PrepareInspectionProject.EnsureFolder("Assets/MotoSim/Generated", "Materials");
            if (sun == null)
            {
                var lightObject = new GameObject("Luz_Solar_Exterior");
                sun = lightObject.AddComponent<Light>();
            }
            sun.type = LightType.Directional;
            sun.color = new Color(1f, .91f, .79f);
            sun.intensity = 1.65f;
            sun.shadows = LightShadows.Soft;
            sun.shadowStrength = .85f;
            sun.shadowBias = .025f;
            sun.shadowNormalBias = .25f;
            sun.transform.rotation = Quaternion.Euler(38f, -35f, 0f);
            RenderSettings.sun = sun;
            RenderSettings.ambientMode = AmbientMode.Trilight;
            RenderSettings.ambientSkyColor = new Color(.56f, .69f, .82f);
            RenderSettings.ambientEquatorColor = new Color(.36f, .41f, .44f);
            RenderSettings.ambientGroundColor = new Color(.18f, .20f, .22f);
            RenderSettings.fog = true;
            RenderSettings.fogMode = FogMode.ExponentialSquared;
            RenderSettings.fogColor = new Color(.70f, .77f, .83f);
            RenderSettings.fogDensity = .0025f;

            ConfigureSkybox();
            BuildCloudsAndRays(siteCenter);
        }

        private static void ConfigureSkybox()
        {
            const string path = Folder + "/Ceu_Exterior.mat";
            Material sky = AssetDatabase.LoadAssetAtPath<Material>(path);
            if (sky == null)
            {
                Shader shader = Shader.Find("Skybox/Procedural");
                if (shader == null)
                {
                    Debug.LogWarning("MotoSim: shader Skybox/Procedural indisponível; mantive o céu padrão.");
                    return;
                }
                sky = new Material(shader) { name = "Ceu_Exterior" };
                AssetDatabase.CreateAsset(sky, path);
            }
            sky.SetColor("_SkyTint", new Color(.42f, .59f, .79f));
            sky.SetColor("_GroundColor", new Color(.44f, .47f, .48f));
            sky.SetFloat("_AtmosphereThickness", 1.15f);
            sky.SetFloat("_SunSize", .055f);
            sky.SetFloat("_SunSizeConvergence", 4f);
            EditorUtility.SetDirty(sky);
            RenderSettings.skybox = sky;
        }

        private static void BuildCloudsAndRays(Vector3 siteCenter)
        {
            Scene scene = SceneManager.GetActiveScene();
            foreach (GameObject root in scene.GetRootGameObjects())
                if (root.name == CloudRootName) UnityEngine.Object.DestroyImmediate(root);

            Material cloudMaterial = TransparentMaterial("Nuvem_Suave", CloudTexture(), Color.white);
            Material rayMaterial = TransparentMaterial("Raio_Solar_Suave", RayTexture(),
                new Color(1f, .87f, .63f, .32f));
            var rootObject = new GameObject(CloudRootName);
            var random = new System.Random(4821);
            for (int i = 0; i < 22; i++)
            {
                float x = (float)random.NextDouble() * 320f - 160f;
                float z = (float)random.NextDouble() * 360f - 100f;
                float y = 72f + (float)random.NextDouble() * 30f;
                float width = 42f + (float)random.NextDouble() * 65f;
                float length = 18f + (float)random.NextDouble() * 22f;
                GameObject cloud = Quad(rootObject.transform, "Nuvem_" + i, cloudMaterial);
                cloud.transform.position = siteCenter + new Vector3(x, y, z);
                cloud.transform.rotation = Quaternion.Euler(90f, (float)random.NextDouble() * 180f, 0f);
                cloud.transform.localScale = new Vector3(width, length, 1f);
            }

            // Thin atmospheric ribbons suggest sunlight through cloud gaps. They
            // are visual only, with no collider and no effect on bike physics.
            for (int i = 0; i < 3; i++)
            {
                GameObject ray = Quad(rootObject.transform, "Raio_Sol_" + i, rayMaterial);
                ray.transform.position = siteCenter + new Vector3(-34f + i * 31f, 25f, 65f + i * 29f);
                ray.transform.rotation = Quaternion.Euler(0f, 180f, -22f);
                ray.transform.localScale = new Vector3(7f + i * 2f, 50f, 1f);
            }
        }

        private static GameObject Quad(Transform parent, string name, Material material)
        {
            GameObject quad = GameObject.CreatePrimitive(PrimitiveType.Quad);
            quad.name = name;
            quad.transform.SetParent(parent, false);
            UnityEngine.Object.DestroyImmediate(quad.GetComponent<Collider>());
            MeshRenderer renderer = quad.GetComponent<MeshRenderer>();
            renderer.sharedMaterial = material;
            renderer.shadowCastingMode = ShadowCastingMode.Off;
            renderer.receiveShadows = false;
            return quad;
        }

        private static Material TransparentMaterial(string name, Texture2D texture, Color tint)
        {
            string path = Folder + "/" + name + ".mat";
            Material material = AssetDatabase.LoadAssetAtPath<Material>(path);
            if (material == null)
            {
                Shader shader = Shader.Find("Universal Render Pipeline/Unlit") ?? Shader.Find("Unlit/Transparent");
                if (shader == null) throw new InvalidOperationException("Shader transparente indisponível para o céu da pista.");
                material = new Material(shader) { name = name };
                AssetDatabase.CreateAsset(material, path);
            }
            material.SetTexture("_BaseMap", texture);
            material.SetTexture("_MainTex", texture);
            material.SetColor("_BaseColor", tint);
            material.SetColor("_Color", tint);
            material.SetFloat("_Surface", 1f);
            material.SetFloat("_SrcBlend", (float)BlendMode.SrcAlpha);
            material.SetFloat("_DstBlend", (float)BlendMode.OneMinusSrcAlpha);
            material.SetFloat("_ZWrite", 0f);
            material.SetFloat("_Cull", 0f);
            material.SetOverrideTag("RenderType", "Transparent");
            material.EnableKeyword("_SURFACE_TYPE_TRANSPARENT");
            material.renderQueue = (int)RenderQueue.Transparent;
            EditorUtility.SetDirty(material);
            return material;
        }

        private static Texture2D CloudTexture()
        {
            const string path = Folder + "/Nuvem_Suave.asset";
            Texture2D texture = AssetDatabase.LoadAssetAtPath<Texture2D>(path);
            if (texture != null) return texture;
            texture = new Texture2D(128, 128, TextureFormat.RGBA32, false) { name = "Nuvem_Suave" };
            texture.wrapMode = TextureWrapMode.Clamp;
            texture.filterMode = FilterMode.Bilinear;
            for (int y = 0; y < 128; y++)
                for (int x = 0; x < 128; x++)
                {
                    float u = (x - 63.5f) / 64f, v = (y - 63.5f) / 64f;
                    float shape = Mathf.Clamp01(1f - u * u - v * v * 1.4f);
                    float noise = .55f * Mathf.PerlinNoise(x * .045f, y * .045f) +
                        .30f * Mathf.PerlinNoise(x * .095f + 17f, y * .095f) +
                        .15f * Mathf.PerlinNoise(x * .19f, y * .19f + 41f);
                    float alpha = Mathf.Pow(shape, 1.7f) * Mathf.SmoothStep(0f, .72f, noise) * .72f;
                    texture.SetPixel(x, y, new Color(.95f, .97f, 1f, alpha));
                }
            texture.Apply();
            AssetDatabase.CreateAsset(texture, path);
            return texture;
        }

        private static Texture2D RayTexture()
        {
            const string path = Folder + "/Raio_Solar_Suave.asset";
            Texture2D texture = AssetDatabase.LoadAssetAtPath<Texture2D>(path);
            if (texture != null) return texture;
            texture = new Texture2D(64, 128, TextureFormat.RGBA32, false) { name = "Raio_Solar_Suave" };
            texture.wrapMode = TextureWrapMode.Clamp;
            texture.filterMode = FilterMode.Bilinear;
            for (int y = 0; y < 128; y++)
                for (int x = 0; x < 64; x++)
                {
                    float horizontal = Mathf.Pow(Mathf.Clamp01(1f - Mathf.Abs(x - 31.5f) / 31.5f), 2f);
                    float vertical = Mathf.Sin(y / 127f * Mathf.PI);
                    texture.SetPixel(x, y, new Color(1f, .92f, .75f, horizontal * vertical * .20f));
                }
            texture.Apply();
            AssetDatabase.CreateAsset(texture, path);
            return texture;
        }
    }
}
