using System;
using System.IO;
using System.Linq;
using MotoSim.Core;
using MotoSim.Unity;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace MotoSim.Editor
{
    /// <summary>Builds a separate provisional riding scene for the user-supplied Africa Twin model.</summary>
    public static class PrepareAfricaTwinProject
    {
        internal const string ScenePath = "Assets/MotoSim/Generated/Africa_Twin_TesteFisico.unity";
        private const string ModelPath = "Assets/MotoSim/Art/Honda_Africa_Twin_MotoSim.fbx";
        private const string Generated = "Assets/MotoSim/Generated";
        private static string Root => Path.GetFullPath(Path.Combine(Application.dataPath, ".."));

        [MenuItem("MotoSim/Preparar Honda Africa Twin")]
        public static void RunSetup()
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode || EditorApplication.isCompiling || EditorApplication.isUpdating)
            { EditorApplication.isPlaying = false; EditorApplication.delayCall += RunSetup; return; }
            try
            {
                PrepareInspectionProject.EnsureFolder("Assets/MotoSim", "Generated");
                PrepareInspectionProject.ConfigurePipeline();
                if (AssetDatabase.LoadAssetAtPath<SceneAsset>(ScenePath) == null) CreateScene();
                else PrepareInspectionProject.OpenPreparedScene(ScenePath);
                AssetDatabase.SaveAssets();
                File.WriteAllText(Path.Combine(Root, "ProjectSettings/MotoSimAfricaTwinSetup.json"),
                    "{\"scenePrepared\":true,\"bike\":\"Honda Africa Twin\",\"referenceCalibration\":false}");
                Debug.Log("MotoSim: Honda Africa Twin adicionada como moto selecionável; perfil físico provisório.");
            }
            catch (Exception error)
            {
                Debug.LogException(error);
                File.WriteAllText(Path.Combine(Root, "MotoSim_AfricaTwin_Setup_Error.txt"), error.ToString());
                if (!Application.isBatchMode)
                    EditorUtility.DisplayDialog("MotoSim — Africa Twin", error.Message, "OK");
            }
        }

        private static void CreateScene()
        {
            GameObject model = AssetDatabase.LoadAssetAtPath<GameObject>(ModelPath);
            if (model == null) throw new InvalidOperationException("O FBX da Honda Africa Twin ainda não foi importado: " + ModelPath);
            var profile = new BikePhysicsProfile
            {
                WheelbaseMetres = 1.65967f,
                BikeMassKg = 230f,
                RiderMassKg = 75f,
                FrontWeightFraction = .49f,
                SuspensionTravelMetres = .20f,
                SuspensionFrequencyHz = 2.5f,
                SuspensionDampingRatio = .82f,
                CenterOfMassHeightMetres = .64f,
                TrainingSpeedLimitKph = 200f,
                GearSpeedLimitsKph = new[] { 30f, 55f, 85f, 120f, 160f, 200f },
                ClutchPullPerSecond = 15f,
                ClutchReleasePerSecond = 7f,
                ReferenceVerified = false,
                ReferenceNote = "Perfil de teste provisório da Africa Twin do GLB enviado; confirmar ano e versão antes de calibrar.",
                ReferenceUrl = ""
            };
            profile.Validate();

            var recovered = PrepareInspectionProject.PreserveUnnamedScenes();
            Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Additive);
            SceneManager.SetActiveScene(scene);
            var root = new GameObject("Honda_Africa_Twin_Fisica_Provisoria");
            var visual = PrefabUtility.InstantiatePrefab(model, scene) as GameObject;
            if (visual == null) throw new InvalidOperationException("O modelo da Honda Africa Twin não pôde ser instanciado.");
            visual.name = "Modelo_Honda_Africa_Twin";
            visual.transform.SetParent(root.transform, true);

            Transform front = Find(visual, "Eixo_Roda_Dianteira");
            Transform rear = Find(visual, "Eixo_Roda_Traseira");
            Vector3 direction = Vector3.ProjectOnPlane(front.position - rear.position, Vector3.up);
            if (direction.sqrMagnitude < .000001f) throw new InvalidOperationException("Os eixos das rodas da Africa Twin estão sobrepostos.");
            visual.transform.rotation = Quaternion.FromToRotation(direction.normalized, Vector3.forward) * visual.transform.rotation;
            float measuredWheelbase = Vector3.ProjectOnPlane(front.position - rear.position, Vector3.up).magnitude;
            float scale = VehicleCalibration.UniformScale(measuredWheelbase, profile.WheelbaseMetres);
            visual.transform.localScale *= scale;
            Bounds tyreBounds = BoundsOf(FindRenderers(visual, "Pneu_"));
            visual.transform.position += new Vector3(-rear.position.x, -tyreBounds.min.y, -rear.position.z);

            Vector3 frontCenter = front.position;
            Vector3 rearCenter = rear.position;
            float frontRadius = TyreRadius(Find(visual, "Pneu_Dianteiro_AfricaTwin"));
            float rearRadius = TyreRadius(Find(visual, "Pneu_Traseiro_AfricaTwin"));
            if (Mathf.Abs(Vector3.ProjectOnPlane(frontCenter - rearCenter, Vector3.up).magnitude - profile.WheelbaseMetres) > .03f)
                throw new InvalidOperationException("O entre-eixos importado da Africa Twin não bate com a escala.");

            foreach (Renderer renderer in visual.GetComponentsInChildren<Renderer>(true))
            {
                Material[] materials = renderer.sharedMaterials;
                for (int i = 0; i < materials.Length; i++)
                    materials[i] = PrepareAfricaMaterial(materials[i], renderer.name);
                renderer.sharedMaterials = materials;
            }

            var bodyCollider = root.AddComponent<BoxCollider>();
            bodyCollider.center = new Vector3(0f, .78f, .78f);
            bodyCollider.size = new Vector3(.72f, 1.25f, 1.7f);
            var body = root.AddComponent<Rigidbody>();
            body.mass = profile.TotalMassKg;
            body.centerOfMass = new Vector3(0f, profile.CenterOfMassHeightMetres, profile.WheelbaseMetres * profile.FrontWeightFraction);
            body.interpolation = RigidbodyInterpolation.Interpolate;
            body.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
            body.solverIterations = 16; body.solverVelocityIterations = 8; body.maxAngularVelocity = 5f;

            WheelCollider frontWheel = MakeWheel(root, "RodaFisica_AfricaTwin_Dianteira", frontCenter,
                frontRadius, profile.TotalMassKg * profile.FrontWeightFraction, profile);
            WheelCollider rearWheel = MakeWheel(root, "RodaFisica_AfricaTwin_Traseira", rearCenter,
                rearRadius, profile.TotalMassKg * (1f - profile.FrontWeightFraction), profile);
            var controller = root.AddComponent<MotorcycleController>();
            controller.Configure(frontWheel, rearWheel, profile, new DrivetrainSettings
            {
                IdleRpm = 1400f, StallRpm = 600f, RedlineRpm = 7500f, PeakTorqueRpm = 6250f,
                PeakTorqueNm = 95f, EngineInertiaKgM2 = .22f, EngineFrictionNm = 3.8f,
                EngineViscousDrag = .006f, ClosedThrottlePumpingDrag = .014f,
                IdleControlGain = .23f, MaxIdleTorqueNm = 20f, ClutchCapacityNm = 145f,
                ClutchSlipGain = .72f, PrimaryRatio = 3f, FinalRatio = 3f,
                MaxFrontBrakeNm = 310f, MaxRearBrakeNm = 190f, TransmissionEfficiency = .95f
            });
            root.AddComponent<MotorcycleAudio>().Configure(controller);
            root.AddComponent<KeyboardRiderInput>();
            root.AddComponent<RiderControlVisuals>().Configure(null, null, null, null, controller);
            root.AddComponent<MotorcyclePaint>().Configure(visual, 2);

            Renderer headlamp = FindRendererByMaterial(visual, "headlight") ?? FindRendererByName(visual, "headlight_l");
            Renderer tailLamp = FindRendererByMaterial(visual, "taillight") ?? FindRendererByName(visual, "taillight_l");
            Renderer[] left = FindRenderers(visual, "indicator_l");
            Renderer[] right = FindRenderers(visual, "indicator_r");
            if (headlamp == null || tailLamp == null || left.Length == 0 || right.Length == 0)
                throw new InvalidOperationException("Não encontrei farol, lanterna ou setas no modelo Africa Twin.");
            var lighting = root.AddComponent<MotorcycleLighting>();
            lighting.Configure(visual, null, controller, headlamp, tailLamp, left, right);
            root.AddComponent<WheelPoseBinding>().Configure(frontWheel, front, frontCenter);
            root.AddComponent<WheelPoseBinding>().Configure(rearWheel, rear, rearCenter);
            root.transform.position = new Vector3(0f, 0f, -3.8f);
            body.ResetInertiaTensor();
            TrainingCourseBuilder.Build();

            var cameraObject = new GameObject("Camera_Acompanhamento_Africa_Twin"); cameraObject.tag = "MainCamera";
            var camera = cameraObject.AddComponent<Camera>(); camera.fieldOfView = 55f; camera.nearClipPlane = .05f; camera.farClipPlane = 500f;
            camera.clearFlags = CameraClearFlags.SolidColor; camera.backgroundColor = new Color(.25f, .34f, .45f);
            cameraObject.AddComponent<AudioListener>();
            var rideCamera = cameraObject.AddComponent<RideCamera>(); rideCamera.Configure(root.transform);
            cameraObject.AddComponent<RideTelemetry>().Configure(controller, rideCamera, lighting);

            var sunObject = new GameObject("Luz_Solar_Africa_Twin"); var sun = sunObject.AddComponent<Light>();
            sun.type = LightType.Directional; sun.intensity = 1.5f; sun.shadows = LightShadows.Soft;
            sunObject.transform.rotation = Quaternion.Euler(45f, -35f, 0f); RenderSettings.sun = sun;
            RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Trilight;
            RenderSettings.ambientSkyColor = new Color(.55f, .62f, .7f);
            RenderSettings.ambientEquatorColor = new Color(.3f, .32f, .35f);
            RenderSettings.ambientGroundColor = new Color(.15f, .14f, .13f);

            if (!EditorSceneManager.SaveScene(scene, ScenePath)) throw new IOException("Não foi possível salvar a cena da Africa Twin.");
            PrepareInspectionProject.CloseRecoveredScenes(recovered);
            File.WriteAllText(Path.Combine(Root, "ProjectSettings/MotoSimAfricaTwinCalibration.json"),
                "{\"wheelbaseMetres\":" + F(profile.WheelbaseMetres) + ",\"measuredWheelbaseMetres\":" + F(measuredWheelbase) +
                ",\"scaleApplied\":" + F(scale) + ",\"frontRadiusMetres\":" + F(frontRadius) +
                ",\"rearRadiusMetres\":" + F(rearRadius) + ",\"totalMassKg\":" + F(profile.TotalMassKg) +
                ",\"gearCount\":6,\"referenceVerified\":false}");
        }

        internal static Material PrepareAfricaMaterial(Material source, string rendererName)
        {
            if (source == null) return PrepareInspectionProject.PrepareMaterial(null, rendererName);
            string safeName = string.Concat(source.name.Select(ch => Path.GetInvalidFileNameChars().Contains(ch) ? '_' : ch));
            string assetPath = Generated + "/Materials/AfricaTwin_" + safeName + ".mat";
            Material material = AssetDatabase.LoadAssetAtPath<Material>(assetPath);
            if (material == null)
            {
                Shader shader = Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Standard");
                material = new Material(shader);
                AssetDatabase.CreateAsset(material, assetPath);
            }

            Color color = source.HasProperty("_BaseColor") ? source.GetColor("_BaseColor") :
                source.HasProperty("_Color") ? source.GetColor("_Color") : Color.white;
            if (material.HasProperty("_BaseColor")) material.SetColor("_BaseColor", color);
            if (material.HasProperty("_Color")) material.SetColor("_Color", color);
            Texture texture = source.mainTexture;
            if (texture == null)
                texture = AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/MotoSim/Art/Textures/AfricaTwin/" + safeName + ".png");
            if (texture != null)
            {
                if (material.HasProperty("_BaseMap")) material.SetTexture("_BaseMap", texture);
                if (material.HasProperty("_MainTex")) material.SetTexture("_MainTex", texture);
            }
            return material;
        }

        private static WheelCollider MakeWheel(GameObject root, string name, Vector3 center, float radius, float supportedMass, BikePhysicsProfile p)
        {
            var wheelObject = new GameObject(name); wheelObject.transform.SetParent(root.transform, false);
            wheelObject.transform.position = center + Vector3.up * p.SuspensionTravelMetres * .5f;
            var wheel = wheelObject.AddComponent<WheelCollider>(); wheel.radius = radius; wheel.mass = 14f;
            wheel.sprungMass = supportedMass; wheel.suspensionDistance = p.SuspensionTravelMetres;
            wheel.forceAppPointDistance = .05f; wheel.wheelDampingRate = .55f;
            float spring = VehicleCalibration.SpringRate(supportedMass, p.SuspensionFrequencyHz * .82f);
            wheel.suspensionSpring = new JointSpring
            {
                spring = spring,
                damper = VehicleCalibration.DamperRate(supportedMass, spring, Mathf.Max(1.05f, p.SuspensionDampingRatio)),
                targetPosition = .5f
            };
            WheelFrictionCurve forward = wheel.forwardFriction; forward.extremumSlip = .18f; forward.extremumValue = 1f;
            forward.asymptoteSlip = .38f; forward.asymptoteValue = .82f; forward.stiffness = 1.2f; wheel.forwardFriction = forward;
            WheelFrictionCurve sideways = wheel.sidewaysFriction; sideways.extremumSlip = .3f; sideways.extremumValue = .85f;
            sideways.asymptoteSlip = .65f; sideways.asymptoteValue = .68f; sideways.stiffness = .82f; wheel.sidewaysFriction = sideways;
            wheel.ConfigureVehicleSubsteps(100f, 16, 16); return wheel;
        }

        private static Transform Find(GameObject model, string name) => FindOptional(model, name) ??
            throw new InvalidOperationException("Componente da Africa Twin não encontrado: " + name);
        private static Transform FindOptional(GameObject model, string name) => model.GetComponentsInChildren<Transform>(true).FirstOrDefault(t => t.name == name);
        private static Renderer[] FindRenderers(GameObject model, string prefix) => model.GetComponentsInChildren<Renderer>(true)
            .Where(r => r.name.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)).ToArray();
        private static Renderer FindRendererByMaterial(GameObject model, string token) => model.GetComponentsInChildren<Renderer>(true)
            .FirstOrDefault(r => r.sharedMaterials.Any(m => m != null && m.name.IndexOf(token, StringComparison.OrdinalIgnoreCase) >= 0));
        private static Renderer FindRendererByName(GameObject model, string token) => model.GetComponentsInChildren<Renderer>(true)
            .FirstOrDefault(r => r.name.IndexOf(token, StringComparison.OrdinalIgnoreCase) >= 0);
        private static Bounds BoundsOf(Renderer[] renderers)
        {
            if (renderers == null || renderers.Length == 0) throw new InvalidOperationException("Não encontrei os pneus da Africa Twin.");
            Bounds bounds = renderers[0].bounds; foreach (Renderer renderer in renderers) bounds.Encapsulate(renderer.bounds); return bounds;
        }
        private static float TyreRadius(Transform tyre)
        {
            Renderer renderer = tyre.GetComponent<Renderer>() ?? tyre.GetComponentInChildren<Renderer>(true);
            if (renderer == null) throw new InvalidOperationException("Pneu sem Renderer: " + tyre.name);
            float radius = renderer.bounds.extents.y;
            if (radius < .15f || radius > .65f) throw new InvalidOperationException("Raio de pneu fora da faixa: " + radius);
            return radius;
        }
        private static string F(float value) => value.ToString("R", System.Globalization.CultureInfo.InvariantCulture);
    }
}
