using UnityEngine;

namespace MotoSim.Unity
{
    /// <summary>Applies the saved showroom paint to the bike's painted body panels at runtime.</summary>
    public sealed class MotorcyclePaint : MonoBehaviour
    {
        [SerializeField] private GameObject visualModel;
        [SerializeField, Range(0, 2)] private int bikeIndex;

        public void Configure(GameObject model, int index)
        {
            visualModel = model;
            bikeIndex = Mathf.Clamp(index, 0, 2);
        }

        private void Start()
        {
            if (visualModel == null) visualModel = gameObject;
            Apply(visualModel, bikeIndex, MotoCareerProgress.PaintIndex(bikeIndex));
        }

        public static void Apply(GameObject visual, int bike, int paintIndex)
        {
            if (visual == null) return;
            Color color = MotoCareerProgress.PaintColor(paintIndex);
            foreach (Renderer renderer in visual.GetComponentsInChildren<Renderer>(true))
            {
                if (!IsPaintedSurface(renderer, bike)) continue;
                var block = new MaterialPropertyBlock();
                if (IsPaintedRendererName(renderer, bike))
                {
                    renderer.GetPropertyBlock(block);
                    ApplyColor(block, color);
                    renderer.SetPropertyBlock(block);
                    continue;
                }

                Material[] slots = renderer.sharedMaterials;
                for (int slot = 0; slot < slots.Length; slot++)
                {
                    if (!IsPaintedMaterial(slots[slot], bike)) continue;
                    renderer.GetPropertyBlock(block, slot);
                    ApplyColor(block, color);
                    renderer.SetPropertyBlock(block, slot);
                }
            }
        }

        private static bool IsPaintedSurface(Renderer renderer, int bike)
        {
            if (IsPaintedRendererName(renderer, bike)) return true;
            foreach (Material material in renderer.sharedMaterials)
                if (IsPaintedMaterial(material, bike)) return true;
            return false;
        }

        private static bool IsPaintedRendererName(Renderer renderer, int bike)
        {
            string name = renderer.name.ToLowerInvariant();
            if (bike == 0)
                return name.Contains("paralama_dianteiro") || name.Contains("carenagem_farol") ||
                    name.Contains("tanque") || name.Contains("lateral_pintada");
            return bike == 1 && (name == "plane019" || name == "plane053" || name == "plane057_1");
        }

        private static bool IsPaintedMaterial(Material material, int bike)
        {
            if (material == null) return false;
            string name = material.name.ToLowerInvariant();
            if (bike == 1)
                return name.Contains("cor_moto") || name.Contains("material_tanque") || name.Contains("mascara_tanque");
            if (bike == 2)
                return (name.Contains("plastics_d") || name == "plastic") &&
                    !name.Contains("indicator") && !name.Contains("light") && !name.Contains("wheel") &&
                    !name.Contains("tyre") && !name.Contains("grip");
            return false;
        }

        private static void ApplyColor(MaterialPropertyBlock block, Color color)
        {
            block.SetColor("_BaseColor", color);
            block.SetColor("_Color", color);
        }
    }
}
