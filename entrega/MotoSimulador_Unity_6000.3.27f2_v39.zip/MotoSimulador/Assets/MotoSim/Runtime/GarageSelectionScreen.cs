using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace MotoSim.Unity
{
    /// <summary>Simple responsive bike selector for the MotoSim garage and async loading overlay.</summary>
    public sealed class GarageSelectionScreen : MonoBehaviour
    {
        private enum ScreenMode { MainMenu, Garage, Settings }

        [SerializeField] private GameObject[] displayModels = new GameObject[0];
        [SerializeField] private string[] bikeNames = new string[0];
        [SerializeField] private string[] scenePaths = new string[0];
        [SerializeField] private Texture2D officialLoadingBackground;
        [SerializeField] private Texture2D brandLogo;
        private int selectedIndex;
        private int selectedPaint;
        private bool loading;
        private float loadProgress;
        private ScreenMode screenMode = ScreenMode.MainMenu;
        private float masterVolume = 1f;
        private int selectedQuality;
        private string noticeText;
        private float noticeUntil;
        private readonly Dictionary<int, float> buttonHover = new Dictionary<int, float>();
        [SerializeField, Min(1f)] private float previewSpinSeconds = 10f;
        private GUIStyle title, heading, body, small, button, card, menuButton, logo, redLogo;

        public void Configure(GameObject[] models, string[] names, string[] scenes, Texture2D loadingBackground, Texture2D logoImage)
        {
            displayModels = models ?? new GameObject[0];
            bikeNames = names ?? new string[0];
            scenePaths = scenes ?? new string[0];
            officialLoadingBackground = loadingBackground;
            brandLogo = logoImage;
            MotoCareerProgress.EnsureInitialized();
            selectedIndex = Mathf.Clamp(PlayerPrefs.GetInt("MotoSim.GarageSelection", 0), 0, Mathf.Max(0, bikeNames.Length - 1));
            selectedPaint = MotoCareerProgress.PaintIndex(selectedIndex);
            masterVolume = PlayerPrefs.GetFloat("MotoSim.MasterVolume", 1f);
            selectedQuality = Mathf.Clamp(QualitySettings.GetQualityLevel(), 0, Mathf.Max(0, QualitySettings.names.Length - 1));
            ApplySelection();
        }

        private void Start()
        {
            MotoCareerProgress.EnsureInitialized();
            selectedIndex = Mathf.Clamp(PlayerPrefs.GetInt("MotoSim.GarageSelection", MotoCareerProgress.StarterBikeIndex),
                0, Mathf.Max(0, bikeNames.Length - 1));
            string saved = PlayerPrefs.GetString("MotoSim.SelectedBike", "");
            for (int i = 0; i < bikeNames.Length; i++)
                if (bikeNames[i] == saved) selectedIndex = i;
            masterVolume = PlayerPrefs.GetFloat("MotoSim.MasterVolume", 1f);
            AudioListener.volume = masterVolume;
            selectedQuality = Mathf.Clamp(PlayerPrefs.GetInt("MotoSim.Quality", QualitySettings.GetQualityLevel()),
                0, Mathf.Max(0, QualitySettings.names.Length - 1));
            if (QualitySettings.names.Length > 0) QualitySettings.SetQualityLevel(selectedQuality, true);
            selectedPaint = MotoCareerProgress.PaintIndex(selectedIndex);
            if (PlayerPrefs.GetInt("MotoSim.OpenGarageOnStart", 0) == 1)
            {
                screenMode = ScreenMode.Garage;
                PlayerPrefs.DeleteKey("MotoSim.OpenGarageOnStart");
                PlayerPrefs.Save();
            }
            ApplySelection();
        }

        private void Update()
        {
            if (loading) return;
            if (screenMode == ScreenMode.Garage && selectedIndex >= 0 && selectedIndex < displayModels.Length)
            {
                GameObject selected = displayModels[selectedIndex];
                if (selected != null && selected.activeInHierarchy)
                    selected.transform.Rotate(Vector3.up, 360f / Mathf.Max(1f, previewSpinSeconds) * Time.deltaTime, Space.World);
            }
            if (!string.IsNullOrEmpty(noticeText) && Time.unscaledTime >= noticeUntil) noticeText = null;
        }

        private void ApplySelection()
        {
            for (int i = 0; i < displayModels.Length; i++)
                if (displayModels[i] != null)
                {
                    displayModels[i].SetActive(screenMode == ScreenMode.Garage && i == selectedIndex);
                    MotorcyclePaint.Apply(displayModels[i], i, MotoCareerProgress.PaintIndex(i));
                }
        }

        private void EnsureStyles()
        {
            if (title != null) return;
            title = new GUIStyle(GUI.skin.label) { fontSize = 27, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleLeft, normal = { textColor = Color.white } };
            heading = new GUIStyle(GUI.skin.label) { fontSize = 18, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleLeft, normal = { textColor = Color.white } };
            body = new GUIStyle(GUI.skin.label) { fontSize = 14, alignment = TextAnchor.MiddleLeft, wordWrap = true, normal = { textColor = new Color(.9f, .92f, .95f) } };
            small = new GUIStyle(body) { fontSize = 11, normal = { textColor = new Color(.76f, .79f, .84f) } };
            button = new GUIStyle(GUI.skin.button) { fontSize = 15, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleCenter };
            card = new GUIStyle(GUI.skin.button) { fontSize = 14, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleLeft, padding = new RectOffset(15, 10, 8, 8), wordWrap = true };
            menuButton = new GUIStyle(GUI.skin.button) { fontSize = 20, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleLeft, padding = new RectOffset(20, 12, 8, 8) };
            logo = new GUIStyle(GUI.skin.label) { fontSize = 39, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleRight, normal = { textColor = Color.white } };
            redLogo = new GUIStyle(logo) { alignment = TextAnchor.MiddleLeft, normal = { textColor = new Color(.95f, .025f, .035f) } };
        }

        private void OnGUI()
        {
            GUI.matrix = Matrix4x4.identity;
            GUI.color = Color.white;
            GUI.backgroundColor = Color.white;
            EnsureStyles();
            if (loading) { DrawLoading(); GUI.matrix = Matrix4x4.identity; return; }
            float w = Screen.width, h = Screen.height;
            float scale = Mathf.Clamp(Mathf.Min(w / 1440f, h / 900f), .68f, 1.35f);
            GUI.matrix = Matrix4x4.Scale(new Vector3(scale, scale, 1));
            w /= scale; h /= scale;

            if (screenMode == ScreenMode.MainMenu)
            {
                DrawMainMenu(w, h);
                GUI.matrix = Matrix4x4.identity;
                return;
            }
            if (screenMode == ScreenMode.Settings)
            {
                DrawSettings(w, h);
                GUI.matrix = Matrix4x4.identity;
                return;
            }

            DrawGarage(w, h);
            GUI.matrix = Matrix4x4.identity;
        }

        private void DrawMainMenu(float width, float height)
        {
            Fill(new Rect(0, 0, width, height), new Color(.008f, .012f, .02f, .26f));
            Fill(new Rect(0, 0, width, 86), new Color(.012f, .015f, .02f, .82f));
            DrawCareerProfile(new Rect(width - 420, 14, 400, 60));

            Rect brand = new Rect(width * .36f, height * .11f, width * .52f, height * .29f);
            DrawBrandLogo(brand);
            Fill(new Rect(brand.x + brand.width * .08f, brand.yMax + 3, brand.width * .84f, 4), new Color(.9f, .025f, .04f, .95f));
            GUI.Label(new Rect(brand.x, brand.yMax + 18, brand.width, 34), "MODO CARREIRA  •  ESCOLA DE PILOTAGEM", heading);

            float left = 24, menuWidth = Mathf.Clamp(width * .25f, 300, 370);
            float buttonHeight = Mathf.Clamp(height * .078f, 58, 72);
            float gap = 12;
            float y = height * .29f;
            DrawMenuButton(new Rect(left, y, menuWidth, buttonHeight), "▶   CONTINUAR", true, 1,
                () =>
                {
                    selectedIndex = Mathf.Clamp(PlayerPrefs.GetInt("MotoSim.GarageSelection", 0), 0, Mathf.Max(0, bikeNames.Length - 1));
                    if (!MotoCareerProgress.IsOwned(selectedIndex)) selectedIndex = MotoCareerProgress.StarterBikeIndex;
                    if (PlayerPrefs.GetInt("MotoSim.HasProgress", 0) == 1) StartCoroutine(LoadSelectedScene());
                    else OpenGarage();
                });
            y += buttonHeight + gap;
            DrawMenuButton(new Rect(left, y, menuWidth, buttonHeight), "◉   NOVO JOGO", false, 2, StartNewGame);
            y += buttonHeight + gap;
            DrawMenuButton(new Rect(left, y, menuWidth, buttonHeight), "⌂   GARAGEM", false, 3, OpenGarage);
            y += buttonHeight + gap;
            DrawMenuButton(new Rect(left, y, menuWidth, buttonHeight), "⚙   CONFIGURAÇÕES", false, 4,
                () => screenMode = ScreenMode.Settings);
            y += buttonHeight + gap;
            DrawMenuButton(new Rect(left, y, menuWidth, buttonHeight), "⇥   SAIR", false, 5, Application.Quit);

            Rect career = new Rect(width * .38f, height * .54f, width * .54f, height * .25f);
            Fill(career, new Color(.012f, .018f, .026f, .67f));
            Stroke(career, new Color(.85f, .09f, .08f, .56f), 1.5f);
            GUI.Label(new Rect(career.x + 26, career.y + 18, career.width - 52, 38), "SUA HISTÓRIA COMEÇA NA START", title);
            GUI.Label(new Rect(career.x + 28, career.y + 62, career.width - 56, 36),
                "Pilote, conclua treinos e ganhe créditos para comprar novas motos.", body);
            GUI.Label(new Rect(career.x + 28, career.y + 111, career.width - 56, 26),
                "RECOMPENSA DE CARREIRA   " + MotoCareerProgress.FormatCredits(MotoCareerProgress.CreditRewardPerKilometre) + "  A CADA KM", small);

            GUI.Label(new Rect(22, height - 42, 160, 24), "v1.0.0", small);
            GUI.Label(new Rect(width - 180, height - 44, 158, 28), "BRASIL  ▾", small);
            DrawNotice(width, height);
        }

        private void DrawGarage(float width, float height)
        {
            Fill(new Rect(0, 0, width, height), new Color(.008f, .012f, .02f, .16f));
            Rect top = new Rect(0, 0, width, 82);
            Fill(top, new Color(.012f, .015f, .02f, .9f));
            if (DrawInteractiveButton(new Rect(18, 16, 142, 50), "‹  VOLTAR", 10, false, button)) OpenMainMenu();
            GUI.Label(new Rect(178, 13, 220, 52), "GARAGEM", title);
            DrawBrandLogo(new Rect(width * .425f, 3, 230, 76));
            DrawCareerProfile(new Rect(width - 420, 12, 400, 60));

            float margin = 22f;
            float leftX = margin, leftY = 106f, leftW = Mathf.Clamp(width * .235f, 300f, 360f);
            float panelH = Mathf.Min(height - 185f, height * .70f);
            Rect leftPanel = new Rect(leftX, leftY, leftW, panelH);
            DrawPanel(leftPanel);
            GUI.Label(new Rect(leftX + 18, leftY + 14, leftW - 36, 32), "ESCOLHA SUA MOTO", heading);
            GUI.Label(new Rect(leftX + 18, leftY + 45, leftW - 36, 24),
                "NÍVEL " + MotoCareerProgress.CareerLevel + "   •   " + MotoCareerProgress.FormatCredits(MotoCareerProgress.Balance), small);

            int count = Mathf.Min(bikeNames.Length, scenePaths.Length);
            float cardHeight = Mathf.Min(94f, (panelH - 170f) / Mathf.Max(1, count));
            for (int i = 0; i < count; i++)
            {
                float y = leftY + 82f + i * (cardHeight + 10f);
                bool owned = MotoCareerProgress.IsOwned(i);
                bool isSelected = i == selectedIndex;
                string state = owned ? (i == 0 ? "MOTO INICIAL  •  GRÁTIS" : "DESBLOQUEADA") :
                    "BLOQUEADA  •  " + MotoCareerProgress.FormatCredits(MotoCareerProgress.PriceFor(i));
                GUI.backgroundColor = isSelected ? new Color(.46f, .018f, .03f, .98f) : new Color(.035f, .04f, .05f, .94f);
                bool clicked = DrawInteractiveButton(new Rect(leftX + 12, y, leftW - 24, cardHeight),
                    bikeNames[i] + "\n" + state, 20 + i, isSelected, card);
                GUI.backgroundColor = Color.white;
                if (clicked)
                {
                    selectedIndex = i;
                    selectedPaint = MotoCareerProgress.PaintIndex(i);
                    PlayerPrefs.SetInt("MotoSim.GarageSelection", i);
                    ApplySelection();
                }
            }
            GUI.Label(new Rect(leftX + 18, leftPanel.yMax - 74f, leftW - 36, 58f),
                "Pilote a Start para receber " + MotoCareerProgress.FormatCredits(MotoCareerProgress.CreditRewardPerKilometre) + " a cada quilômetro.", small);

            float rightW = Mathf.Clamp(width * .24f, 318f, 360f);
            float rightX = width - rightW - margin;
            Rect info = new Rect(rightX, leftY + 4, rightW, Mathf.Min(panelH - 10, 535f));
            DrawPanel(info);
            string name = selectedIndex < bikeNames.Length ? bikeNames[selectedIndex] : "Moto";
            GUI.Label(new Rect(rightX + 20, info.y + 18, rightW - 40, 58), name, title);
            bool selectedOwned = MotoCareerProgress.IsOwned(selectedIndex);
            string stateText = selectedOwned ? (selectedIndex == 0 ? "MOTO INICIAL  •  SEM CUSTO" : "MOTO DESBLOQUEADA") : "MOTO BLOQUEADA";
            GUI.Label(new Rect(rightX + 20, info.y + 75, rightW - 40, 28), stateText, heading);
            Fill(new Rect(rightX + 18, info.y + 112, rightW - 36, 2), new Color(.86f, .035f, .045f, .9f));
            GUI.Label(new Rect(rightX + 20, info.y + 126, rightW - 40, 24), "PREÇO DE COMPRA", small);
            GUI.Label(new Rect(rightX + 20, info.y + 148, rightW - 40, 42),
                selectedIndex == MotoCareerProgress.StarterBikeIndex ? "GRÁTIS" : MotoCareerProgress.FormatCredits(MotoCareerProgress.PriceFor(selectedIndex)), title);
            GUI.Label(new Rect(rightX + 20, info.y + 194, rightW - 40, 25),
                "SALDO  " + MotoCareerProgress.FormatCredits(MotoCareerProgress.Balance), body);

            GUI.Label(new Rect(rightX + 20, info.y + 241, rightW - 40, 25), "PINTURA DA MOTO", heading);
            GUI.Label(new Rect(rightX + 20, info.y + 268, rightW - 40, 20), MotoCareerProgress.PaintName(selectedPaint), small);
            float swatchY = info.y + 294, swatchSize = 46f, swatchGap = 12f;
            float swatchX = rightX + 20;
            for (int color = 0; color < 4; color++)
            {
                Rect swatch = new Rect(swatchX + color * (swatchSize + swatchGap), swatchY, swatchSize, swatchSize);
                if (DrawPaintSwatch(swatch, color, 50 + color))
                {
                    selectedPaint = color;
                    MotoCareerProgress.SetPaintIndex(selectedIndex, color);
                    if (selectedIndex >= 0 && selectedIndex < displayModels.Length)
                        MotorcyclePaint.Apply(displayModels[selectedIndex], selectedIndex, color);
                    ShowNotice("Pintura " + MotoCareerProgress.PaintName(color) + " aplicada.");
                }
            }
            GUI.Label(new Rect(rightX + 20, info.y + 358, rightW - 40, 54),
                "A pintura acompanha a moto na garagem e durante a pilotagem.", small);

            float actionY = height - 82f;
            float actionW = Mathf.Clamp(width * .19f, 220f, 270f);
            float gap = 18f;
            float actionX = (width - (actionW * 2f + gap)) * .5f;
            if (selectedOwned)
            {
                if (DrawActionButton(new Rect(actionX, actionY, actionW, 58), "✓   SELECIONAR", true, 60))
                { SaveSelection(); ShowNotice(name + " selecionada."); }
                if (DrawActionButton(new Rect(actionX + actionW + gap, actionY, actionW, 58), "▶   TESTAR", false, 61))
                    StartCoroutine(LoadSelectedScene());
            }
            else
            {
                bool canBuy = MotoCareerProgress.Balance >= MotoCareerProgress.PriceFor(selectedIndex);
                GUI.enabled = canBuy;
                bool buy = DrawActionButton(new Rect(actionX, actionY, actionW, 58), canBuy ? "R$   COMPRAR" : "SALDO INSUFICIENTE", true, 62);
                GUI.enabled = true;
                if (buy)
                {
                    if (MotoCareerProgress.TryPurchase(selectedIndex))
                    {
                        ShowNotice(name + " comprada e desbloqueada!");
                        SaveSelection();
                        ApplySelection();
                    }
                }
                if (DrawActionButton(new Rect(actionX + actionW + gap, actionY, actionW, 58), "▶   PILOTAR START", false, 63))
                {
                    selectedIndex = MotoCareerProgress.StarterBikeIndex;
                    SaveSelection();
                    StartCoroutine(LoadSelectedScene());
                }
            }
            DrawNotice(width, height);
        }

        private void DrawCareerProfile(Rect rect)
        {
            DrawPanel(rect);
            GUI.Label(new Rect(rect.x + 16, rect.y + 4, 170, 24), "●  JOGADOR", heading);
            GUI.Label(new Rect(rect.x + 18, rect.y + 30, 105, 19), "NÍVEL " + MotoCareerProgress.CareerLevel, small);
            Fill(new Rect(rect.x + 120, rect.y + 37, 94, 8), new Color(.2f, .21f, .23f));
            Fill(new Rect(rect.x + 120, rect.y + 37, 94f * MotoCareerProgress.LevelProgress, 8), new Color(.9f, .025f, .04f));
            GUI.Label(new Rect(rect.x + 226, rect.y + 12, rect.width - 236, 34), MotoCareerProgress.FormatCredits(MotoCareerProgress.Balance), heading);
        }

        private void DrawBrandLogo(Rect rect)
        {
            if (brandLogo != null)
            {
                Color old = GUI.color;
                GUI.color = Color.white;
                GUI.DrawTextureWithTexCoords(rect, brandLogo, new Rect(.02f, .08f, .96f, .72f), true);
                GUI.color = old;
            }
            else
            {
                GUI.Label(new Rect(rect.x, rect.y, rect.width * .45f, rect.height), "MOTO", logo);
                GUI.Label(new Rect(rect.x + rect.width * .45f, rect.y, rect.width * .55f, rect.height), "SIMULADOR", redLogo);
            }
        }

        private void DrawPanel(Rect rect)
        {
            Fill(new Rect(rect.x + 4, rect.y + 5, rect.width, rect.height), new Color(0, 0, 0, .45f));
            Fill(rect, new Color(.012f, .018f, .026f, .88f));
            Stroke(rect, new Color(.4f, .43f, .48f, .72f), 1.5f);
            Fill(new Rect(rect.x, rect.y, rect.width, 3), new Color(.86f, .025f, .04f, .86f));
        }

        private bool DrawPaintSwatch(Rect rect, int paintIndex, int animationId)
        {
            float hover = HoverAmount(rect, animationId);
            Fill(new Rect(rect.x - 2f, rect.y - 2f, rect.width + 4f, rect.height + 4f),
                new Color(.9f, .025f, .035f, paintIndex == selectedPaint ? .95f : .22f + hover * .55f));
            Fill(rect, MotoCareerProgress.PaintColor(paintIndex));
            Rect label = new Rect(rect.x - 4, rect.yMax + 3, rect.width + 8, 17);
            GUIStyle labelStyle = new GUIStyle(small) { alignment = TextAnchor.MiddleCenter, fontSize = 9 };
            GUI.Label(label, paintIndex == selectedPaint ? "✓" : MotoCareerProgress.PaintName(paintIndex), labelStyle);
            return GUI.Button(rect, GUIContent.none, GUIStyle.none);
        }

        private bool DrawActionButton(Rect rect, string label, bool highlighted, int id)
        {
            Color accent = highlighted ? new Color(.92f, .025f, .04f) : new Color(.55f, .59f, .64f);
            Fill(rect, accent);
            Fill(new Rect(rect.x + 2, rect.y + 2, rect.width - 4, rect.height - 4),
                highlighted ? new Color(.18f, .018f, .026f, .97f) : new Color(.025f, .035f, .05f, .96f));
            return DrawInteractiveButton(new Rect(rect.x + 4, rect.y + 4, rect.width - 8, rect.height - 8), label, id, highlighted, button);
        }

        private bool DrawInteractiveButton(Rect rect, string label, int id, bool highlighted, GUIStyle style)
        {
            float hover = HoverAmount(rect, id);
            float pulse = .5f + .5f * Mathf.Sin(Time.unscaledTime * 4.5f + id * .37f);
            Color accent = highlighted ? new Color(.95f, .025f, .04f) : new Color(.46f, .51f, .57f);
            Stroke(new Rect(rect.x - 1.5f, rect.y - 1.5f, rect.width + 3f, rect.height + 3f),
                new Color(accent.r, accent.g, accent.b, .28f + .48f * hover + (highlighted ? .12f * pulse : 0)),
                1f + hover * 1.5f);
            GUI.backgroundColor = highlighted ? new Color(.72f + .2f * hover, .018f, .03f, .98f) :
                new Color(.08f + .13f * hover, .095f + .13f * hover, .11f + .13f * hover, .98f);
            bool clicked = GUI.Button(rect, label, style);
            GUI.backgroundColor = Color.white;
            return clicked;
        }

        private float HoverAmount(Rect rect, int id)
        {
            if (!buttonHover.TryGetValue(id, out float value)) value = 0;
            float target = rect.Contains(Event.current.mousePosition) ? 1f : 0f;
            value = Mathf.MoveTowards(value, target, Mathf.Max(.01f, Time.unscaledDeltaTime) * 7f);
            buttonHover[id] = value;
            return value;
        }

        private void DrawNotice(float width, float height)
        {
            if (string.IsNullOrEmpty(noticeText) || Time.unscaledTime >= noticeUntil) return;
            float alpha = Mathf.Clamp01(Mathf.Min((noticeUntil - Time.unscaledTime) * 2f, 1f));
            Rect rect = new Rect(width * .31f, height - 146f, width * .38f, 42f);
            Fill(rect, new Color(.02f, .025f, .03f, .9f * alpha));
            Stroke(rect, new Color(.92f, .03f, .045f, .9f * alpha), 2f);
            GUIStyle toast = new GUIStyle(heading) { alignment = TextAnchor.MiddleCenter, fontSize = 14,
                normal = { textColor = new Color(1f, 1f, 1f, alpha) } };
            GUI.Label(rect, noticeText, toast);
        }

        private void ShowNotice(string message)
        {
            noticeText = message;
            noticeUntil = Time.unscaledTime + 3.4f;
        }

        private void DrawSettings(float width, float height)
        {
            Fill(new Rect(0, 0, width, height), new Color(.01f, .012f, .018f, .64f));
            Rect panel = new Rect(width * .28f, height * .18f, width * .48f, height * .64f);
            Fill(panel, new Color(.025f, .03f, .04f, .97f));
            Stroke(panel, new Color(.75f, .025f, .04f), 2);
            GUI.Label(new Rect(panel.x + 28, panel.y + 20, panel.width - 56, 48), "CONFIGURAÇÕES", title);
            GUI.Label(new Rect(panel.x + 32, panel.y + 105, 180, 30), "Volume geral", body);
            float volume = GUI.HorizontalSlider(new Rect(panel.x + 220, panel.y + 112, panel.width - 265, 24), masterVolume, 0, 1);
            if (!Mathf.Approximately(volume, masterVolume))
            {
                masterVolume = volume;
                AudioListener.volume = masterVolume;
                PlayerPrefs.SetFloat("MotoSim.MasterVolume", masterVolume);
            }
            GUI.Label(new Rect(panel.x + 32, panel.y + 180, 180, 30), "Tela cheia", body);
            bool fullscreen = GUI.Toggle(new Rect(panel.x + 220, panel.y + 180, 160, 30), Screen.fullScreen, "Ativada");
            if (fullscreen != Screen.fullScreen) Screen.fullScreen = fullscreen;
            GUI.Label(new Rect(panel.x + 32, panel.y + 250, 180, 30), "Qualidade", body);
            string[] qualityNames = QualitySettings.names;
            if (qualityNames.Length > 0)
            {
                int quality = GUI.SelectionGrid(new Rect(panel.x + 220, panel.y + 244, panel.width - 260, 38),
                    selectedQuality, qualityNames, Mathf.Min(qualityNames.Length, 3));
                if (quality != selectedQuality)
                {
                    selectedQuality = quality;
                    QualitySettings.SetQualityLevel(selectedQuality, true);
                    PlayerPrefs.SetInt("MotoSim.Quality", selectedQuality);
                }
            }
            if (DrawActionButton(new Rect(panel.x + 32, panel.y + panel.height - 76, 210, 50), "SALVAR E VOLTAR", true, 70))
            {
                PlayerPrefs.Save();
                OpenMainMenu();
            }
        }

        private void DrawMenuButton(Rect rect, string label, bool highlighted, int id, System.Action action)
        {
            Color accent = highlighted ? new Color(.88f, .025f, .035f) : new Color(.35f, .37f, .4f);
            Fill(rect, accent);
            Fill(new Rect(rect.x + 3, rect.y + 3, rect.width - 6, rect.height - 6),
                highlighted ? new Color(.12f, .018f, .022f, .97f) : new Color(.025f, .03f, .04f, .94f));
            if (DrawInteractiveButton(new Rect(rect.x + 4, rect.y + 4, rect.width - 8, rect.height - 8),
                label, id, highlighted, menuButton)) action();
        }

        private void StartNewGame()
        {
            MotoCareerProgress.StartNewCareer();
            selectedIndex = MotoCareerProgress.StarterBikeIndex;
            selectedPaint = MotoCareerProgress.PaintIndex(selectedIndex);
            ShowNotice("Nova carreira iniciada. A Honda Start 160 está liberada.");
            OpenGarage();
        }

        private void OpenGarage()
        {
            screenMode = ScreenMode.Garage;
            selectedIndex = Mathf.Clamp(PlayerPrefs.GetInt("MotoSim.GarageSelection", MotoCareerProgress.StarterBikeIndex),
                0, Mathf.Max(0, bikeNames.Length - 1));
            selectedPaint = MotoCareerProgress.PaintIndex(selectedIndex);
            ApplySelection();
        }

        private void OpenMainMenu()
        {
            screenMode = ScreenMode.MainMenu;
            ApplySelection();
        }

        private static void Stroke(Rect rect, Color color, float thickness)
        {
            Fill(new Rect(rect.x, rect.y, rect.width, thickness), color);
            Fill(new Rect(rect.x, rect.yMax - thickness, rect.width, thickness), color);
            Fill(new Rect(rect.x, rect.y, thickness, rect.height), color);
            Fill(new Rect(rect.xMax - thickness, rect.y, thickness, rect.height), color);
        }

        private void SaveSelection()
        {
            if (selectedIndex >= 0 && selectedIndex < bikeNames.Length && MotoCareerProgress.IsOwned(selectedIndex))
            {
                PlayerPrefs.SetString("MotoSim.SelectedBike", bikeNames[selectedIndex]);
                PlayerPrefs.SetInt("MotoSim.GarageSelection", selectedIndex);
                PlayerPrefs.Save();
            }
        }

        private IEnumerator LoadSelectedScene()
        {
            if (selectedIndex < 0 || selectedIndex >= scenePaths.Length) yield break;
            if (!MotoCareerProgress.IsOwned(selectedIndex))
            {
                ShowNotice("Essa moto está bloqueada. Compre-a com os créditos da carreira.");
                yield break;
            }
            SaveSelection();
            PlayerPrefs.SetInt("MotoSim.HasProgress", 1);
            PlayerPrefs.Save();
            loading = true; loadProgress = 0;
            AsyncOperation operation = SceneManager.LoadSceneAsync(scenePaths[selectedIndex]);
            if (operation == null) { loading = false; yield break; }
            operation.allowSceneActivation = false;
            while (operation.progress < .9f)
            { loadProgress = Mathf.Clamp01(operation.progress / .9f); yield return null; }
            loadProgress = 1; yield return null; operation.allowSceneActivation = true;
        }

        private void DrawLoading()
        {
            EnsureStyles();
            Rect screen = new Rect(0, 0, Screen.width, Screen.height);
            if (officialLoadingBackground != null)
                GUI.DrawTexture(screen, officialLoadingBackground, ScaleMode.ScaleAndCrop, false);
            else Fill(screen, new Color(.035f, .035f, .045f, 1));
            GUIStyle center = new GUIStyle(title)
            { alignment = TextAnchor.MiddleCenter, fontSize = Mathf.Clamp(Screen.height / 28, 20, 34), fontStyle = FontStyle.Bold };
            GUIStyle tip = new GUIStyle(body)
            { alignment = TextAnchor.MiddleLeft, fontSize = Mathf.Clamp(Screen.height / 62, 13, 22), fontStyle = FontStyle.Italic };
            float labelY = Screen.height * .735f;
            GUI.Label(new Rect(0, labelY, Screen.width, Screen.height * .055f), "C A R R E G A N D O . . .", center);
            Rect bar = new Rect(Screen.width * .24f, Screen.height * .805f, Screen.width * .52f, Mathf.Clamp(Screen.height * .037f, 20, 36));
            Fill(bar, new Color(.025f, .025f, .03f, .96f));
            Fill(new Rect(bar.x + 4, bar.y + 4, Mathf.Max(0, (bar.width - 8) * Mathf.Clamp01(loadProgress)), bar.height - 8), new Color(.91f, .025f, .035f));
            Fill(new Rect(bar.x, bar.y, bar.width, 2), new Color(.7f, .7f, .72f, .85f));
            GUI.Label(new Rect(Screen.width * .285f, bar.y + bar.height + 14, Screen.width * .43f, Screen.height * .075f),
                "DICA: MANTENHA O EQUILÍBRIO E A VELOCIDADE CONSTANTE\nNOS PERCURSOS DE PROVA.", tip);
        }

        private static void Fill(Rect rect, Color color)
        {
            Color old = GUI.color; GUI.color = color; GUI.DrawTexture(rect, Texture2D.whiteTexture); GUI.color = old;
        }
    }
}
