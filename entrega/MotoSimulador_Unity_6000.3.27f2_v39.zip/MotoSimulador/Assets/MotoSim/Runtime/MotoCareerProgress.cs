using System.Globalization;
using UnityEngine;

namespace MotoSim.Unity
{
    /// <summary>Persistent starter-bike ownership, game credits, paint choices, and riding distance.</summary>
    public static class MotoCareerProgress
    {
        public const int StarterBikeIndex = 0;
        public const int CreditRewardPerKilometre = 2500;
        public const int DistanceRewardCentimetres = 100000;
        private const string InitializedKey = "MotoSim.Career.Initialized.v1";
        private const string BalanceKey = "MotoSim.Career.Credits";
        private const string DistanceKey = "MotoSim.Career.DistanceCm";

        public static int Balance
        {
            get { EnsureInitialized(); return PlayerPrefs.GetInt(BalanceKey, 0); }
        }

        public static int DistanceCentimetres
        {
            get { EnsureInitialized(); return PlayerPrefs.GetInt(DistanceKey, 0); }
        }

        public static int CareerLevel => 1 + DistanceCentimetres / (DistanceRewardCentimetres * 5);

        public static float LevelProgress
        {
            get
            {
                int levelDistance = DistanceCentimetres % (DistanceRewardCentimetres * 5);
                return levelDistance / (float)(DistanceRewardCentimetres * 5);
            }
        }

        public static int PriceFor(int bikeIndex)
        {
            switch (bikeIndex)
            {
                case 0: return 0;
                case 1: return 22000;
                case 2: return 82000;
                default: return int.MaxValue;
            }
        }

        public static bool IsOwned(int bikeIndex)
        {
            EnsureInitialized();
            return bikeIndex == StarterBikeIndex || PlayerPrefs.GetInt(OwnedKey(bikeIndex), 0) == 1;
        }

        public static bool TryPurchase(int bikeIndex)
        {
            EnsureInitialized();
            int price = PriceFor(bikeIndex);
            if (bikeIndex <= StarterBikeIndex || price == int.MaxValue || IsOwned(bikeIndex) || Balance < price) return false;
            PlayerPrefs.SetInt(BalanceKey, Balance - price);
            PlayerPrefs.SetInt(OwnedKey(bikeIndex), 1);
            PlayerPrefs.Save();
            return true;
        }

        public static void AddCredits(int credits)
        {
            EnsureInitialized();
            if (credits <= 0) return;
            PlayerPrefs.SetInt(BalanceKey, Balance + credits);
            PlayerPrefs.Save();
        }

        public static void SaveDistance(int centimetres)
        {
            EnsureInitialized();
            PlayerPrefs.SetInt(DistanceKey, Mathf.Max(0, centimetres));
        }

        public static int PaintIndex(int bikeIndex)
        {
            EnsureInitialized();
            return Mathf.Clamp(PlayerPrefs.GetInt(PaintKey(bikeIndex), 0), 0, 3);
        }

        public static void SetPaintIndex(int bikeIndex, int paintIndex)
        {
            EnsureInitialized();
            PlayerPrefs.SetInt(PaintKey(bikeIndex), Mathf.Clamp(paintIndex, 0, 3));
            PlayerPrefs.Save();
        }

        public static Color PaintColor(int paintIndex)
        {
            switch (Mathf.Clamp(paintIndex, 0, 3))
            {
                case 0: return new Color32(215, 25, 38, 255);  // vermelho corrida
                case 1: return new Color32(24, 91, 184, 255);  // azul
                case 2: return new Color32(50, 55, 63, 255);  // grafite
                default: return new Color32(238, 164, 24, 255); // amarelo
            }
        }

        public static string PaintName(int paintIndex)
        {
            switch (Mathf.Clamp(paintIndex, 0, 3))
            {
                case 0: return "VERMELHO";
                case 1: return "AZUL";
                case 2: return "GRAFITE";
                default: return "AMARELO";
            }
        }

        public static string FormatCredits(int amount) =>
            "R$ " + Mathf.Max(0, amount).ToString("N0", CultureInfo.GetCultureInfo("pt-BR")) + ",00";

        public static void StartNewCareer()
        {
            EnsureInitialized();
            PlayerPrefs.SetInt(BalanceKey, 0);
            PlayerPrefs.SetInt(DistanceKey, 0);
            PlayerPrefs.SetInt(OwnedKey(0), 1);
            PlayerPrefs.SetInt(OwnedKey(1), 0);
            PlayerPrefs.SetInt(OwnedKey(2), 0);
            for (int i = 0; i < 3; i++) PlayerPrefs.SetInt(PaintKey(i), 0);
            PlayerPrefs.SetInt("MotoSim.GarageSelection", StarterBikeIndex);
            PlayerPrefs.SetString("MotoSim.SelectedBike", "Honda CG 160 Start");
            PlayerPrefs.SetInt("MotoSim.HasProgress", 0);
            PlayerPrefs.Save();
        }

        public static void EnsureInitialized()
        {
            if (PlayerPrefs.GetInt(InitializedKey, 0) == 1) return;
            PlayerPrefs.SetInt(BalanceKey, 0);
            PlayerPrefs.SetInt(DistanceKey, 0);
            PlayerPrefs.SetInt(OwnedKey(0), 1);
            PlayerPrefs.SetInt(OwnedKey(1), 0);
            PlayerPrefs.SetInt(OwnedKey(2), 0);
            PlayerPrefs.SetInt(InitializedKey, 1);
            PlayerPrefs.Save();
        }

        private static string OwnedKey(int bikeIndex) => "MotoSim.Career.Owned." + bikeIndex;
        private static string PaintKey(int bikeIndex) => "MotoSim.Career.Paint." + bikeIndex;
    }
}
