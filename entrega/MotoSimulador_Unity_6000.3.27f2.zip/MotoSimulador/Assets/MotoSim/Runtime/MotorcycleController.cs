using System;
using MotoSim.Core;
using UnityEngine;

namespace MotoSim.Unity
{
    [RequireComponent(typeof(Rigidbody))]
    public sealed class MotorcycleController : MonoBehaviour
    {
        [Header("Calibration is required before enabling the simulation")]
        [SerializeField] private bool physicalScaleVerified;
        [SerializeField] private WheelCollider frontWheel;
        [SerializeField] private WheelCollider rearWheel;
        [Tooltip("Provisional simulator tuning. Not Honda factory specifications.")]
        [SerializeField] private DrivetrainSettings tuning = new DrivetrainSettings();
        [Header("Steering and optional balance assistance")]
        [SerializeField] private float lowSpeedSteerDegrees = 30;
        [SerializeField] private float highSpeedSteerDegrees = 8;
        [SerializeField] private float maxLeanDegrees = 35;
        [SerializeField] private float balanceAcceleration = 25;
        [SerializeField] private float balanceDamping = 5;
        [SerializeField] private float maxBalanceAcceleration = 35;
        [SerializeField] private bool balanceAssistance = true;

        private Rigidbody body;
        private Drivetrain drivetrain;
        private float throttle, clutch = 1, frontBrake, rearBrake, steer, smoothedSteer;
        private int shiftRequest;
        private bool ignitionRequested, neutralRequested;
        public DriveOutput Telemetry { get; private set; }
        private Vector3 BodyVelocity
        {
            get
            {
#if UNITY_6000_0_OR_NEWER
                return body.linearVelocity;
#else
                return body.velocity;
#endif
            }
        }
        public float SpeedKph => body == null ? 0 : BodyVelocity.magnitude * 3.6f;
        public bool IsReady => enabled && drivetrain != null;

        private void Awake()
        {
            body = GetComponent<Rigidbody>();
            if (!physicalScaleVerified || frontWheel == null || rearWheel == null || frontWheel == rearWheel)
            {
                Debug.LogError("Calibrate model scale in meters and assign separate front/rear WheelColliders before enabling MotoSim.", this);
                enabled = false; return;
            }
            if ((transform.lossyScale - Vector3.one).sqrMagnitude > .000001f ||
                Vector3.Distance(frontWheel.transform.position, rearWheel.transform.position) < .5f ||
                Vector3.Distance(frontWheel.transform.position, rearWheel.transform.position) > 3 ||
                frontWheel.radius <= 0 || rearWheel.radius <= 0)
            {
                Debug.LogError("Use an unscaled Rigidbody root, calibrated wheel radii and a physical wheelbase. Scale the visual child separately.", this);
                enabled = false; return;
            }
            try { drivetrain = new Drivetrain(tuning); }
            catch (ArgumentException e) { Debug.LogError("Invalid drivetrain tuning: " + e.Message, this); enabled = false; }
        }

        // Any input source (keyboard, gamepad, wheel) can feed the same interface.
        public void SetControls(float gas, float clutchLever, float front, float rear, float steering)
        {
            throttle = Mathf.Clamp01(gas); clutch = Mathf.Clamp01(clutchLever);
            frontBrake = Mathf.Clamp01(front); rearBrake = Mathf.Clamp01(rear); steer = Mathf.Clamp(steering, -1, 1);
        }

        public void RequestShift(int direction)
        {
            if (direction != -1 && direction != 1) throw new ArgumentOutOfRangeException(nameof(direction));
            shiftRequest = direction; neutralRequested = false;
        }
        public void RequestNeutral() { neutralRequested = true; shiftRequest = 0; }
        public void RequestIgnitionToggle() => ignitionRequested = !ignitionRequested;
        public void ClearInput()
        { SetControls(0, 1, 0, 0, 0); shiftRequest = 0; ignitionRequested = false; neutralRequested = false; }

        private void FixedUpdate()
        {
            if (drivetrain == null) return;
            if (ignitionRequested)
            {
                ignitionRequested = false;
                if (drivetrain.EngineRunning) drivetrain.StopEngine();
                else drivetrain.TryStartEngine(clutch >= tuning.ShiftClutchThreshold);
            }
            var commands = new RiderCommands(throttle, clutch, frontBrake, rearBrake, shiftRequest, neutralRequested);
            shiftRequest = 0; neutralRequested = false;
            Telemetry = drivetrain.Step(Time.fixedDeltaTime, commands, rearWheel.rpm * (2 * Mathf.PI / 60));
            rearWheel.motorTorque = Telemetry.RearDriveTorqueNm;
            frontWheel.motorTorque = 0;
            frontWheel.brakeTorque = Telemetry.FrontBrakeTorqueNm;
            rearWheel.brakeTorque = Telemetry.RearBrakeTorqueNm;

            smoothedSteer = Mathf.MoveTowards(smoothedSteer, steer, 4 * Time.fixedDeltaTime);
            float speed = BodyVelocity.magnitude;
            frontWheel.steerAngle = smoothedSteer * Mathf.Lerp(lowSpeedSteerDegrees, highSpeedSteerDegrees, Mathf.Clamp01(speed / 20));
            if (balanceAssistance && (frontWheel.isGrounded || rearWheel.isGrounded)) ApplyBalance(speed);
        }

        private void ApplyBalance(float speed)
        {
            float wheelbase = Vector3.Distance(frontWheel.transform.position, rearWheel.transform.position);
            float gravity = Mathf.Max(.1f, Physics.gravity.magnitude);
            float lean = Mathf.Atan(speed * speed * Mathf.Tan(frontWheel.steerAngle * Mathf.Deg2Rad) / (wheelbase * gravity)) * Mathf.Rad2Deg;
            lean = Mathf.Clamp(lean, -maxLeanDegrees, maxLeanDegrees);
            Vector3 forward = Vector3.ProjectOnPlane(transform.forward, Vector3.up).normalized;
            if (forward.sqrMagnitude < .001f) return;
            Vector3 targetUp = Quaternion.AngleAxis(-lean, forward) * Vector3.up;
            Vector3 correction = Vector3.Cross(transform.up, targetUp) * balanceAcceleration
                - Vector3.ProjectOnPlane(body.angularVelocity, Vector3.up) * balanceDamping;
            body.AddTorque(Vector3.ClampMagnitude(correction, maxBalanceAcceleration), ForceMode.Acceleration);
        }

        private void OnDisable()
        {
            if (frontWheel != null) { frontWheel.motorTorque = 0; frontWheel.brakeTorque = 0; }
            if (rearWheel != null) { rearWheel.motorTorque = 0; rearWheel.brakeTorque = 0; }
            drivetrain?.StopEngine(); ClearInput();
        }
    }
}
