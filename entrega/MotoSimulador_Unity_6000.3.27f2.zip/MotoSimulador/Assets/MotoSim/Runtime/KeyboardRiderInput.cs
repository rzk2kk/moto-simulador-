using UnityEngine;

namespace MotoSim.Unity
{
    /// <summary>Initial keyboard input. Requires the legacy Input Manager or Active Input Handling = Both.</summary>
    [RequireComponent(typeof(MotorcycleController))]
    public sealed class KeyboardRiderInput : MonoBehaviour
    {
        private MotorcycleController motorcycle;
        private void Awake() => motorcycle = GetComponent<MotorcycleController>();
        private void Update()
        {
            if (!motorcycle.IsReady) return;
            float direction = (Input.GetKey(KeyCode.D) ? 1 : 0) - (Input.GetKey(KeyCode.A) ? 1 : 0);
            motorcycle.SetControls(Input.GetKey(KeyCode.W) ? 1 : 0,
                Input.GetKey(KeyCode.LeftShift) ? 1 : 0,
                Input.GetKey(KeyCode.Space) ? 1 : 0, Input.GetKey(KeyCode.S) ? 1 : 0, direction);
            if (Input.GetKeyDown(KeyCode.E)) motorcycle.RequestShift(1);
            if (Input.GetKeyDown(KeyCode.Q)) motorcycle.RequestShift(-1);
            if (Input.GetKeyDown(KeyCode.N)) motorcycle.RequestNeutral();
            if (Input.GetKeyDown(KeyCode.I)) motorcycle.RequestIgnitionToggle();
        }
        private void OnApplicationFocus(bool focused) { if (!focused && motorcycle != null) motorcycle.ClearInput(); }
        private void OnDisable() { if (motorcycle != null) motorcycle.ClearInput(); }
    }
}
