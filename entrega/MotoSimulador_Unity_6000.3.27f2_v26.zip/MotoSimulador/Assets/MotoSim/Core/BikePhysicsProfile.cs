using System;

namespace MotoSim.Core
{
    /// <summary>Provisional test profile. Values are not certified Honda specifications.</summary>
    [Serializable]
    public sealed class BikePhysicsProfile
    {
        public float WheelbaseMetres = 1.315f;
        public float BikeMassKg = 115;
        public float RiderMassKg = 75;
        public float FrontWeightFraction = .47f;
        public float SuspensionTravelMetres = .12f;
        public float SuspensionFrequencyHz = 3;
        public float SuspensionDampingRatio = .8f;
        public float CenterOfMassHeightMetres = .42f;
        public float TrainingSpeedLimitKph = 50;
        public float ClutchPullPerSecond = 16;
        public float ClutchReleasePerSecond = 8f;
        public bool ReferenceVerified = false;
        public string ReferenceNote = "Initial adjustable test values; not verified against the model year or a Honda manual.";
        public string ReferenceUrl = "";
        public float TotalMassKg => BikeMassKg + RiderMassKg;

        public void Validate()
        {
            VehicleCalibration.Positive(WheelbaseMetres, nameof(WheelbaseMetres));
            VehicleCalibration.Positive(BikeMassKg, nameof(BikeMassKg));
            if (!DrivetrainSettings.Finite(RiderMassKg) || RiderMassKg < 0) throw new ArgumentOutOfRangeException(nameof(RiderMassKg));
            if (!(FrontWeightFraction > 0 && FrontWeightFraction < 1)) throw new ArgumentOutOfRangeException(nameof(FrontWeightFraction));
            VehicleCalibration.Positive(SuspensionTravelMetres, nameof(SuspensionTravelMetres));
            VehicleCalibration.Positive(SuspensionFrequencyHz, nameof(SuspensionFrequencyHz));
            VehicleCalibration.Positive(SuspensionDampingRatio, nameof(SuspensionDampingRatio));
            VehicleCalibration.Positive(CenterOfMassHeightMetres, nameof(CenterOfMassHeightMetres));
            VehicleCalibration.Positive(TrainingSpeedLimitKph, nameof(TrainingSpeedLimitKph));
            VehicleCalibration.Positive(ClutchPullPerSecond, nameof(ClutchPullPerSecond));
            VehicleCalibration.Positive(ClutchReleasePerSecond, nameof(ClutchReleasePerSecond));
            if (ReferenceVerified && string.IsNullOrWhiteSpace(ReferenceUrl))
                throw new ArgumentException("A verified reference requires its source URL.");
        }
    }

    public static class VehicleCalibration
    {
        public static float UniformScale(float measuredWheelbase, float targetWheelbase)
        {
            Positive(measuredWheelbase, nameof(measuredWheelbase)); Positive(targetWheelbase, nameof(targetWheelbase));
            return targetWheelbase / measuredWheelbase;
        }
        public static float SpringRate(float sprungMassKg, float frequencyHz)
        {
            Positive(sprungMassKg, nameof(sprungMassKg)); Positive(frequencyHz, nameof(frequencyHz));
            float omega = 2 * (float)Math.PI * frequencyHz;
            return sprungMassKg * omega * omega;
        }
        public static float DamperRate(float sprungMassKg, float springRate, float dampingRatio)
        {
            Positive(sprungMassKg, nameof(sprungMassKg)); Positive(springRate, nameof(springRate)); Positive(dampingRatio, nameof(dampingRatio));
            return 2 * dampingRatio * (float)Math.Sqrt(sprungMassKg * springRate);
        }
        public static float SafeSteerDegrees(float speed, float wheelbase, float maxSteerDegrees, float maxLeanDegrees, float gravity)
        {
            Positive(wheelbase, nameof(wheelbase)); Positive(gravity, nameof(gravity));
            if (!DrivetrainSettings.Finite(speed)) throw new ArgumentOutOfRangeException(nameof(speed));
            if (!(maxSteerDegrees > 0 && maxSteerDegrees < 89) || !(maxLeanDegrees > 0 && maxLeanDegrees < 89))
                throw new ArgumentOutOfRangeException(nameof(maxSteerDegrees));
            if (Math.Abs(speed) < .1f) return maxSteerDegrees;
            float rad = (float)Math.PI / 180;
            float limit = (float)Math.Atan(gravity * wheelbase * Math.Tan(maxLeanDegrees * rad) / (speed * speed)) / rad;
            return Math.Min(maxSteerDegrees, limit);
        }
        public static float SpeedLimiterScale(float speedKph, float limitKph, float rampKph)
        {
            Positive(limitKph, nameof(limitKph)); Positive(rampKph, nameof(rampKph));
            if (!DrivetrainSettings.Finite(speedKph) || speedKph < 0)
                throw new ArgumentOutOfRangeException(nameof(speedKph));
            return Clamp((limitKph - speedKph) / rampKph, 0, 1);
        }
        internal static void Positive(float value, string name)
        { if (!DrivetrainSettings.Finite(value) || value <= 0) throw new ArgumentOutOfRangeException(name); }
        private static float Clamp(float value, float min, float max) => Math.Max(min, Math.Min(max, value));
    }

    public sealed class ClutchActuator
    {
        private readonly float pullRate, releaseRate;
        public float Lever { get; private set; } = 1;
        public ClutchActuator(float pullPerSecond, float releasePerSecond)
        {
            VehicleCalibration.Positive(pullPerSecond, nameof(pullPerSecond));
            VehicleCalibration.Positive(releasePerSecond, nameof(releasePerSecond));
            pullRate = pullPerSecond; releaseRate = releasePerSecond;
        }
        public float Step(float dt, float requestedLever)
        {
            if (!DrivetrainSettings.Finite(dt) || dt <= 0 || dt > .1f || !DrivetrainSettings.Finite(requestedLever))
                throw new ArgumentOutOfRangeException(nameof(dt));
            float target = Math.Max(0, Math.Min(1, requestedLever));
            float rate = target > Lever ? pullRate : releaseRate;
            Lever += Math.Max(-rate * dt, Math.Min(rate * dt, target - Lever));
            return Lever;
        }
    }
}
