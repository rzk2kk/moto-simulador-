using UnityEngine;

namespace MotoSim.Unity
{
    /// <summary>Simple articulated rider, visible in third person with animated hands in first person.</summary>
    public sealed class RiderAvatar : MonoBehaviour
    {
        [SerializeField] private GameObject motorcycleModel;
        [SerializeField] private MotorcycleController motorcycle;
        [SerializeField] private RideCamera rideCamera;
        private GameObject body;
        private Transform leftArm, rightArm, leftHand, rightHand, leftLever, rightLever, throttleGrip;
        private Material suit, glove, helmet, visor, metal;
        private Vector3 leftGrip, rightGrip;

        public void Configure(GameObject visual, MotorcycleController vehicle, RideCamera camera)
        { motorcycleModel = visual; motorcycle = vehicle; rideCamera = camera; }

        private void Start()
        {
            Shader shader = Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Standard");
            if (shader == null) return;
            suit = MakeMaterial(shader, new Color(.025f, .028f, .035f));
            glove = MakeMaterial(shader, new Color(.12f, .13f, .15f));
            helmet = MakeMaterial(shader, new Color(.15f, .018f, .025f));
            visor = MakeMaterial(shader, new Color(.008f, .012f, .018f));
            metal = MakeMaterial(shader, new Color(.55f, .57f, .59f));
            Transform bodyRoot = new GameObject("Corpo_Piloto").transform;
            bodyRoot.SetParent(transform, false);
            body = bodyRoot.gameObject;
            Shape("Tronco", PrimitiveType.Capsule, bodyRoot, new Vector3(0, 1.11f, .20f), new Vector3(.34f, .33f, .24f), suit);
            Shape("Capacete", PrimitiveType.Sphere, bodyRoot, new Vector3(0, 1.61f, .40f), new Vector3(.34f, .38f, .35f), helmet);
            Shape("Viseira", PrimitiveType.Sphere, bodyRoot, new Vector3(0, 1.64f, .59f), new Vector3(.29f, .18f, .10f), visor);
            Shape("Quadril", PrimitiveType.Capsule, bodyRoot, new Vector3(0, .83f, .10f), new Vector3(.34f, .18f, .29f), suit);
            for (int side = -1; side <= 1; side += 2)
            {
                Vector3 hip = new Vector3(side * .16f, .76f, .13f);
                Vector3 knee = new Vector3(side * .32f, .50f, .52f);
                Vector3 foot = new Vector3(side * .28f, .30f, .08f);
                Segment("Coxa", bodyRoot, hip, knee, .11f, suit);
                Segment("Perna", bodyRoot, knee, foot, .085f, suit);
                Shape("Bota", PrimitiveType.Capsule, bodyRoot, foot, new Vector3(.17f, .13f, .28f), glove);
            }
            leftGrip = new Vector3(-.36f, 1.19f, 1.05f);
            rightGrip = new Vector3(.36f, 1.19f, 1.05f);
            leftArm = Segment("Braco_Embreagem", transform, new Vector3(-.18f, 1.37f, .40f), leftGrip, .075f, suit);
            rightArm = Segment("Braco_Freio", transform, new Vector3(.18f, 1.37f, .40f), rightGrip, .075f, suit);
            leftHand = Shape("Mao_Embreagem", PrimitiveType.Capsule, transform, leftGrip, new Vector3(.13f, .08f, .22f), glove);
            rightHand = Shape("Mao_Acelerador_Freio", PrimitiveType.Capsule, transform, rightGrip, new Vector3(.13f, .08f, .22f), glove);
            leftLever = Segment("Manete_Embreagem_Animado", transform, leftGrip + new Vector3(-.18f, -.03f, .03f),
                leftGrip + new Vector3(.03f, -.04f, .12f), .015f, metal);
            rightLever = Segment("Manete_Freio_Animado", transform, rightGrip + new Vector3(-.03f, -.03f, .12f),
                rightGrip + new Vector3(.18f, -.03f, .03f), .015f, metal);
            throttleGrip = Shape("Punho_Acelerador_Animado", PrimitiveType.Cylinder, transform,
                rightGrip + new Vector3(.10f, .0f, -.02f), new Vector3(.055f, .13f, .055f), glove);
        }

        private void LateUpdate()
        {
            if (body == null || motorcycle == null) return;
            body.SetActive(rideCamera == null || !rideCamera.IsFirstPerson);
            float clutch = motorcycle.ClutchLever;
            float brake = motorcycle.FrontBrakeInput;
            float throttle = motorcycle.ThrottleInput;
            leftHand.localPosition = leftGrip + new Vector3(0, -.035f * clutch, -.025f * clutch);
            leftHand.localRotation = Quaternion.Euler(15f * clutch, 0, 0);
            rightHand.localPosition = rightGrip + new Vector3(0, -.035f * brake, -.025f * brake);
            rightHand.localRotation = Quaternion.Euler(25f * throttle + 15f * brake, 0, 0);
            leftLever.localRotation = Quaternion.Euler(18f * clutch, 0, 0);
            rightLever.localRotation = Quaternion.Euler(22f * brake, 0, 0);
            throttleGrip.localRotation = Quaternion.Euler(-25f * throttle, 0, 90f);
            PlaceSegment(leftArm, new Vector3(-.18f, 1.37f, .40f), leftHand.localPosition, .075f);
            PlaceSegment(rightArm, new Vector3(.18f, 1.37f, .40f), rightHand.localPosition, .075f);
        }

        private static Material MakeMaterial(Shader shader, Color color)
        {
            Material material = new Material(shader) { color = color };
            if (material.HasProperty("_BaseColor")) material.SetColor("_BaseColor", color);
            return material;
        }
        private static Transform Shape(string name, PrimitiveType primitive, Transform parent, Vector3 position, Vector3 scale, Material material)
        {
            GameObject obj = GameObject.CreatePrimitive(primitive);
            obj.name = name; obj.transform.SetParent(parent, false);
            obj.transform.localPosition = position; obj.transform.localScale = scale;
            obj.GetComponent<Renderer>().material = material;
            Collider collider = obj.GetComponent<Collider>(); if (collider != null) Destroy(collider);
            return obj.transform;
        }
        private static Transform Segment(string name, Transform parent, Vector3 start, Vector3 end, float radius, Material material)
        {
            Transform piece = Shape(name, PrimitiveType.Capsule, parent, Vector3.zero, Vector3.one, material);
            PlaceSegment(piece, start, end, radius);
            return piece;
        }
        private static void PlaceSegment(Transform piece, Vector3 start, Vector3 end, float radius)
        {
            Vector3 delta = end - start;
            piece.localPosition = (start + end) * .5f;
            piece.localRotation = Quaternion.FromToRotation(Vector3.up, delta.normalized);
            piece.localScale = new Vector3(radius * 2f, delta.magnitude * .5f, radius * 2f);
        }
    }
}
