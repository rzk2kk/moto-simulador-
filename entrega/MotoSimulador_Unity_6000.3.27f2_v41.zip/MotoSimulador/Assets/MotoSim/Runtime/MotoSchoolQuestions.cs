namespace MotoSim.Unity
{
    /// <summary>Original questions based on common road-safety rules; they are not official exam items.</summary>
    public static class MotoSchoolQuestions
    {
        public const int Count = 6;
        public const int PassingScore = 5;
        private static readonly string[][] Prompts = {
            new[] { "Ao ver um semáforo vermelho, o condutor deve:", "At a red traffic light, the rider must:", "Ante un semáforo rojo, el conductor debe:" },
            new[] { "Antes de mudar de direção, o motociclista deve:", "Before turning, a motorcyclist must:", "Antes de girar, el motociclista debe:" },
            new[] { "Qual equipamento é indispensável ao pilotar?", "Which equipment is essential while riding?", "¿Qué equipo es esencial al conducir?" },
            new[] { "Em uma faixa de pedestres, havendo travessia iniciada, deve-se:", "At a crossing with a pedestrian already crossing, you must:", "En un cruce con un peatón cruzando, se debe:" },
            new[] { "Se a pista estiver molhada, o mais seguro é:", "On a wet road, the safest action is to:", "Si la calzada está mojada, lo más seguro es:" },
            new[] { "Após consumir bebida alcoólica, a decisão segura é:", "After drinking alcohol, the safe decision is to:", "Después de beber alcohol, la decisión segura es:" }
        };
        private static readonly string[][][] Answers = {
            new[] { new[] { "Parar antes da linha de retenção", "Stop before the stop line", "Detenerse antes de la línea" }, new[] { "Acelerar para cruzar", "Accelerate across", "Acelerar para cruzar" }, new[] { "Buzinar e seguir", "Sound the horn and go", "Tocar la bocina y seguir" } },
            new[] { new[] { "Sinalizar e conferir o entorno", "Signal and check surroundings", "Señalizar y revisar alrededor" }, new[] { "Virar sem avisar", "Turn without warning", "Girar sin avisar" }, new[] { "Frear só no meio da curva", "Brake only mid-turn", "Frenar solo en la curva" } },
            new[] { new[] { "Capacete adequado e afivelado", "A suitable, fastened helmet", "Casco adecuado y abrochado" }, new[] { "Somente óculos escuros", "Only sunglasses", "Solo gafas de sol" }, new[] { "Boné", "A cap", "Una gorra" } },
            new[] { new[] { "Dar preferência à pessoa", "Give way to the pedestrian", "Dar prioridad al peatón" }, new[] { "Manter a velocidade", "Keep speed", "Mantener la velocidad" }, new[] { "Desviar pela calçada", "Use the sidewalk", "Usar la acera" } },
            new[] { new[] { "Reduzir velocidade e aumentar distância", "Slow down and increase distance", "Reducir la velocidad y aumentar distancia" }, new[] { "Frear bruscamente", "Brake sharply", "Frenar bruscamente" }, new[] { "Acelerar nas curvas", "Accelerate in turns", "Acelerar en las curvas" } },
            new[] { new[] { "Não pilotar; usar outro transporte", "Do not ride; use other transport", "No conducir; usar otro transporte" }, new[] { "Pilotar devagar", "Ride slowly", "Conducir despacio" }, new[] { "Tomar café e pilotar", "Drink coffee and ride", "Tomar café y conducir" } }
        };
        public static string Prompt(int index) => MotoRegion.T(Prompts[index][0], Prompts[index][1], Prompts[index][2]);
        public static string Answer(int index, int option) => MotoRegion.T(Answers[index][option][0], Answers[index][option][1], Answers[index][option][2]);
        public static bool IsCorrect(int option) => option == 0;
    }
}
