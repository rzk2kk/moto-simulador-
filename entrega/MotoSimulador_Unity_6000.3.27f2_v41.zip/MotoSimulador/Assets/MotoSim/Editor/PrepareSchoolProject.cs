using System;
using System.IO;
using MotoSim.Unity;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace MotoSim.Editor
{
    /// <summary>Creates a separate marked practice track from the starter-bike scene.</summary>
    public static class PrepareSchoolProject
    {
        internal const string ScenePath = "Assets/MotoSim/Generated/Autoescola_ProvaPratica.unity";
        private const string MaterialFolder = "Assets/MotoSim/Generated/Materials";
        private static readonly Vector3 Offset = new Vector3(200f, 0f, 0f);
        private static readonly Vector3[] Route = {
            new Vector3(0, 0, -5), new Vector3(0, 0, 45), new Vector3(0, 0, 88),
            new Vector3(0, 0, 135), new Vector3(0, 0, 190), new Vector3(8, 0, 235),
            new Vector3(56, 0, 245), new Vector3(75, 0, 245)
        };

        public static void RunSetup()
        {
            if (AssetDatabase.LoadAssetAtPath<SceneAsset>(ScenePath) != null) return;
            if (AssetDatabase.LoadAssetAtPath<SceneAsset>(PrepareRidingProject.ScenePath) == null)
                PrepareRidingProject.RunSetup();
            if (!AssetDatabase.CopyAsset(PrepareRidingProject.ScenePath, ScenePath))
                throw new IOException("Não foi possível criar a cena da prova prática.");
            Scene scene = EditorSceneManager.OpenScene(ScenePath, OpenSceneMode.Single);
            MotorcycleController motorcycle = null;
            foreach (GameObject root in scene.GetRootGameObjects())
            {
                motorcycle = root.GetComponentInChildren<MotorcycleController>(true);
                if (motorcycle != null) break;
            }
            if (motorcycle == null) throw new InvalidOperationException("Cena de aula prática sem a moto inicial.");
            motorcycle.transform.position += Offset;
            foreach (GameObject root in scene.GetRootGameObjects())
            {
                RideCamera camera = root.GetComponentInChildren<RideCamera>(true);
                if (camera != null) camera.transform.position += Offset;
            }
            BuildCourse();
            if (!EditorSceneManager.SaveScene(scene, ScenePath)) throw new IOException("Falha ao salvar a prova prática.");
            AssetDatabase.SaveAssets();
        }

        private static void BuildCourse()
        {
            Material ground = CourseMaterial("Escola_Grama", new Color(.13f, .23f, .15f));
            Material asphalt = CourseMaterial("Escola_Asfalto", new Color(.10f, .11f, .12f));
            Material stripe = CourseMaterial("Escola_Faixa", new Color(.96f, .78f, .08f));
            Material cone = CourseMaterial("Escola_Cone", new Color(.95f, .25f, .05f));
            Cube("Terreno_Escola_Pratico", Offset + new Vector3(15, -.15f, 125), new Vector3(140, .25f, 300), ground);
            for (int i = 0; i < Route.Length - 1; i++)
            {
                Vector3 a = Route[i] + Offset, b = Route[i + 1] + Offset;
                Vector3 direction = (b - a).normalized;
                GameObject road = Cube("Pista_Pratico_Trecho_" + i, (a + b) * .5f + Vector3.up * .035f,
                    new Vector3(14f, .10f, Vector3.Distance(a, b) + 1.2f), asphalt);
                road.transform.rotation = Quaternion.LookRotation(direction, Vector3.up);
                for (float t = 10f; t < Vector3.Distance(a, b) - 5f; t += 16f)
                {
                    Vector3 center = a + direction * t;
                    GameObject mark = Cube("Faixa_Amarela_" + i + "_" + t, center + Vector3.up * .10f,
                        new Vector3(.12f, .012f, 3f), stripe);
                    mark.transform.rotation = road.transform.rotation;
                    UnityEngine.Object.DestroyImmediate(mark.GetComponent<Collider>());
                    Vector3 side = Vector3.Cross(Vector3.up, direction).normalized * 6.3f;
                    for (int s = -1; s <= 1; s += 2)
                    {
                        GameObject marker = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
                        marker.name = "Cone_Escola_" + i + "_" + t + "_" + s;
                        marker.transform.position = center + side * s + Vector3.up * .32f;
                        marker.transform.localScale = new Vector3(.24f, .32f, .24f);
                        marker.GetComponent<Renderer>().sharedMaterial = cone;
                    }
                }
            }
        }

        private static GameObject Cube(string name, Vector3 position, Vector3 scale, Material material)
        {
            GameObject obj = GameObject.CreatePrimitive(PrimitiveType.Cube);
            obj.name = name; obj.transform.position = position; obj.transform.localScale = scale;
            obj.GetComponent<Renderer>().sharedMaterial = material;
            return obj;
        }

        private static Material CourseMaterial(string name, Color color)
        {
            PrepareInspectionProject.EnsureFolder("Assets/MotoSim/Generated", "Materials");
            string path = MaterialFolder + "/" + name + ".mat";
            Material material = AssetDatabase.LoadAssetAtPath<Material>(path);
            if (material == null)
            {
                Shader shader = Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Standard");
                material = new Material(shader) { name = name };
                AssetDatabase.CreateAsset(material, path);
            }
            if (material.HasProperty("_BaseColor")) material.SetColor("_BaseColor", color);
            if (material.HasProperty("_Color")) material.SetColor("_Color", color);
            EditorUtility.SetDirty(material);
            return material;
        }
    }
}
