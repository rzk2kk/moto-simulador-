using System;
using System.Collections.Generic;
using System.IO;
using MotoSim.Unity;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using UnityEngine.SceneManagement;

namespace MotoSim.Editor
{
    /// <summary>First-open setup for the supplied project only. Does not modify an unrelated user's project.</summary>
    [InitializeOnLoad]
    public static class PrepareInspectionProject
    {
        private const string Generated = "Assets/MotoSim/Generated";
        private const string ScenePath = Generated + "/CG160_Inspecao.unity";
        private const string ModelPath = "Assets/MotoSim/Art/CG160_neutra_unidades_originais.fbx";
        private const string SessionKey = "MotoSim.InspectionSetupAttempted";
        [Serializable] private sealed class ProjectRequest
        { public string projectId; public bool automaticInspectionSetup; public string startupScene; }

        static PrepareInspectionProject()
        {
            EditorApplication.delayCall += TryAutomaticSetup;
            EditorApplication.playModeStateChanged += OnPlayModeChanged;
            EditorSceneManager.sceneOpened += (scene, mode) => EditorApplication.delayCall += TryAutomaticSetup;
        }

        private static string Root => Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
        private static string Completion => Path.Combine(Root, "ProjectSettings", "MotoSimInspectionSetup.json");

        private static bool IsSuppliedProject()
        {
            string requestPath = Path.Combine(Root, "MotoSimProject.json");
            if (!File.Exists(requestPath)) return false;
            var request = JsonUtility.FromJson<ProjectRequest>(File.ReadAllText(requestPath));
            return request != null && request.projectId == "motosim-cg160" && request.automaticInspectionSetup;
        }

        private static bool WantsRidingTest()
        {
            var request = JsonUtility.FromJson<ProjectRequest>(File.ReadAllText(Path.Combine(Root, "MotoSimProject.json")));
            return request.startupScene == "riding-test";
        }

        private static void TryAutomaticSetup()
        {
            if (!IsSuppliedProject()) return;
            if (EditorApplication.isCompiling || EditorApplication.isUpdating || EditorApplication.isPlayingOrWillChangePlaymode)
            { EditorApplication.delayCall += TryAutomaticSetup; return; }
            if (WantsRidingTest()) { PrepareRidingProject.TryAutomaticSetup(); return; }
            if (File.Exists(Completion) && AssetDatabase.LoadAssetAtPath<SceneAsset>(ScenePath) != null)
            {
                // A completion marker proves generation, not that Unity reopened the scene.
                Scene active = SceneManager.GetActiveScene();
                if (active.IsValid() && !active.isDirty && string.IsNullOrEmpty(active.path))
                    OpenInspectionScene();
                return;
            }
            if (SessionState.GetBool(SessionKey, false)) return;
            SessionState.SetBool(SessionKey, true);
            RunSetup();
        }

        private static void OnPlayModeChanged(PlayModeStateChange state)
        {
            if (state != PlayModeStateChange.ExitingEditMode || !IsSuppliedProject()) return;
            Scene active = SceneManager.GetActiveScene();
            if (!active.IsValid() || !string.IsNullOrEmpty(active.path) || active.isDirty || HasGameCamera(active)) return;
            // Stop entering an empty Untitled scene. Prepare in edit mode and then honor Play.
            EditorApplication.isPlaying = false;
            EditorApplication.delayCall += PrepareBeforePlay;
        }

        private static void PrepareBeforePlay()
        {
            if (EditorApplication.isCompiling || EditorApplication.isUpdating || EditorApplication.isPlayingOrWillChangePlaymode)
            { EditorApplication.delayCall += PrepareBeforePlay; return; }
            if (WantsRidingTest()) PrepareRidingProject.RunSetup(); else RunSetup();
            Scene inspection = SceneManager.GetSceneByPath(WantsRidingTest() ? PrepareRidingProject.ScenePath : ScenePath);
            if (inspection.IsValid() && inspection.isLoaded && HasGameCamera(inspection))
                EditorApplication.isPlaying = true;
        }

        internal static bool HasGameCamera(Scene scene)
        {
            foreach (GameObject root in scene.GetRootGameObjects())
                foreach (Camera cameraComponent in root.GetComponentsInChildren<Camera>())
                    if (cameraComponent.enabled && cameraComponent.gameObject.activeInHierarchy && cameraComponent.targetTexture == null)
                        return true;
            return false;
        }

        private static void OpenInspectionScene() => OpenPreparedScene(ScenePath);

        internal static void OpenPreparedScene(string path)
        {
            Scene inspection = SceneManager.GetSceneByPath(path);
            if (!inspection.IsValid() || !inspection.isLoaded)
            {
                var recovered = PreserveUnnamedScenes();
                inspection = EditorSceneManager.OpenScene(path, OpenSceneMode.Additive);
                SceneManager.SetActiveScene(inspection);
                CloseRecoveredScenes(recovered);
            }
            SceneManager.SetActiveScene(inspection);
        }

        internal static List<Scene> PreserveUnnamedScenes()
        {
            var recovered = new List<Scene>();
            for (int i = 0; i < SceneManager.sceneCount; i++)
            {
                Scene scene = SceneManager.GetSceneAt(i);
                if (!scene.IsValid() || !scene.isLoaded || !string.IsNullOrEmpty(scene.path)) continue;
                EnsureFolder(Generated, "Recuperadas");
                string path = AssetDatabase.GenerateUniqueAssetPath(Generated + "/Recuperadas/CenaAnterior.unity");
                // Unity refuses additive scene creation while ANY loaded scene is untitled,
                // even when that scene is empty and isDirty is false. Save before adding.
                if (!EditorSceneManager.SaveScene(scene, path) || string.IsNullOrEmpty(scene.path))
                    throw new IOException("Não foi possível preservar a cena sem nome em " + path + ". Nenhuma nova cena foi criada.");
                recovered.Add(scene);
            }
            // Guard the native API precondition explicitly, including non-active scenes.
            for (int i = 0; i < SceneManager.sceneCount; i++)
            {
                Scene scene = SceneManager.GetSceneAt(i);
                if (scene.isLoaded && string.IsNullOrEmpty(scene.path))
                    throw new InvalidOperationException("Ainda existe uma cena sem nome; a criação adicional foi interrompida para preservar seu conteúdo.");
            }
            return recovered;
        }

        internal static void CloseRecoveredScenes(List<Scene> recovered)
        {
            // Close only the scenes saved by this operation; files remain recoverable.
            foreach (Scene scene in recovered)
                if (scene.IsValid() && scene.isLoaded && !scene.isDirty)
                    EditorSceneManager.CloseScene(scene, true);
        }

        [MenuItem("MotoSim/Abrir inspeção da moto")]
        public static void RunSetup()
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode)
            {
                EditorApplication.isPlaying = false;
                EditorApplication.delayCall += RunSetup;
                return;
            }
            try
            {
                EnsureFolder("Assets/MotoSim", "Generated");
                ConfigurePipeline();
                if (AssetDatabase.LoadAssetAtPath<SceneAsset>(ScenePath) == null) CreateInspectionScene();
                else OpenInspectionScene();
                Scene inspection = SceneManager.GetSceneByPath(ScenePath);
                if (!inspection.IsValid() || !inspection.isLoaded || !HasGameCamera(inspection))
                    throw new InvalidOperationException("A cena de inspeção não contém uma câmera ativa. A preparação não foi concluída.");
                AssetDatabase.SaveAssets();
                File.WriteAllText(Completion,
                    "{\"inspectionPrepared\":true,\"physicsCalibrated\":false,\"editor\":\"" + Application.unityVersion + "\"}");
                Debug.Log("MotoSim: cena de inspeção preparada. A física ainda não está calibrada.");
            }
            catch (Exception error)
            {
                Debug.LogException(error);
                File.WriteAllText(Path.Combine(Root, "MotoSim_Setup_Error.txt"), error.ToString());
                EditorUtility.DisplayDialog("MotoSim — preparação incompleta",
                    error.Message + "\n\nO detalhe foi registrado no Console e no arquivo MotoSim_Setup_Error.txt na pasta do projeto.", "OK");
                // Preserve evidence and all existing assets; do not mark incomplete setup as successful.
            }
        }

        internal static void EnsureFolder(string parent, string name)
        { if (!AssetDatabase.IsValidFolder(parent + "/" + name)) AssetDatabase.CreateFolder(parent, name); }

        internal static void ConfigurePipeline()
        {
            const string rendererPath = Generated + "/MotoSimRenderer.asset";
            const string pipelinePath = Generated + "/MotoSimURP.asset";
            var renderer = AssetDatabase.LoadAssetAtPath<UniversalRendererData>(rendererPath);
            if (renderer == null)
            {
                renderer = ScriptableObject.CreateInstance<UniversalRendererData>();
                AssetDatabase.CreateAsset(renderer, rendererPath);
                ResourceReloader.ReloadAllNullIn(renderer, "Packages/com.unity.render-pipelines.universal");
            }
            var pipeline = AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>(pipelinePath);
            if (pipeline == null)
            {
                pipeline = UniversalRenderPipelineAsset.Create(renderer);
                pipeline.renderScale = 1;
                pipeline.msaaSampleCount = 2;
                pipeline.supportsHDR = false;
                pipeline.supportsCameraDepthTexture = false;
                pipeline.supportsCameraOpaqueTexture = false;
                pipeline.shadowDistance = 20;
                pipeline.mainLightShadowmapResolution = 1024;
                AssetDatabase.CreateAsset(pipeline, pipelinePath);
            }
            // The motorcycle headlamp is an additional spot light; make sure the
            // URP forward renderer actually evaluates it on the road surface.
            pipeline.additionalLightsRenderingMode = LightRenderingMode.PerPixel;
            pipeline.additionalLightsPerObjectLimit = 4;
            GraphicsSettings.defaultRenderPipeline = pipeline;
            QualitySettings.renderPipeline = pipeline;
        }

        private static void CreateInspectionScene()
        {
            var importer = AssetImporter.GetAtPath(ModelPath) as ModelImporter;
            if (importer == null) throw new InvalidOperationException("FBX não encontrado em " + ModelPath);
            if (importer.importAnimation || importer.isReadable)
            {
                importer.importAnimation = false;
                importer.isReadable = false;
                importer.SaveAndReimport();
            }
            var model = AssetDatabase.LoadAssetAtPath<GameObject>(ModelPath);
            if (model == null) throw new InvalidOperationException("A importação do FBX ainda não foi concluída.");
            if (Shader.Find("Universal Render Pipeline/Lit") == null)
                throw new InvalidOperationException("Shader URP/Lit indisponível. A resolução do pacote URP precisa terminar.");
            var recovered = PreserveUnnamedScenes();
            Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Additive);
            SceneManager.SetActiveScene(scene);
            var instance = (GameObject)PrefabUtility.InstantiatePrefab(model, scene);
            instance.name = "CG160_Inspecao";
            var renderers = instance.GetComponentsInChildren<Renderer>(true);
            if (renderers.Length == 0) throw new InvalidOperationException("O FBX não contém renderers.");
            Bounds bounds = renderers[0].bounds;
            EnsureFolder(Generated, "Materials");
            foreach (var renderer in renderers)
            {
                bounds.Encapsulate(renderer.bounds);
                var assigned = renderer.sharedMaterials;
                for (int i = 0; i < assigned.Length; i++) assigned[i] = PrepareMaterial(assigned[i], renderer.name);
                renderer.sharedMaterials = assigned;
            }
            var cameraObject = new GameObject("Camera_Inspecao");
            cameraObject.tag = "MainCamera";
            var cameraComponent = cameraObject.AddComponent<Camera>();
            cameraComponent.clearFlags = CameraClearFlags.SolidColor;
            cameraComponent.backgroundColor = new Color(.12f, .16f, .21f);
            cameraObject.AddComponent<ModelInspectionCamera>().Configure(bounds);
            var lightObject = new GameObject("Luz_Inspecao");
            var light = lightObject.AddComponent<Light>();
            light.type = LightType.Directional; light.intensity = 1.5f; light.shadows = LightShadows.Soft;
            lightObject.transform.rotation = Quaternion.Euler(45, -35, 0);
            RenderSettings.sun = light;
            RenderSettings.ambientMode = AmbientMode.Trilight;
            RenderSettings.ambientSkyColor = new Color(.55f, .62f, .7f);
            RenderSettings.ambientEquatorColor = new Color(.3f, .32f, .35f);
            RenderSettings.ambientGroundColor = new Color(.15f, .14f, .13f);
            if (!EditorSceneManager.SaveScene(scene, ScenePath))
                throw new IOException("Não foi possível salvar a cena de inspeção em " + ScenePath);
            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
            CloseRecoveredScenes(recovered);
            Selection.activeGameObject = instance;
            if (SceneView.lastActiveSceneView != null) SceneView.lastActiveSceneView.Frame(bounds, false);
        }

        internal static Material PrepareMaterial(Material original, string meshName)
        {
            string name = original == null ? "Material" : original.name;
            // Classify only parts already identified in the source, leaving unclassified body colors alone.
            string category = meshName.IndexOf("Pneu", StringComparison.OrdinalIgnoreCase) >= 0 ? "Borracha" : "Original";
            string path = Generated + "/Materials/" + SafeName(name + "_" + category) + ".mat";
            var material = AssetDatabase.LoadAssetAtPath<Material>(path);
            if (material != null) return material;
            material = new Material(Shader.Find("Universal Render Pipeline/Lit"));
            Color color = new Color(.42f, .42f, .42f);
            if (original != null)
            {
                if (original.HasProperty("_BaseColor")) color = original.GetColor("_BaseColor");
                else if (original.HasProperty("_Color")) color = original.GetColor("_Color");
                if (original.mainTexture != null) material.SetTexture("_BaseMap", original.mainTexture);
            }
            if (category == "Borracha") color = new Color(.045f, .045f, .045f);
            material.SetColor("_BaseColor", color);
            material.SetFloat("_Smoothness", category == "Borracha" ? .12f : .4f);
            material.SetFloat("_Metallic", 0);
            AssetDatabase.CreateAsset(material, path);
            return material;
        }

        private static string SafeName(string value)
        {
            foreach (char character in Path.GetInvalidFileNameChars()) value = value.Replace(character, '_');
            return value.Replace('/', '_').Replace('\\', '_');
        }
    }
}
