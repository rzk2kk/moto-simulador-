using System;
using UnityEngine;

namespace MotoSim.Unity
{
    /// <summary>Compact in-game riding panel with live states, controls, and a round speedometer.</summary>
    public sealed class RideTelemetry : MonoBehaviour
    {
        [SerializeField] private MotorcycleController motorcycle;
        [SerializeField] private RideCamera rideCamera;
        [SerializeField] private MotorcycleLighting lighting;
        [SerializeField] private MotorcycleAudio motorcycleAudio;
        [SerializeField] private bool cameraSettingsOpen;
        private Texture2D panelTexture;
        private GUIStyle panelStyle, titleStyle, valueStyle, smallStyle, buttonStyle, speedStyle;

        public void Configure(MotorcycleController vehicle, RideCamera camera, MotorcycleLighting lights)
        { motorcycle = vehicle; rideCamera = camera; lighting = lights; motorcycleAudio = vehicle.GetComponent<MotorcycleAudio>(); }

        private void OnGUI()
        {
            if (motorcycle == null) return;
            EnsureStyles();
            DrawRiderPanel();
            DrawSpeedometer();
            DrawCameraPanel();
        }

        private void DrawRiderPanel()
        {
            float scale = Mathf.Clamp(Screen.height / 900f, .72f, 1f);
            float width = Mathf.Min(340f * scale, Screen.width - 24);
            float x = 12f, y = 12f;
            float row = 20f * scale;
            float header = 22f * scale;
            float commandsHeight = 115f * scale;
            float height = 12f * scale + header + row * 7 + 5f * scale + commandsHeight + 8f * scale;
            GUI.Box(new Rect(x, y, width, height), GUIContent.none, panelStyle);
            GUI.Label(new Rect(x + 11 * scale, y + 4 * scale, width - 22 * scale, header), "MOTOSIM  |  PAINEL DO PILOTO", titleStyle);

            var state = motorcycle.Telemetry;
            string gear = state.Gear == 0 ? "N" : state.Gear.ToString();
            float cy = y + header + 7f * scale;
            DrawStatusRow(x, cy, width, row, "MOTOR", state.EngineRunning ? "LIGADO" : "DESLIGADO", state.EngineRunning, scale); cy += row;
            DrawStatusRow(x, cy, width, row, "MARCHA", gear, true, scale); cy += row;
            float clutchLever = motorcycle.ClutchLever;
            DrawStatusRow(x, cy, width, row, "EMBREAGEM", Mathf.RoundToInt(clutchLever * 100) + "% PUXADA",
                clutchLever > .05f, scale); cy += row;
            DrawStatusRow(x, cy, width, row, "RPM", state.EngineRpm.ToString("0"), true, scale); cy += row;
            DrawStatusRow(x, cy, width, row, "FAROL", lighting != null && lighting.HeadlampOn ? "LIGADO" : "DESLIGADO", lighting != null && lighting.HeadlampOn, scale); cy += row;
            string left = lighting != null && lighting.LeftSignalOn ? "ESQ. LIGADA" : "ESQ. DESL.";
            string right = lighting != null && lighting.RightSignalOn ? "DIR. LIGADA" : "DIR. DESL.";
            DrawStatusRow(x, cy, width, row, "SETAS", left + "  |  " + right,
                lighting != null && (lighting.LeftSignalOn || lighting.RightSignalOn), scale); cy += row;
            DrawStatusRow(x, cy, width, row, "PISCA-ALERTA", lighting != null && lighting.HazardsOn ? "LIGADO" : "DESLIGADO",
                lighting != null && lighting.HazardsOn, scale); cy += row + 4f * scale;

            GUI.color = new Color(.35f, .45f, .53f, .85f);
            GUI.DrawTexture(new Rect(x + 10 * scale, cy, width - 20 * scale, 1f), Texture2D.whiteTexture);
            GUI.color = Color.white;
            GUI.Label(new Rect(x + 11 * scale, cy + 3 * scale, width - 22 * scale, 16 * scale), "COMANDOS", smallStyle);
            float commandY = cy + 19 * scale;
            float half = (width - 28 * scale) / 2f;
            GUI.Label(new Rect(x + 11 * scale, commandY, half, 15 * scale), "W acelerar   S frear", smallStyle);
            GUI.Label(new Rect(x + 11 * scale, commandY + 15 * scale, half, 15 * scale), "Q/E marchas   Shift embreagem", smallStyle);
            GUI.Label(new Rect(x + 14 * scale + half, commandY, half, 15 * scale), "I motor   L farol", smallStyle);
            GUI.Label(new Rect(x + 14 * scale + half, commandY + 15 * scale, half, 15 * scale), "Z/X setas  H alerta  B buzina", smallStyle);
            float buttonY = commandY + 34f * scale;
            float gap = 4f * scale;
            float buttonWidth = (width - 28f * scale - gap * 5f) / 6f;
            float buttonHeight = 25f * scale;
            DrawButton(new Rect(x + 10f * scale, buttonY, buttonWidth, buttonHeight), state.EngineRunning ? "MOTOR\nOFF" : "MOTOR\nON",
                state.EngineRunning ? new Color(.15f, .43f, .33f) : new Color(.16f, .32f, .44f), motorcycle.RequestIgnitionToggle);
            DrawButton(new Rect(x + 10f * scale + (buttonWidth + gap), buttonY, buttonWidth, buttonHeight),
                lighting != null && lighting.HeadlampOn ? "FAROL\nON" : "FAROL\nOFF",
                lighting != null && lighting.HeadlampOn ? new Color(.48f, .4f, .18f) : new Color(.16f, .22f, .29f), () => lighting?.ToggleHeadlamp());
            DrawButton(new Rect(x + 10f * scale + 2f * (buttonWidth + gap), buttonY, buttonWidth, buttonHeight),
                lighting != null && lighting.LeftSignalOn ? "ESQ.\nON" : "ESQ. Z",
                lighting != null && lighting.LeftSignalOn ? new Color(.58f, .31f, .1f) : new Color(.16f, .22f, .29f), () => lighting?.ToggleLeftSignal());
            DrawButton(new Rect(x + 10f * scale + 3f * (buttonWidth + gap), buttonY, buttonWidth, buttonHeight),
                lighting != null && lighting.RightSignalOn ? "DIR.\nON" : "DIR. X",
                lighting != null && lighting.RightSignalOn ? new Color(.58f, .31f, .1f) : new Color(.16f, .22f, .29f), () => lighting?.ToggleRightSignal());
            DrawButton(new Rect(x + 10f * scale + 4f * (buttonWidth + gap), buttonY, buttonWidth, buttonHeight),
                lighting != null && lighting.HazardsOn ? "ALERTA\nON" : "ALERTA H",
                lighting != null && lighting.HazardsOn ? new Color(.58f, .31f, .1f) : new Color(.16f, .22f, .29f), () => lighting?.ToggleHazards());
            DrawButton(new Rect(x + 10f * scale + 5f * (buttonWidth + gap), buttonY, buttonWidth, buttonHeight),
                "BUZINA\nB", new Color(.5f, .25f, .12f), () => motorcycleAudio?.PlayHorn());
        }

        private void DrawStatusRow(float x, float y, float width, float rowHeight, string label, string value, bool active, float scale)
        {
            GUI.Label(new Rect(x + 11 * scale, y, width * .43f, rowHeight), label, smallStyle);
            GUIStyle rowValueStyle = active ? valueStyleActive : valueStyle;
            GUI.Label(new Rect(x + width * .44f, y, width * .53f - 8 * scale, rowHeight), value, rowValueStyle);
            GUI.color = new Color(.25f, .34f, .42f, .52f);
            GUI.DrawTexture(new Rect(x + 10 * scale, y + rowHeight - 1, width - 20 * scale, 1f), Texture2D.whiteTexture);
            GUI.color = Color.white;
        }

        private GUIStyle valueStyleActive;

        private void DrawSpeedometer()
        {
            float diameter = Mathf.Clamp(Screen.height * .22f, 150f, 198f);
            float margin = 14f;
            float x = Screen.width - diameter - margin;
            float y = Screen.height - diameter - margin;
            Rect rect = new Rect(x, y, diameter, diameter);
            GUI.Box(rect, GUIContent.none, panelStyle);

            Vector2 center = rect.center;
            float radius = diameter * .39f;
            float speed = Mathf.Clamp(motorcycle.SpeedKph, 0f, motorcycle.MaximumSpeedKph);
            float maxSpeed = Mathf.Max(1f, motorcycle.MaximumSpeedKph);

            // Dial ticks cover a 240 degree arc, leaving a clear lower center for the readout.
            for (int i = 0; i <= 24; i++)
            {
                float normalized = i / 24f;
                float angle = Mathf.Lerp(150f, 390f, normalized);
                float radians = angle * Mathf.Deg2Rad;
                float outer = radius;
                float inner = radius - (i % 4 == 0 ? 9f : 5f) * (diameter / 180f);
                Vector2 p1 = center + new Vector2(Mathf.Cos(radians), Mathf.Sin(radians)) * inner;
                Vector2 p2 = center + new Vector2(Mathf.Cos(radians), Mathf.Sin(radians)) * outer;
                DrawLine(p1, p2, i % 4 == 0 ? new Color(.82f, .88f, .93f) : new Color(.43f, .52f, .59f), 1.4f * (diameter / 180f));
            }

            int[] marks = { 0, 10, 20, 30, 40, 50 };
            foreach (int mark in marks)
            {
                if (mark > maxSpeed) continue;
                float normalized = mark / maxSpeed;
                float angle = Mathf.Lerp(150f, 390f, normalized) * Mathf.Deg2Rad;
                Vector2 point = center + new Vector2(Mathf.Cos(angle), Mathf.Sin(angle)) * (radius - 20f * diameter / 180f);
                GUI.Label(new Rect(point.x - 12f, point.y - 8f, 24f, 16f), mark.ToString(), smallCenterStyle);
            }

            float needleAngle = Mathf.Lerp(150f, 390f, Mathf.Clamp01(speed / maxSpeed)) * Mathf.Deg2Rad;
            Vector2 needleEnd = center + new Vector2(Mathf.Cos(needleAngle), Mathf.Sin(needleAngle)) * (radius - 18f * diameter / 180f);
            DrawLine(center, needleEnd, new Color(.14f, .82f, .84f), 2.4f * diameter / 180f);
            GUI.color = new Color(.14f, .82f, .84f);
            GUI.DrawTexture(new Rect(center.x - 4f, center.y - 4f, 8f, 8f), Texture2D.whiteTexture);
            GUI.color = Color.white;

            GUI.Label(new Rect(x + diameter * .19f, y + diameter * .38f, diameter * .62f, diameter * .27f),
                Mathf.RoundToInt(motorcycle.SpeedKph).ToString("00"), speedStyle);
            GUI.Label(new Rect(x + diameter * .28f, y + diameter * .63f, diameter * .44f, diameter * .11f), "km/h", smallCenterStyle);
            GUI.Label(new Rect(x + diameter * .16f, y + diameter * .77f, diameter * .68f, diameter * .12f),
                "LIMITE " + motorcycle.MaximumSpeedKph.ToString("0"), smallCenterStyle);
        }

        private void DrawCameraPanel()
        {
            if (rideCamera == null) return;
            const float width = 290;
            float x = Screen.width - width - 12;
            DrawButton(new Rect(x, 12, 140, 38), rideCamera.IsFirstPerson ? "VISÃO  1ª PESSOA" : "VISÃO  3ª PESSOA",
                new Color(.17f, .28f, .4f), rideCamera.ToggleView);
            DrawButton(new Rect(x + 146, 12, 132, 38), cameraSettingsOpen ? "FECHAR CÂMERA" : "AJUSTAR CÂMERA",
                new Color(.22f, .31f, .42f), () => cameraSettingsOpen = !cameraSettingsOpen);
            if (!cameraSettingsOpen) return;

            float verticalAdjustment = rideCamera.IsFirstPerson ? 0 : 22;
            GUI.Box(new Rect(x, 56, width, 174 + verticalAdjustment), GUIContent.none, panelStyle);
            GUI.Label(new Rect(x + 12, 63, width - 24, 22), "POSIÇÃO DA CÂMERA 1ª PESSOA", titleStyle);
            if (!rideCamera.IsFirstPerson)
                GUI.Label(new Rect(x + 12, 86, width - 24, 22), "Ajuste salvo; volte para 1ª pessoa para conferir.", smallStyle);
            float start = 91 + verticalAdjustment;
            GUI.Label(new Rect(x + 12, start, width - 24, 22), "Altura  " + rideCamera.FirstPersonHeightOffset.ToString("+0.00;-0.00;0.00") + " m", smallStyle);
            float height = GUI.HorizontalSlider(new Rect(x + 14, start + 23, width - 28, 18),
                rideCamera.FirstPersonHeightOffset, -.25f, .65f);
            GUI.Label(new Rect(x + 12, start + 45, width - 24, 22), "Distância  " + rideCamera.FirstPersonForwardOffset.ToString("+0.00;-0.00;0.00") + " m", smallStyle);
            float forward = GUI.HorizontalSlider(new Rect(x + 14, start + 68, width - 28, 18),
                rideCamera.FirstPersonForwardOffset, -.35f, .65f);
            if (GUI.Button(new Rect(x + 12, start + 98, width - 24, 28), "RESTAURAR POSIÇÃO PADRÃO", buttonStyle))
                rideCamera.ResetFirstPersonOffsets();
            if (Mathf.Abs(height - rideCamera.FirstPersonHeightOffset) > .002f ||
                Mathf.Abs(forward - rideCamera.FirstPersonForwardOffset) > .002f)
                rideCamera.SetFirstPersonOffsets(height, forward);
        }

        private void DrawLine(Vector2 a, Vector2 b, Color color, float thickness)
        {
            Matrix4x4 oldMatrix = GUI.matrix;
            Color oldColor = GUI.color;
            Vector2 delta = b - a;
            float angle = Mathf.Atan2(delta.y, delta.x) * Mathf.Rad2Deg;
            GUI.color = color;
            GUIUtility.RotateAroundPivot(angle, a);
            GUI.DrawTexture(new Rect(a.x, a.y - thickness * .5f, delta.magnitude, thickness), Texture2D.whiteTexture);
            GUI.matrix = oldMatrix;
            GUI.color = oldColor;
        }

        private void DrawButton(Rect rect, string text, Color tint, Action action)
        {
            Color previous = GUI.color;
            GUI.color = tint;
            if (GUI.Button(rect, text, buttonStyle)) action();
            GUI.color = previous;
        }

        private GUIStyle smallCenterStyle;

        private void EnsureStyles()
        {
            if (panelStyle != null) return;
            panelTexture = new Texture2D(1, 1, TextureFormat.RGBA32, false);
            panelTexture.SetPixel(0, 0, new Color(.025f, .045f, .065f, .91f)); panelTexture.Apply();
            panelStyle = new GUIStyle(GUI.skin.box) { normal = { background = panelTexture } };
            titleStyle = new GUIStyle(GUI.skin.label) { fontSize = 12, fontStyle = FontStyle.Bold,
                alignment = TextAnchor.MiddleLeft, normal = { textColor = new Color(.68f, .83f, .94f) } };
            valueStyle = new GUIStyle(GUI.skin.label) { fontSize = 10, fontStyle = FontStyle.Bold,
                alignment = TextAnchor.MiddleLeft, normal = { textColor = new Color(.8f, .86f, .91f) } };
            valueStyleActive = new GUIStyle(valueStyle) { normal = { textColor = new Color(.14f, .82f, .84f) } };
            smallStyle = new GUIStyle(GUI.skin.label) { fontSize = 9,
                alignment = TextAnchor.MiddleLeft, normal = { textColor = new Color(.78f, .84f, .9f) } };
            smallCenterStyle = new GUIStyle(smallStyle) { alignment = TextAnchor.MiddleCenter };
            speedStyle = new GUIStyle(GUI.skin.label) { fontSize = 29, fontStyle = FontStyle.Bold,
                alignment = TextAnchor.MiddleCenter, normal = { textColor = Color.white } };
            buttonStyle = new GUIStyle(GUI.skin.button) { fontSize = 10, fontStyle = FontStyle.Bold,
                alignment = TextAnchor.MiddleCenter, wordWrap = true, normal = { textColor = Color.white } };
        }

        private void OnDestroy()
        { if (panelTexture != null) Destroy(panelTexture); }
    }
}
