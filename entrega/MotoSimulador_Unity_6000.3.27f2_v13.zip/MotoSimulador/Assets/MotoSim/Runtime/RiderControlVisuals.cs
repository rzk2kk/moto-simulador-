using UnityEngine;

namespace MotoSim.Unity
{
    /// <summary>Animates the clutch and front-brake levers from the actual rider inputs.</summary>
    public sealed class RiderControlVisuals : MonoBehaviour
    {
        [SerializeField] private Transform clutchLever;
        [SerializeField] private Transform frontBrakeLever;
        [SerializeField] private MotorcycleController motorcycle;
        [SerializeField] private float travelDegrees = 14;
        private Quaternion clutchRest;
        private Quaternion brakeRest;

        public void Configure(Transform clutch, Transform frontBrake, MotorcycleController vehicle)
        {
            clutchLever = clutch;
            frontBrakeLever = frontBrake;
            motorcycle = vehicle;
            clutchRest = clutchLever.localRotation;
            brakeRest = frontBrakeLever.localRotation;
        }

        private void Awake()
        {
            if (clutchLever != null) clutchRest = clutchLever.localRotation;
            if (frontBrakeLever != null) brakeRest = frontBrakeLever.localRotation;
        }

        private void LateUpdate()
        {
            if (motorcycle == null) return;
            float clutch = motorcycle.ClutchLever;
            float brake = motorcycle.FrontBrakeInput;
            if (clutchLever != null)
                clutchLever.localRotation = clutchRest * Quaternion.AngleAxis(-travelDegrees * clutch, Vector3.forward);
            if (frontBrakeLever != null)
                frontBrakeLever.localRotation = brakeRest * Quaternion.AngleAxis(travelDegrees * brake, Vector3.forward);
        }
    }
}
