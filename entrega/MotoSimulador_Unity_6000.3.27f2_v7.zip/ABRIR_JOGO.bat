@echo off
setlocal
set "MOTOSIM_PROJECT=%~dp0MotoSimulador"
set "MOTOSIM_EDITOR=%ProgramFiles%\Unity\Hub\Editor\6000.3.27f2\Editor\Unity.exe"
set "MOTOSIM_PLAYER=%MOTOSIM_PROJECT%\Build\Windows\MotoSimulador.exe"
set "MOTOSIM_LOG=%MOTOSIM_PROJECT%\Build\primeira_compilacao.log"
if not exist "%MOTOSIM_PROJECT%\MotoSimProject.json" (
 echo Pasta do projeto MotoSimulador nao encontrada ao lado deste arquivo.
 pause
 exit /b 1
)
if exist "%MOTOSIM_PLAYER%" goto launch_game
if not exist "%MOTOSIM_EDITOR%" (
 echo Unity 6000.3.27f2 nao foi encontrada em:
 echo %MOTOSIM_EDITOR%
 echo No Unity Hub, verifique a instalacao do Editor e reabra este arquivo.
 pause
 exit /b 1
)
if not exist "%MOTOSIM_PROJECT%\Build" mkdir "%MOTOSIM_PROJECT%\Build"
echo Primeira compilacao do jogo. Pode levar alguns minutos; a Unity sera executada em segundo plano.
"%MOTOSIM_EDITOR%" -batchmode -quit -projectPath "%MOTOSIM_PROJECT%" -buildTarget Win64 -executeMethod MotoSim.Editor.BuildStandalone.BuildWindows -logFile "%MOTOSIM_LOG%"
if not exist "%MOTOSIM_PLAYER%" (
 echo Nao foi possivel gerar o jogo. Consulte o log:
 echo %MOTOSIM_LOG%
 pause
 exit /b 1
)
:launch_game
start "" "%MOTOSIM_PLAYER%"
