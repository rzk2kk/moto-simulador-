using UnityEngine;

namespace MotoSim.Unity
{
    /// <summary>First-person rider viewpoint, positioned just behind the handlebars.</summary>
    public sealed class RideCamera : MonoBehaviour
    {
        [SerializeField] private Transform target;
        [SerializeField] private Vector3 localEyePosition = new Vector3(0, 1.18f, .43f);
        private Vector3 velocity;

        public void Configure(Transform vehicle)
        {
            target = vehicle;
            Position(false);
        }

        private void LateUpdate() => Position(true);

        private void Position(bool smooth)
        {
            if (target == null) return;
            Vector3 desired = target.TransformPoint(localEyePosition);
            transform.position = smooth
                ? Vector3.SmoothDamp(transform.position, desired, ref velocity, .06f)
                : desired;
            transform.rotation = target.rotation;
        }
    }
}
