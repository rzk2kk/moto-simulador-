using UnityEngine;

namespace MotoSim.Unity
{
    /// <summary>Preserves the imported visual orientation instead of assuming the mesh spin axis.</summary>
    public sealed class WheelPoseBinding : MonoBehaviour
    {
        [SerializeField] private WheelCollider wheel;
        [SerializeField] private Transform visualAxle;
        private Quaternion rotationOffset;
        private Vector3 positionOffset;
        [SerializeField] private bool offsetConfigured;
        [SerializeField] private Quaternion initialRotationOffset;
        [SerializeField] private Vector3 initialPositionOffset;

        public void Configure(WheelCollider source, Transform target, Vector3 restWheelCenter)
        {
            wheel = source; visualAxle = target;
            initialRotationOffset = Quaternion.Inverse(source.transform.rotation) * target.rotation;
            initialPositionOffset = Quaternion.Inverse(source.transform.rotation) * (target.position - restWheelCenter);
            offsetConfigured = true;
        }

        private void Awake()
        {
            if (wheel == null || visualAxle == null || visualAxle == wheel.transform ||
                visualAxle == wheel.attachedRigidbody?.transform || wheel.transform.IsChildOf(visualAxle))
            {
                Debug.LogError("Assign a visual wheel axle separate from the physics root and WheelCollider hierarchy.", this);
                enabled = false; return;
            }
            if (offsetConfigured) { rotationOffset = initialRotationOffset; positionOffset = initialPositionOffset; }
            else
            {
                wheel.GetWorldPose(out Vector3 position, out Quaternion rotation);
                rotationOffset = Quaternion.Inverse(rotation) * visualAxle.rotation;
                positionOffset = Quaternion.Inverse(rotation) * (visualAxle.position - position);
            }
        }
        private void LateUpdate()
        {
            wheel.GetWorldPose(out Vector3 position, out Quaternion rotation);
            visualAxle.SetPositionAndRotation(position + rotation * positionOffset, rotation * rotationOffset);
        }
    }
}
