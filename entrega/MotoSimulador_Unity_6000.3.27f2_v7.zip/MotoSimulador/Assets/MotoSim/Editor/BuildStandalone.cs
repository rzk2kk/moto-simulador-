using System;
using System.IO;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace MotoSim.Editor
{
    /// <summary>Builds and launches the Windows game from the installed Unity Editor.</summary>
    public static class BuildStandalone
    {
        private static string ProjectRoot => Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
        private static string OutputDirectory => Path.Combine(ProjectRoot, "Build", "Windows");
        private static string OutputPlayer => Path.Combine(OutputDirectory, "MotoSimulador.exe");

        public static void BuildWindows()
        {
            try
            {
                // PrepareRidingProject creates or opens the current scene using the same
                // safe setup flow as the Editor launcher before starting the player build.
                PrepareRidingProject.RunSetup();
                AssetDatabase.Refresh();
                AssetDatabase.SaveAssets();

                string scenePath = PrepareRidingProject.ScenePath;
                if (AssetDatabase.LoadAssetAtPath<SceneAsset>(scenePath) == null)
                    throw new InvalidOperationException("A cena do teste físico não foi criada: " + scenePath);

                Directory.CreateDirectory(OutputDirectory);
                var options = new BuildPlayerOptions
                {
                    scenes = new[] { scenePath },
                    locationPathName = OutputPlayer,
                    target = BuildTarget.StandaloneWindows64,
                    options = BuildOptions.None
                };
                BuildReport report = BuildPipeline.BuildPlayer(options);
                if (report.summary.result != BuildResult.Succeeded)
                    throw new InvalidOperationException("A compilação do jogo falhou: " + report.summary.result +
                        ". Veja o Console da Unity para o erro detalhado.");

                Debug.Log("MotoSim: jogo Windows criado em " + OutputPlayer);
                EditorApplication.Exit(0);
            }
            catch (Exception error)
            {
                Debug.LogException(error);
                try { File.WriteAllText(Path.Combine(ProjectRoot, "Build", "ERRO_AO_GERAR_JOGO.txt"), error.ToString()); }
                catch { /* Unity writes the same details to its batch log. */ }
                EditorApplication.Exit(1);
            }
        }
    }
}
