using System;

namespace MotoSim.Core
{
    /// <summary>Rotational engine/clutch model. Wheel speed comes from a separate vehicle solver.</summary>
    public sealed class Drivetrain
    {
        private const float RpmPerRadSecond = 60f / (2f * (float)Math.PI);
        private readonly DrivetrainSettings settings;
        private float angularSpeed, throttle;
        private double fuel;
        public int Gear { get; private set; }
        public bool EngineRunning { get; private set; }
        public float EngineRpm => angularSpeed * RpmPerRadSecond;
        public float FuelLitres => (float)fuel;
        public int GearCount => settings.GearRatios.Length;

        public Drivetrain(DrivetrainSettings settings)
        {
            this.settings = (settings ?? throw new ArgumentNullException(nameof(settings))).CopyValidated();
            fuel = this.settings.FuelCapacityLitres;
        }

        public bool TryStartEngine(bool clutchDisengaged = false)
        {
            if (EngineRunning) return true;
            if (fuel <= 0 || (Gear != 0 && !clutchDisengaged)) return false;
            EngineRunning = true;
            angularSpeed = Math.Max(angularSpeed, settings.IdleRpm / RpmPerRadSecond);
            return true;
        }

        public void StopEngine() => EngineRunning = false;

        public void SetFuelLitres(float litres)
        {
            if (!DrivetrainSettings.Finite(litres)) throw new ArgumentOutOfRangeException(nameof(litres));
            fuel = Clamp(litres, 0, settings.FuelCapacityLitres);
            if (fuel == 0) StopEngine();
        }

        /// <param name="rearWheelRadPerSecond">Signed wheel speed; positive means forward.</param>
        public DriveOutput Step(float seconds, RiderCommands commands, float rearWheelRadPerSecond)
        {
            if (!DrivetrainSettings.Finite(seconds) || seconds <= 0 || seconds > 0.1f)
                throw new ArgumentOutOfRangeException(nameof(seconds), "Use fixed steps in (0, 0.1] seconds.");
            if (!DrivetrainSettings.Finite(rearWheelRadPerSecond) ||
                !DrivetrainSettings.Finite(commands.Throttle) || !DrivetrainSettings.Finite(commands.ClutchLever) ||
                !DrivetrainSettings.Finite(commands.FrontBrake) || !DrivetrainSettings.Finite(commands.RearBrake))
                throw new ArgumentException("Wheel speed and controls must be finite.");
            if (commands.ShiftDelta < -1 || commands.ShiftDelta > 1)
                throw new ArgumentOutOfRangeException(nameof(commands.ShiftDelta));
            if (commands.SelectNeutral && commands.ShiftDelta != 0)
                throw new ArgumentException("Request either a full shift or the neutral half-step, not both.");

            float lever = Clamp(commands.ClutchLever, 0, 1);
            bool rejected = false;
            if (commands.SelectNeutral && Gear != 0)
            {
                if (lever < settings.ShiftClutchThreshold || Gear > 2) rejected = true;
                else Gear = 0;
            }
            else if (commands.ShiftDelta != 0)
            {
                // Full strokes bypass neutral: 1 — N — 2 — 3 ...; from N, down=1 and up=2.
                int target = Gear == 0 ? (commands.ShiftDelta < 0 ? 1 : Math.Min(2, GearCount)) : Gear + commands.ShiftDelta;
                if (lever < settings.ShiftClutchThreshold || target < 1 || target > GearCount) rejected = true;
                else Gear = target;
            }
            float ratio = Gear == 0 ? 0 : settings.PrimaryRatio * settings.FinalRatio * settings.GearRatios[Gear - 1];
            int count = (int)Math.Ceiling(seconds / 0.001f);
            float h = seconds / count, sumTorque = 0, sumHeat = 0;
            bool limiterWasActive = false;
            float requestedThrottle = Clamp(commands.Throttle, 0, 1);

            for (int i = 0; i < count; i++)
            {
                float rate = requestedThrottle >= throttle ? settings.ThrottleRisePerSecond : settings.ThrottleFallPerSecond;
                throttle += Clamp(requestedThrottle - throttle, -rate * h, rate * h);
                float rpm = EngineRpm;
                limiterWasActive |= EngineRunning && rpm >= settings.RedlineRpm;
                float friction = settings.EngineFrictionNm + settings.EngineViscousDrag * angularSpeed
                    + settings.ClosedThrottlePumpingDrag * (1 - throttle) * angularSpeed;
                float combustion = 0;
                if (EngineRunning && fuel > 0 && rpm < settings.RedlineRpm)
                {
                    float idle = Clamp((settings.IdleRpm / RpmPerRadSecond - angularSpeed) * settings.IdleControlGain
                        + settings.EngineFrictionNm + (settings.EngineViscousDrag + settings.ClosedThrottlePumpingDrag) * settings.IdleRpm / RpmPerRadSecond,
                        0, settings.MaxIdleTorqueNm);
                    combustion = throttle * TorqueCurve(rpm) + (1 - throttle) * idle;
                }
                float slip = angularSpeed - rearWheelRadPerSecond * ratio;
                float capacity = settings.ClutchCapacityNm * (1 - lever);
                float clutchTorque = ratio == 0 ? 0 : Clamp(slip * settings.ClutchSlipGain, -capacity, capacity);
                // Reverse power flow must lose energy too: divide by efficiency on backdrive.
                float efficiency = clutchTorque >= 0 ? settings.TransmissionEfficiency : 1 / settings.TransmissionEfficiency;
                sumTorque += clutchTorque * ratio * efficiency;
                sumHeat += Math.Abs(clutchTorque * slip);
                angularSpeed = Math.Max(0, angularSpeed + (combustion - friction - clutchTorque) / settings.EngineInertiaKgM2 * h);
                if (EngineRunning)
                {
                    fuel = Math.Max(0, fuel - h * (settings.IdleFuelLitresPerHour
                        + settings.ExtraFuelLitresPerHourAtFullThrottle * throttle) / 3600.0);
                    if (EngineRpm < settings.StallRpm || fuel <= 0) StopEngine();
                }
            }
            return new DriveOutput(EngineRpm, sumTorque / count,
                settings.MaxFrontBrakeNm * Clamp(commands.FrontBrake, 0, 1),
                settings.MaxRearBrakeNm * Clamp(commands.RearBrake, 0, 1), throttle, FuelLitres,
                sumHeat / count, Gear, EngineRunning, rejected, limiterWasActive);
        }

        private float TorqueCurve(float rpm)
        {
            float fraction = rpm <= settings.PeakTorqueRpm
                ? 0.45f + 0.55f * Clamp(rpm / settings.PeakTorqueRpm, 0, 1)
                : 1 - 0.35f * Clamp((rpm - settings.PeakTorqueRpm) / (settings.RedlineRpm - settings.PeakTorqueRpm), 0, 1);
            return settings.PeakTorqueNm * fraction;
        }

        private static float Clamp(float value, float min, float max) => Math.Max(min, Math.Min(max, value));
    }
}
