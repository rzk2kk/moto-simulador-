using System;
using MotoSim.Core;
using UnityEngine;
using UnityEngine.Serialization;

namespace MotoSim.Unity
{
    [RequireComponent(typeof(Rigidbody))]
    public sealed class MotorcycleController : MonoBehaviour
    {
        [Header("Calibration is required before enabling the simulation")]
        [FormerlySerializedAs("physicalScaleVerified")]
        [Tooltip("Scale configured in SI units. This does not certify factory dimensions.")]
        [SerializeField] private bool physicalScaleConfigured;
        [SerializeField] private WheelCollider frontWheel;
        [SerializeField] private WheelCollider rearWheel;
        [Tooltip("Provisional simulator tuning. Not Honda factory specifications.")]
        [SerializeField] private DrivetrainSettings tuning = new DrivetrainSettings();
        [Header("Steering and optional balance assistance")]
        [SerializeField] private float lowSpeedSteerDegrees = 20;
        [SerializeField] private float highSpeedSteerDegrees = 5;
        [SerializeField] private float maxLeanDegrees = 18;
        [SerializeField] private float maximumSpeedKph = 50;
        [SerializeField] private float balanceAcceleration = 35;
        [SerializeField] private float balanceDamping = 10;
        [SerializeField] private float maxBalanceAcceleration = 50;
        [SerializeField] private bool balanceAssistance = true;
        [SerializeField] private float clutchPullRate = 8;
        [SerializeField] private float clutchReleaseRate = .6f;
        [SerializeField] private float physicalWheelbaseMetres = 1.315f;

        private Rigidbody body;
        private Drivetrain drivetrain;
        private float throttle, clutch = 1, frontBrake, rearBrake, steer, smoothedSteer;
        private int shiftRequest;
        private bool ignitionRequested, neutralRequested;
        private ClutchActuator clutchActuator;
        private Vector3 spawnPosition;
        private Quaternion spawnRotation;
        public DriveOutput Telemetry { get; private set; }
        public float FrontSteerAngleDegrees => frontWheel == null ? 0 : frontWheel.steerAngle;
        public WheelCollider FrontWheel => frontWheel;
        public bool FrontGrounded => frontWheel != null && frontWheel.isGrounded;
        public bool RearGrounded => rearWheel != null && rearWheel.isGrounded;
        public float MaximumSpeedKph => maximumSpeedKph;
        private Vector3 BodyVelocity
        {
            get
            {
#if UNITY_6000_0_OR_NEWER
                return body.linearVelocity;
#else
                return body.velocity;
#endif
            }
        }
        public float SpeedKph => body == null ? 0 : Vector3.ProjectOnPlane(BodyVelocity, Vector3.up).magnitude * 3.6f;
        public bool IsReady => enabled && drivetrain != null;

        private void Awake()
        {
            body = GetComponent<Rigidbody>();
            if (!physicalScaleConfigured || frontWheel == null || rearWheel == null || frontWheel == rearWheel)
            {
                Debug.LogError("Calibrate model scale in meters and assign separate front/rear WheelColliders before enabling MotoSim.", this);
                enabled = false; return;
            }
            if ((transform.lossyScale - Vector3.one).sqrMagnitude > .000001f ||
                Vector3.Distance(frontWheel.transform.position, rearWheel.transform.position) < .5f ||
                Vector3.Distance(frontWheel.transform.position, rearWheel.transform.position) > 3 ||
                frontWheel.radius <= 0 || rearWheel.radius <= 0)
            {
                Debug.LogError("Use an unscaled Rigidbody root, calibrated wheel radii and a physical wheelbase. Scale the visual child separately.", this);
                enabled = false; return;
            }
            spawnPosition = body.position; spawnRotation = body.rotation;
            try { drivetrain = new Drivetrain(tuning); clutchActuator = new ClutchActuator(clutchPullRate, clutchReleaseRate); }
            catch (ArgumentException e) { Debug.LogError("Invalid drivetrain tuning: " + e.Message, this); enabled = false; }
        }

        public void Configure(WheelCollider front, WheelCollider rear, BikePhysicsProfile profile)
        {
            profile.Validate(); frontWheel = front; rearWheel = rear; physicalScaleConfigured = true;
            clutchPullRate = profile.ClutchPullPerSecond; clutchReleaseRate = profile.ClutchReleasePerSecond;
            physicalWheelbaseMetres = profile.WheelbaseMetres;
            maximumSpeedKph = profile.TrainingSpeedLimitKph;
        }

        public void ResetToStart()
        {
            if (body == null || drivetrain == null) return;
            body.position = spawnPosition; body.rotation = spawnRotation;
#if UNITY_6000_0_OR_NEWER
            body.linearVelocity = Vector3.zero;
#else
            body.velocity = Vector3.zero;
#endif
            body.angularVelocity = Vector3.zero;
            drivetrain = new Drivetrain(tuning); clutchActuator = new ClutchActuator(clutchPullRate, clutchReleaseRate);
            Telemetry = default; ClearInput();
        }

        // Any input source (keyboard, gamepad, wheel) can feed the same interface.
        public void SetControls(float gas, float clutchLever, float front, float rear, float steering)
        {
            throttle = Mathf.Clamp01(gas); clutch = Mathf.Clamp01(clutchLever);
            frontBrake = Mathf.Clamp01(front); rearBrake = Mathf.Clamp01(rear); steer = Mathf.Clamp(steering, -1, 1);
        }

        public void RequestShift(int direction)
        {
            if (direction != -1 && direction != 1) throw new ArgumentOutOfRangeException(nameof(direction));
            shiftRequest = direction; neutralRequested = false;
        }
        public void RequestNeutral() { neutralRequested = true; shiftRequest = 0; }
        public void RequestIgnitionToggle() => ignitionRequested = !ignitionRequested;
        public void ClearInput()
        { SetControls(0, 1, 0, 0, 0); shiftRequest = 0; ignitionRequested = false; neutralRequested = false; }

        private void FixedUpdate()
        {
            if (drivetrain == null) return;
            float actualClutch = clutchActuator.Step(Time.fixedDeltaTime, clutch);
            if (ignitionRequested)
            {
                ignitionRequested = false;
                if (drivetrain.EngineRunning) drivetrain.StopEngine();
                else drivetrain.TryStartEngine(actualClutch >= tuning.ShiftClutchThreshold);
            }
            // A keyboard stroke may arrive while the lever is still moving; apply once pulled.
            bool shiftReady = actualClutch >= tuning.ShiftClutchThreshold;
            var commands = new RiderCommands(throttle, actualClutch, frontBrake, rearBrake,
                shiftReady ? shiftRequest : 0, shiftReady && neutralRequested);
            if (shiftReady || clutch < tuning.ShiftClutchThreshold) { shiftRequest = 0; neutralRequested = false; }
            Telemetry = drivetrain.Step(Time.fixedDeltaTime, commands, rearWheel.rpm * (2 * Mathf.PI / 60));
            Vector3 horizontalVelocity = Vector3.ProjectOnPlane(BodyVelocity, Vector3.up);
            float speedKph = horizontalVelocity.magnitude * 3.6f;
            float driveTorque = Telemetry.RearDriveTorqueNm;
            if (driveTorque > 0 && Vector3.Dot(horizontalVelocity, transform.forward) > 0)
                driveTorque *= VehicleCalibration.SpeedLimiterScale(speedKph, maximumSpeedKph, 3f);
            rearWheel.motorTorque = driveTorque;
            frontWheel.motorTorque = 0;
            frontWheel.brakeTorque = Telemetry.FrontBrakeTorqueNm;
            rearWheel.brakeTorque = Telemetry.RearBrakeTorqueNm;

            smoothedSteer = Mathf.MoveTowards(smoothedSteer, steer, 4 * Time.fixedDeltaTime);
            float speed = Vector3.ProjectOnPlane(BodyVelocity, Vector3.up).magnitude;
            float geometricLimit = VehicleCalibration.SafeSteerDegrees(speed,
                physicalWheelbaseMetres,
                lowSpeedSteerDegrees, maxLeanDegrees, Mathf.Max(.1f, Physics.gravity.magnitude));
            frontWheel.steerAngle = smoothedSteer * Mathf.Min(geometricLimit,
                Mathf.Lerp(lowSpeedSteerDegrees, highSpeedSteerDegrees,
                    Mathf.Clamp01(speed / Mathf.Max(1, maximumSpeedKph / 3.6f))));
            if (balanceAssistance && (frontWheel.isGrounded || rearWheel.isGrounded)) ApplyBalance(speed);
            Vector3 velocity = BodyVelocity;
            float drag = .5f * 1.225f * .6f * velocity.sqrMagnitude;
            float rolling = (frontWheel.isGrounded || rearWheel.isGrounded) && speed > .2f ? .008f * body.mass * Physics.gravity.magnitude : 0;
            if (velocity.sqrMagnitude > .0001f) body.AddForce(-velocity.normalized * drag, ForceMode.Force);
            Vector3 groundVelocity = Vector3.ProjectOnPlane(velocity, Vector3.up);
            if (rolling > 0 && groundVelocity.sqrMagnitude > .0001f)
                body.AddForce(-groundVelocity.normalized * rolling, ForceMode.Force);
            CapTrainingSpeed(velocity);
        }

        private void CapTrainingSpeed(Vector3 currentVelocity)
        {
            Vector3 horizontal = Vector3.ProjectOnPlane(currentVelocity, Vector3.up);
            float limit = maximumSpeedKph / 3.6f;
            if (horizontal.magnitude <= limit) return;
            Vector3 cappedVelocity = currentVelocity - horizontal + horizontal.normalized * limit;
#if UNITY_6000_0_OR_NEWER
            body.linearVelocity = cappedVelocity;
#else
            body.velocity = cappedVelocity;
#endif
        }

        private void LateUpdate()
        {
            // Clamp again after the physics step so gravity/collision impulses cannot
            // leave the training straight above its configured maximum between ticks.
            if (body != null && drivetrain != null) CapTrainingSpeed(BodyVelocity);
        }

        private void ApplyBalance(float speed)
        {
            float wheelbase = physicalWheelbaseMetres;
            float gravity = Mathf.Max(.1f, Physics.gravity.magnitude);
            float lean = Mathf.Atan(speed * speed * Mathf.Tan(frontWheel.steerAngle * Mathf.Deg2Rad) / (wheelbase * gravity)) * Mathf.Rad2Deg;
            lean = Mathf.Clamp(lean, -maxLeanDegrees, maxLeanDegrees);
            Vector3 forward = transform.forward.normalized;
            if (forward.sqrMagnitude < .001f) return;
            Vector3 targetUp = Quaternion.AngleAxis(-lean, forward) * Vector3.up;
            Vector3 currentUp = Vector3.ProjectOnPlane(transform.up, forward).normalized;
            targetUp = Vector3.ProjectOnPlane(targetUp, forward).normalized;
            if (currentUp.sqrMagnitude < .001f || targetUp.sqrMagnitude < .001f) return;

            // Roll is rotation around the bike's forward axis. Crossing the two up
            // vectors directly produces a pitch/yaw torque and cannot catch a fall.
            float rollErrorRadians = Vector3.SignedAngle(currentUp, targetUp, forward) * Mathf.Deg2Rad;
            float rollRate = Vector3.Dot(body.angularVelocity, forward);
            float rollAcceleration = rollErrorRadians * balanceAcceleration - rollRate * balanceDamping;
            body.AddTorque(forward * Mathf.Clamp(rollAcceleration, -maxBalanceAcceleration, maxBalanceAcceleration),
                ForceMode.Acceleration);
        }

        private void OnDisable()
        {
            if (frontWheel != null) { frontWheel.motorTorque = 0; frontWheel.brakeTorque = 0; }
            if (rearWheel != null) { rearWheel.motorTorque = 0; rearWheel.brakeTorque = 0; }
            drivetrain?.StopEngine(); ClearInput();
        }
    }
}
