using System;

namespace MotoSim.Core
{
    public static class CareerExperience
    {
        public const int MaximumLevel = 50;

        public static int ThresholdForLevel(int level)
        {
            int bounded = Math.Max(1, Math.Min(MaximumLevel, level));
            return 50 * bounded * (bounded - 1);
        }

        public static int LevelFor(int experience)
        {
            int total = Math.Max(0, experience);
            int level = 1;
            while (level < MaximumLevel && total >= ThresholdForLevel(level + 1)) level++;
            return level;
        }

        public static float Progress(int experience)
        {
            int level = LevelFor(experience);
            if (level == MaximumLevel) return 1f;
            int floor = ThresholdForLevel(level);
            int ceiling = ThresholdForLevel(level + 1);
            return Math.Max(0f, Math.Min(1f, (Math.Max(0, experience) - floor) / (float)(ceiling - floor)));
        }

        public static int MissionReward(MissionTier tier)
        {
            switch (tier)
            {
                case MissionTier.Easy: return 60;
                case MissionTier.Medium: return 120;
                default: return 240;
            }
        }
    }
}
