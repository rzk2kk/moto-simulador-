using UnityEngine;

namespace MotoSim.Unity
{
    /// <summary>Simple articulated rider, visible in third person with animated hands in first person.</summary>
    public sealed class RiderAvatar : MonoBehaviour
    {
        [SerializeField] private GameObject motorcycleModel;
        [SerializeField] private MotorcycleController motorcycle;
        [SerializeField] private RideCamera rideCamera;
        [SerializeField] private GameObject humanModel;
        [SerializeField] private GameObject femaleModel;
        [SerializeField] private GameObject firstPersonArms;
        [SerializeField] private GameObject femaleFirstPersonArms;
        [SerializeField] private AnimationClip seatedAnimation;
        private GameObject body;
        private Transform leftArm, rightArm, leftHand, rightHand, leftLever, rightLever, throttleGrip;
        private Material suit, glove, helmet, visor, metal;
        private Vector3 leftGrip, rightGrip;
        private Transform rigLeftHand, rigRightHand;
        private Quaternion rigLeftRest, rigRightRest;

        public void Configure(GameObject visual, MotorcycleController vehicle, RideCamera camera)
        { motorcycleModel = visual; motorcycle = vehicle; rideCamera = camera; }

        public void SetHumanModel(GameObject actor, AnimationClip seated)
        {
            humanModel = actor; seatedAnimation = seated;
            if (actor != null)
            {
                actor.transform.SetParent(transform, false);
                actor.transform.localPosition = new Vector3(0, .64f, .10f);
            }
        }

        public void SetFemaleModel(GameObject actor)
        {
            femaleModel = actor;
            if (actor != null)
            {
                actor.transform.SetParent(transform, false);
                actor.transform.localPosition = new Vector3(0, .64f, .10f);
            }
        }

        public void SetFirstPersonArms(GameObject arms)
        {
            firstPersonArms = arms;
            if (arms != null)
            {
                arms.transform.SetParent(transform, false);
                arms.transform.localPosition = new Vector3(0, .64f, .10f);
            }
        }

        public void SetFemaleFirstPersonArms(GameObject arms)
        {
            femaleFirstPersonArms = arms;
            if (arms != null) arms.transform.SetParent(transform, false);
        }

        private void Start()
        {
            Shader shader = Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Standard");
            if (shader == null) return;
            suit = MakeMaterial(shader, new Color(.025f, .028f, .035f));
            glove = MakeMaterial(shader, new Color(.12f, .13f, .15f));
            helmet = MakeMaterial(shader, new Color(.15f, .018f, .025f));
            visor = MakeMaterial(shader, new Color(.008f, .012f, .018f));
            metal = MakeMaterial(shader, new Color(.55f, .57f, .59f));
            Transform bodyRoot = new GameObject("Corpo_Piloto").transform;
            bodyRoot.SetParent(transform, false);
            body = bodyRoot.gameObject;
            GameObject selectedHuman = MotoCareerProfile.Gender == 1 && femaleModel != null ? femaleModel : humanModel;
            if (humanModel != null && humanModel != selectedHuman) humanModel.SetActive(false);
            if (femaleModel != null && femaleModel != selectedHuman) femaleModel.SetActive(false);
            humanModel = selectedHuman;
            GameObject selectedArms = MotoCareerProfile.Gender == 1 && femaleFirstPersonArms != null ?
                femaleFirstPersonArms : firstPersonArms;
            if (firstPersonArms != null && firstPersonArms != selectedArms) firstPersonArms.SetActive(false);
            if (femaleFirstPersonArms != null && femaleFirstPersonArms != selectedArms) femaleFirstPersonArms.SetActive(false);
            firstPersonArms = selectedArms;
            if (humanModel != null)
            {
                humanModel.transform.SetParent(bodyRoot, false);
                humanModel.transform.localPosition = new Vector3(0, .64f, .10f);
                humanModel.transform.localRotation = Quaternion.identity;
                if (seatedAnimation != null && seatedAnimation.legacy)
                {
                    Animation animation = humanModel.GetComponent<Animation>();
                    if (animation == null) animation = humanModel.AddComponent<Animation>();
                    if (animation.GetClip(seatedAnimation.name) == null)
                        animation.AddClip(seatedAnimation, seatedAnimation.name);
                    animation.clip = seatedAnimation;
                    animation[seatedAnimation.name].wrapMode = WrapMode.Loop;
                    animation.Play(seatedAnimation.name);
                }
            }
            else
            {
                Shape("Tronco", PrimitiveType.Capsule, bodyRoot, new Vector3(0, 1.11f, .20f), new Vector3(.34f, .33f, .24f), suit);
                Shape("Capacete", PrimitiveType.Sphere, bodyRoot, new Vector3(0, 1.61f, .40f), new Vector3(.34f, .38f, .35f), helmet);
                Shape("Viseira", PrimitiveType.Sphere, bodyRoot, new Vector3(0, 1.64f, .59f), new Vector3(.29f, .18f, .10f), visor);
                Shape("Quadril", PrimitiveType.Capsule, bodyRoot, new Vector3(0, .83f, .10f), new Vector3(.34f, .18f, .29f), suit);
                for (int side = -1; side <= 1; side += 2)
                {
                    Vector3 hip = new Vector3(side * .16f, .76f, .13f);
                    Vector3 knee = new Vector3(side * .32f, .50f, .52f);
                    Vector3 foot = new Vector3(side * .28f, .30f, .08f);
                    Segment("Coxa", bodyRoot, hip, knee, .11f, suit);
                    Segment("Perna", bodyRoot, knee, foot, .085f, suit);
                    Shape("Bota", PrimitiveType.Capsule, bodyRoot, foot, new Vector3(.17f, .13f, .28f), glove);
                }
            }
            leftGrip = new Vector3(-.36f, 1.19f, 1.05f);
            rightGrip = new Vector3(.36f, 1.19f, 1.05f);
            leftArm = Segment("Braco_Embreagem", transform, new Vector3(-.18f, 1.37f, .40f), leftGrip, .075f, suit);
            rightArm = Segment("Braco_Freio", transform, new Vector3(.18f, 1.37f, .40f), rightGrip, .075f, suit);
            leftHand = Shape("Mao_Embreagem", PrimitiveType.Capsule, transform, leftGrip, new Vector3(.13f, .08f, .22f), glove);
            rightHand = Shape("Mao_Acelerador_Freio", PrimitiveType.Capsule, transform, rightGrip, new Vector3(.13f, .08f, .22f), glove);
            leftLever = Segment("Manete_Embreagem_Animado", transform, leftGrip + new Vector3(-.18f, -.03f, .03f),
                leftGrip + new Vector3(.03f, -.04f, .12f), .015f, metal);
            rightLever = Segment("Manete_Freio_Animado", transform, rightGrip + new Vector3(-.03f, -.03f, .12f),
                rightGrip + new Vector3(.18f, -.03f, .03f), .015f, metal);
            throttleGrip = Shape("Punho_Acelerador_Animado", PrimitiveType.Cylinder, transform,
                rightGrip + new Vector3(.10f, .0f, -.02f), new Vector3(.055f, .13f, .055f), glove);
            if (firstPersonArms != null && seatedAnimation != null && seatedAnimation.legacy)
            {
                Animation armAnimation = firstPersonArms.GetComponent<Animation>();
                if (armAnimation == null) armAnimation = firstPersonArms.AddComponent<Animation>();
                if (armAnimation.GetClip(seatedAnimation.name) == null)
                    armAnimation.AddClip(seatedAnimation, seatedAnimation.name);
                armAnimation.clip = seatedAnimation;
                armAnimation[seatedAnimation.name].wrapMode = WrapMode.Loop;
                armAnimation.Play(seatedAnimation.name);
            }
            if (firstPersonArms != null)
            {
                foreach (Transform bone in firstPersonArms.GetComponentsInChildren<Transform>(true))
                {
                    if (bone.name == "Bip01 L Hand") rigLeftHand = bone;
                    if (bone.name == "Bip01 R Hand") rigRightHand = bone;
                }
                if (rigLeftHand != null) rigLeftRest = rigLeftHand.localRotation;
                if (rigRightHand != null) rigRightRest = rigRightHand.localRotation;
            }
        }

        private void LateUpdate()
        {
            if (body == null || motorcycle == null) return;
            body.SetActive(rideCamera == null || !rideCamera.IsFirstPerson);
            if (firstPersonArms != null) firstPersonArms.SetActive(rideCamera != null && rideCamera.IsFirstPerson);
            bool showProxyHands = humanModel == null && firstPersonArms == null;
            leftArm.gameObject.SetActive(showProxyHands && firstPersonArms == null);
            rightArm.gameObject.SetActive(showProxyHands && firstPersonArms == null);
            leftHand.gameObject.SetActive(showProxyHands);
            rightHand.gameObject.SetActive(showProxyHands);
            float clutch = motorcycle.ClutchLever;
            float brake = motorcycle.FrontBrakeInput;
            float throttle = motorcycle.ThrottleInput;
            leftHand.localPosition = leftGrip + new Vector3(0, -.035f * clutch, -.025f * clutch);
            leftHand.localRotation = Quaternion.Euler(15f * clutch, 0, 0);
            rightHand.localPosition = rightGrip + new Vector3(0, -.035f * brake, -.025f * brake);
            rightHand.localRotation = Quaternion.Euler(25f * throttle + 15f * brake, 0, 0);
            leftLever.localRotation = Quaternion.Euler(18f * clutch, 0, 0);
            rightLever.localRotation = Quaternion.Euler(22f * brake, 0, 0);
            throttleGrip.localRotation = Quaternion.Euler(-25f * throttle, 0, 90f);
            if (rigLeftHand != null) rigLeftHand.localRotation = rigLeftRest * Quaternion.Euler(12f * clutch, 0, 0);
            if (rigRightHand != null) rigRightHand.localRotation = rigRightRest * Quaternion.Euler(15f * throttle + 8f * brake, 0, 0);
            PlaceSegment(leftArm, new Vector3(-.18f, 1.37f, .40f), leftHand.localPosition, .075f);
            PlaceSegment(rightArm, new Vector3(.18f, 1.37f, .40f), rightHand.localPosition, .075f);
        }

        private static Material MakeMaterial(Shader shader, Color color)
        {
            Material material = new Material(shader) { color = color };
            if (material.HasProperty("_BaseColor")) material.SetColor("_BaseColor", color);
            return material;
        }
        private static Transform Shape(string name, PrimitiveType primitive, Transform parent, Vector3 position, Vector3 scale, Material material)
        {
            GameObject obj = GameObject.CreatePrimitive(primitive);
            obj.name = name; obj.transform.SetParent(parent, false);
            obj.transform.localPosition = position; obj.transform.localScale = scale;
            obj.GetComponent<Renderer>().material = material;
            Collider collider = obj.GetComponent<Collider>(); if (collider != null) Destroy(collider);
            return obj.transform;
        }
        private static Transform Segment(string name, Transform parent, Vector3 start, Vector3 end, float radius, Material material)
        {
            Transform piece = Shape(name, PrimitiveType.Capsule, parent, Vector3.zero, Vector3.one, material);
            PlaceSegment(piece, start, end, radius);
            return piece;
        }
        private static void PlaceSegment(Transform piece, Vector3 start, Vector3 end, float radius)
        {
            Vector3 delta = end - start;
            piece.localPosition = (start + end) * .5f;
            piece.localRotation = Quaternion.FromToRotation(Vector3.up, delta.normalized);
            piece.localScale = new Vector3(radius * 2f, delta.magnitude * .5f, radius * 2f);
        }
    }
}
