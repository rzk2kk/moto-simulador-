using UnityEngine;

namespace MotoSim.Unity
{
    /// <summary>In-game first-person school scenes, with optional third-person camera.</summary>
    public sealed class SchoolStoryStage : MonoBehaviour
    {
        [SerializeField] private Camera storyCamera;
        [SerializeField] private GameObject learner;
        [SerializeField] private GameObject maleLearner;
        [SerializeField] private GameObject femaleLearner;
        [SerializeField] private GameObject instructor;
        [SerializeField] private GameObject entrance;
        [SerializeField] private GameObject classroom;
        [SerializeField] private GameObject demonstrationYard;
        [SerializeField] private GameObject examRoom;
        [SerializeField] private AnimationClip walk, idle, talk, sit;
        private Vector3 garagePosition;
        private Quaternion garageRotation;
        private bool visible, thirdPerson;
        private int lesson = -1;
        private float sceneStarted;
        private bool arrivalFinished;
        private bool instructorSpeaking;
        private Renderer[] learnerRenderers = new Renderer[0];

        private void Awake()
        {
            learnerRenderers = learner == null ? new Renderer[0] : learner.GetComponentsInChildren<Renderer>(true);
            if (storyCamera != null)
            {
                garagePosition = storyCamera.transform.position;
                garageRotation = storyCamera.transform.rotation;
            }
            visible = false;
            lesson = -1;
        }

        public void Configure(Camera camera, GameObject student, GameObject femaleStudent, GameObject teacher, GameObject door,
            GameObject classSet, GameObject yard, GameObject examSet, AnimationClip walking, AnimationClip waiting,
            AnimationClip speaking, AnimationClip sitting)
        {
            storyCamera = camera; learner = student; maleLearner = student; femaleLearner = femaleStudent; instructor = teacher;
            learnerRenderers = student == null ? new Renderer[0] : student.GetComponentsInChildren<Renderer>(true);
            entrance = door; classroom = classSet; demonstrationYard = yard; examRoom = examSet;
            walk = walking; idle = waiting; talk = speaking; sit = sitting;
            garagePosition = camera.transform.position;
            garageRotation = camera.transform.rotation;
            visible = true;
            SetPresentation(false, 0);
        }

        public void SetPresentation(bool active, int step)
        {
            if (storyCamera == null) return;
            GameObject desired = MotoCareerProfile.Gender == 1 && femaleLearner != null ? femaleLearner : maleLearner;
            if (learner != desired)
            {
                GameObject old = learner;
                learner = desired;
                if (old != null) old.SetActive(false);
                learnerRenderers = learner == null ? new Renderer[0] : learner.GetComponentsInChildren<Renderer>(true);
            }
            if (visible == active && (!active || lesson == step)) return;
            visible = active;
            lesson = step;
            sceneStarted = Time.unscaledTime;
            arrivalFinished = false;
            instructorSpeaking = false;
            bool arrival = active && step == 0;
            bool exam = active && step == MotoSchoolQuestions.LessonCount - 1;
            bool yard = active && !arrival && !exam && MotoSchoolQuestions.SceneForLesson(step) == 2;
            if (entrance != null) entrance.SetActive(arrival);
            if (classroom != null) classroom.SetActive(active && !arrival && !exam && !yard);
            if (demonstrationYard != null) demonstrationYard.SetActive(yard);
            if (examRoom != null) examRoom.SetActive(exam);
            if (learner != null) learner.SetActive(active);
            if (femaleLearner != null && femaleLearner != learner) femaleLearner.SetActive(false);
            if (instructor != null) instructor.SetActive(active);
            if (!active)
            {
                storyCamera.transform.SetPositionAndRotation(garagePosition, garageRotation);
                return;
            }
            float z = arrival ? 45f : exam ? 140f : yard ? 185f : 95f;
            if (learner != null)
            {
                learner.transform.SetPositionAndRotation(new Vector3(-.7f, 0, z - (arrival ? 5f : 3f)), Quaternion.identity);
                Play(learner, arrival ? walk : yard ? idle : sit);
            }
            if (instructor != null)
            {
                float instructorX = !arrival && !exam && !yard ?
                    (step % 3 == 0 ? 1.3f : step % 3 == 1 ? 2.5f : -2.6f) : 1.3f;
                instructor.transform.SetPositionAndRotation(new Vector3(instructorX, 0, z + (arrival ? 1.5f : 2f)),
                    Quaternion.Euler(0, 180, 0));
                Play(instructor, idle);
            }
            Vector3 eye = new Vector3(-.7f, 1.62f, z - (arrival ? 4.9f : 2.9f));
            Vector3 position = thirdPerson ? eye + new Vector3(2.4f, 1.1f, -4.7f) : eye;
            Vector3 focus = thirdPerson ? new Vector3(0, 1.4f, z + 1f) :
                new Vector3(1.3f, 1.48f, z + 2f);
            storyCamera.transform.SetPositionAndRotation(position, Quaternion.LookRotation(focus - position));
        }

        public void SetSpeaking(bool speaking)
        {
            if (!visible || instructor == null || instructorSpeaking == speaking) return;
            instructorSpeaking = speaking;
            Play(instructor, speaking ? talk : idle);
        }

        private static void Play(GameObject actor, AnimationClip clip)
        {
            if (actor == null || clip == null || !clip.legacy) return;
            Animation animation = actor.GetComponent<Animation>();
            if (animation == null) animation = actor.AddComponent<Animation>();
            if (animation.GetClip(clip.name) == null) animation.AddClip(clip, clip.name);
            animation.clip = clip;
            animation[clip.name].wrapMode = WrapMode.Loop;
            animation.Play(clip.name);
        }

        private void Update()
        {
            if (!visible || storyCamera == null) return;
#if ENABLE_LEGACY_INPUT_MANAGER
            if (Input.GetKeyDown(KeyCode.V)) thirdPerson = !thirdPerson;
#endif
            float z = lesson == 0 ? 45f : lesson == MotoSchoolQuestions.LessonCount - 1 ? 140f :
                MotoSchoolQuestions.SceneForLesson(lesson) == 2 ? 185f : 95f;
            if (learner != null && lesson == 0)
            {
                Vector3 target = new Vector3(-.7f, 0, z - 2.5f);
                learner.transform.position = Vector3.Lerp(new Vector3(-.7f, 0, z - 5f), target,
                    Mathf.Clamp01((Time.unscaledTime - sceneStarted) / 6f));
                if (!arrivalFinished && Time.unscaledTime - sceneStarted > 6f)
                {
                    arrivalFinished = true;
                    Play(learner, idle);
                }
            }
            foreach (Renderer renderer in learnerRenderers)
                if (renderer != null) renderer.enabled = thirdPerson;
            Vector3 eye = learner == null ? new Vector3(-.7f, 1.62f, z - 3f) :
                learner.transform.position + new Vector3(0, 1.62f, .1f);
            Vector3 cameraPosition = thirdPerson ? eye + new Vector3(2.4f, 1.1f, -4.7f) : eye;
            bool inClass = lesson > 0 && lesson < MotoSchoolQuestions.LessonCount - 1 &&
                MotoSchoolQuestions.SceneForLesson(lesson) != 2;
            Vector3 focus = thirdPerson ? new Vector3(0, 1.4f, z + 1f) :
                inClass && lesson % 3 == 1 ? new Vector3(0f, 2.2f, z + 5.8f) :
                inClass && lesson % 3 == 2 ? new Vector3(-3f, 1.5f, z + 1.3f) :
                instructor != null ? instructor.transform.position + Vector3.up * 1.48f :
                new Vector3(1.3f, 1.48f, z + 2f);
            storyCamera.transform.position = Vector3.Lerp(storyCamera.transform.position, cameraPosition,
                1f - Mathf.Exp(-5f * Time.unscaledDeltaTime));
            storyCamera.transform.rotation = Quaternion.Slerp(storyCamera.transform.rotation,
                Quaternion.LookRotation(focus - cameraPosition), 1f - Mathf.Exp(-5f * Time.unscaledDeltaTime));
        }
    }
}
