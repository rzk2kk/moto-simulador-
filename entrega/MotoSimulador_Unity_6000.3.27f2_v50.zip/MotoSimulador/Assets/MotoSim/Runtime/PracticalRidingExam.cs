using UnityEngine;
using UnityEngine.SceneManagement;

namespace MotoSim.Unity
{
    /// <summary>Ordered full-course check with fall, speed and obstacle penalties.</summary>
    public sealed class PracticalRidingExam : MonoBehaviour
    {
        private static readonly Vector3[] Route = {
            new Vector3(0, 0, 45), new Vector3(0, 0, 88),
            new Vector3(0, 0, 135), new Vector3(0, 0, 190),
            new Vector3(8, 0, 235), new Vector3(56, 0, 245)
        };
        private static readonly Vector3 TrackOffset = new Vector3(1200f, 0f, 0f);
        [SerializeField] private MotorcycleController motorcycle;
        [SerializeField] private GameObject handoverInstructor;
        [SerializeField] private AnimationClip handoverGesture;
        private int stage;
        private bool active, failed, complete;
        private GameObject marker;
        private float excessiveSpeedTime;
        private float offRoadTime;
        private float licencePresentedAt;
        private GUIStyle labelStyle;

        public void Configure(MotorcycleController vehicle) => motorcycle = vehicle;

        public void SetHandoverInstructor(GameObject actor, AnimationClip gesture)
        {
            handoverInstructor = actor;
            handoverGesture = gesture;
            if (actor != null) actor.SetActive(false);
        }

        private void Start()
        {
            active = SceneManager.GetActiveScene().path.EndsWith("Autoescola_ProvaPratica.unity") &&
                PlayerPrefs.GetInt("MotoSim.Career.PracticalActive", 0) == 1 &&
                PlayerPrefs.GetInt("MotoSim.Career.TheoryPassed", 0) == 1;
            if (active) CreateMarker();
        }

        private void Update()
        {
            if (complete)
            {
                if (handoverInstructor != null && motorcycle != null)
                {
                    float approach = Mathf.Clamp01((Time.unscaledTime - licencePresentedAt) / 2f);
                    Vector3 side = motorcycle.transform.right;
                    side.y = 0f; side.Normalize();
                    Vector3 position = motorcycle.transform.position + side * Mathf.Lerp(3f, 1.7f, approach);
                    position.y = motorcycle.transform.position.y;
                    handoverInstructor.transform.position = position;
                    handoverInstructor.transform.rotation = Quaternion.LookRotation(-side, Vector3.up);
                }
                return;
            }
            if (!active || failed || motorcycle == null) return;
            if (Vector3.Dot(motorcycle.transform.up, Vector3.up) < .45f) { Fail(); return; }
            excessiveSpeedTime = motorcycle.SpeedKph > 45f ? excessiveSpeedTime + Time.deltaTime : 0;
            if (excessiveSpeedTime > 2f) { Fail(); return; }
            offRoadTime = DistanceFromCourse(motorcycle.transform.position) > 14f ? offRoadTime + Time.deltaTime : 0f;
            if (offRoadTime > 3f) { Fail(); return; }
            Vector3 offset = motorcycle.transform.position - (Route[stage] + TrackOffset);
            offset.y = 0;
            if (offset.sqrMagnitude > 14f * 14f) return;
            stage++;
            if (marker != null) Destroy(marker);
            if (stage == Route.Length)
            {
                complete = true;
                PlayerPrefs.SetInt("MotoSim.Career.PracticalPassed", 1);
                PlayerPrefs.SetInt("MotoSim.Career.PracticalActive", 0);
                MotoCareerProfile.MarkLicensed();
                PlayerPrefs.Save();
                MotoCareerProgress.AddCredits(5000);
                MotoCareerProgress.AddExperience(300);
                MotoMissionBoard.SyncMilestones();
                MotoCareerSaveSlots.SaveActive();
                licencePresentedAt = Time.unscaledTime;
                if (handoverInstructor != null)
                {
                    handoverInstructor.SetActive(true);
                    if (handoverGesture != null && handoverGesture.legacy)
                    {
                        Animation animation = handoverInstructor.GetComponent<Animation>();
                        if (animation == null) animation = handoverInstructor.AddComponent<Animation>();
                        animation.AddClip(handoverGesture, handoverGesture.name);
                        animation.clip = handoverGesture;
                        animation[handoverGesture.name].wrapMode = WrapMode.Loop;
                        animation.Play(handoverGesture.name);
                    }
                }
            }
            else CreateMarker();
        }

        private void OnCollisionEnter(Collision collision)
        {
            if (!active || failed || complete) return;
            string part = collision.collider.name;
            if (part.StartsWith("Cone_") || part.StartsWith("Balizador_") || part.StartsWith("Marco_Oito_")) Fail();
        }

        private static float DistanceFromCourse(Vector3 position)
        {
            Vector3 previous = TrackOffset + new Vector3(0f, 0f, -5f);
            float nearest = float.MaxValue;
            foreach (Vector3 checkpoint in Route)
            {
                Vector3 next = checkpoint + TrackOffset;
                Vector3 direction = next - previous;
                float t = Mathf.Clamp01(Vector3.Dot(position - previous, direction) / direction.sqrMagnitude);
                Vector3 projection = previous + direction * t;
                nearest = Mathf.Min(nearest, Vector3.ProjectOnPlane(position - projection, Vector3.up).magnitude);
                previous = next;
            }
            return nearest;
        }

        private void Fail() { failed = true; if (marker != null) marker.SetActive(false); }

        private void CreateMarker()
        {
            marker = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            marker.name = "Proxima_Etapa_Pratico_" + (stage + 1);
            marker.transform.position = Route[stage] + TrackOffset + Vector3.up * 2.5f;
            marker.transform.localScale = Vector3.one * .8f;
            Collider collider = marker.GetComponent<Collider>();
            if (collider != null) Destroy(collider);
            Shader shader = Shader.Find("Universal Render Pipeline/Unlit") ?? Shader.Find("Unlit/Color");
            if (shader != null)
            {
                var material = new Material(shader) { color = new Color(1f, .72f, .04f) };
                marker.GetComponent<Renderer>().material = material;
            }
        }

        private void OnGUI()
        {
            if (!active) return;
            if (labelStyle == null) labelStyle = new GUIStyle(GUI.skin.label) {
                fontSize = 17, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleCenter,
                normal = { textColor = Color.white } };
            Rect panel = new Rect(Screen.width * .5f - 240, 52, 480, failed || complete ? 112 : 70);
            GUI.Box(panel, GUIContent.none);
            string message = failed ? MotoRegion.T("PROVA PRÁTICA REPROVADA", "PRACTICAL TEST FAILED", "PRUEBA PRÁCTICA REPROBADA") :
                complete ? MotoRegion.T("PROVA PRÁTICA APROVADA · CIDADE EM BREVE", "PRACTICAL TEST PASSED · CITY COMING SOON", "PRUEBA PRÁCTICA APROBADA · CIUDAD PRÓXIMAMENTE") :
                MotoRegion.T("PROVA PRÁTICA  ·  ETAPA ", "PRACTICAL TEST  ·  STAGE ", "PRUEBA PRÁCTICA  ·  ETAPA ") + (stage + 1).ToString() + "/" + Route.Length;
            GUI.Label(new Rect(panel.x + 8, panel.y + 6, panel.width - 16, 32), message, labelStyle);
            if (!failed && !complete)
                GUI.Label(new Rect(panel.x + 8, panel.y + 37, panel.width - 16, 23),
                    MotoRegion.T("Siga o marcador amarelo. Até 45 km/h, sem derrubar cones.", "Follow the yellow marker. Stay under 45 km/h and avoid cones.", "Sigue el marcador amarillo. Hasta 45 km/h, sin tocar conos."), labelStyle);
            if (failed && GUI.Button(new Rect(panel.x + 95, panel.y + 49, 290, 48),
                MotoRegion.T("REINICIAR PROVA", "RETRY TEST", "REPETIR PRUEBA")))
            {
                stage = 0; failed = false; excessiveSpeedTime = 0; offRoadTime = 0;
                motorcycle.ResetToStart(); CreateMarker();
            }
            if (complete) DrawLicenceCeremony();
        }

        private void DrawLicenceCeremony()
        {
            float t = Mathf.Clamp01((Time.unscaledTime - licencePresentedAt) / 1.4f);
            t = t * t * (3f - 2f * t);
            float width = Mathf.Min(520f, Screen.width * .83f);
            float height = Mathf.Min(300f, Screen.height * .48f);
            Rect card = new Rect((Screen.width - width) * .5f + (1f - t) * Screen.width * .4f,
                Screen.height * .5f - height * .5f, width, height);
            Color old = GUI.color;
            GUI.color = new Color(.04f, .09f, .13f, .95f * t);
            GUI.DrawTexture(card, Texture2D.whiteTexture);
            GUI.color = new Color(.91f, .72f, .22f, t);
            GUI.DrawTexture(new Rect(card.x, card.y, card.width, 5), Texture2D.whiteTexture);
            GUI.color = new Color(1f, 1f, 1f, t);
            GUIStyle title = new GUIStyle(labelStyle) { fontSize = 23, alignment = TextAnchor.MiddleLeft };
            GUIStyle text = new GUIStyle(labelStyle) { fontSize = 16, alignment = TextAnchor.MiddleLeft };
            GUI.Label(new Rect(card.x + 24, card.y + 16, card.width - 48, 36),
                MotoRegion.T("HABILITAÇÃO DE PILOTAGEM", "RIDING LICENCE", "LICENCIA DE CONDUCCIÓN"), title);
            GUI.Label(new Rect(card.x + 24, card.y + 73, card.width - 48, 32),
                MotoRegion.T("PILOTO: ", "RIDER: ", "CONDUCTOR: ") + MotoCareerProfile.Name, text);
            GUI.Label(new Rect(card.x + 24, card.y + 116, card.width - 48, 30),
                MotoRegion.T("INÍCIO DA CARREIRA: ", "CAREER START: ", "INICIO DE CARRERA: ") + MotoCareerProfile.StartDate, text);
            GUI.Label(new Rect(card.x + 24, card.y + 152, card.width - 48, 30),
                MotoRegion.T("EMISSÃO: ", "ISSUED: ", "EMISIÓN: ") + MotoCareerProfile.LicenceDate, text);
            GUI.Label(new Rect(card.x + 24, card.y + height - 66, card.width - 48, 46),
                MotoRegion.T("Leo: parabéns, você concluiu a prova prática!",
                    "Leo: congratulations, you passed the practical test!",
                    "Leo: ¡felicidades, aprobaste la prueba práctica!"), text);
            GUI.color = old;
        }
    }
}
