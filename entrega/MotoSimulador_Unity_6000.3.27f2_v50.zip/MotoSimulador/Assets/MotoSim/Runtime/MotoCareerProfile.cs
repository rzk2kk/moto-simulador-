using System;
using System.Text;
using UnityEngine;

namespace MotoSim.Unity
{
    /// <summary>Identity and licence dates belong to the active career save.</summary>
    public static class MotoCareerProfile
    {
        public const string NameKey = "MotoSim.Career.PlayerName";
        public const string GenderKey = "MotoSim.Career.Gender";
        public const string StartedKey = "MotoSim.Career.StartedUtc";
        public const string LicensedKey = "MotoSim.Career.LicensedUtc";

        public static string Name
        {
            get
            {
                string saved = PlayerPrefs.GetString(NameKey, "");
                return string.IsNullOrWhiteSpace(saved) ? "Jogador" : saved;
            }
        }
        public static int Gender => Mathf.Clamp(PlayerPrefs.GetInt(GenderKey, 0), 0, 1);
        public static string StartDate => FormatDate(PlayerPrefs.GetString(StartedKey, ""));
        public static string LicenceDate => FormatDate(PlayerPrefs.GetString(LicensedKey, ""));
        public static bool HasLicence => !string.IsNullOrEmpty(PlayerPrefs.GetString(LicensedKey, ""));

        public static string CleanName(string raw)
        {
            if (string.IsNullOrWhiteSpace(raw)) return "";
            var clean = new StringBuilder();
            bool space = false;
            foreach (char ch in raw.Trim())
            {
                if (clean.Length >= 24) break;
                if (char.IsLetterOrDigit(ch) || ch == '-' || ch == '\'')
                {
                    clean.Append(ch); space = false;
                }
                else if (char.IsWhiteSpace(ch) && clean.Length > 0 && !space)
                {
                    clean.Append(' '); space = true;
                }
            }
            return clean.ToString().Trim();
        }

        public static bool Begin(string rawName, int gender)
        {
            string name = CleanName(rawName);
            if (name.Length < 2) return false;
            PlayerPrefs.SetString(NameKey, name);
            PlayerPrefs.SetInt(GenderKey, Mathf.Clamp(gender, 0, 1));
            PlayerPrefs.SetString(StartedKey, DateTime.UtcNow.Ticks.ToString());
            PlayerPrefs.DeleteKey(LicensedKey);
            MotoCareerSaveSlots.SaveActive();
            return true;
        }

        public static void MarkLicensed()
        {
            if (HasLicence) return;
            PlayerPrefs.SetString(LicensedKey, DateTime.UtcNow.Ticks.ToString());
            MotoCareerSaveSlots.SaveActive();
        }

        public static string FormatDate(string ticksText)
        {
            if (!long.TryParse(ticksText, out long ticks) ||
                ticks < DateTime.MinValue.Ticks || ticks > DateTime.MaxValue.Ticks) return "—";
            return new DateTime(ticks, DateTimeKind.Utc).ToLocalTime().ToString("dd/MM/yyyy");
        }
    }
}
