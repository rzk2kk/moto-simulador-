# Personagens e animações Rocketbox

Origem: https://github.com/microsoft/Microsoft-Rocketbox

Personagens Male_Adult_01, Male_Adult_02 e Female_Adult_01, com as texturas de corpo, rosto e opacidade. As animações vêm da pasta Assets/Animations do mesmo repositório. Os modelos *_Game.fbx foram preparados no Blender; os arquivos *_Bracos1P.fbx retêm braços e mãos da malha articulada para a câmera interna. As texturas foram convertidas de TGA para PNG e JPEG.

Licença: MIT, © 2020 Microsoft. O texto integral está em LICENSE.md e deve acompanhar os arquivos em redistribuições.

Estes personagens são uma base para evolução visual. A pose sobre cada moto, os encaixes de mãos nos controles e a reprodução das animações devem ser revisados no Unity Editor antes de considerar a apresentação final.
