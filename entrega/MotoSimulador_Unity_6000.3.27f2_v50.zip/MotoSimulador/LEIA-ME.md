# MotoSimulador — Unity 6.3 LTS / versão 50

Projeto para o Editor **6000.3.27f2** e URP **17.3.0**. A versão 44 melhora os painéis do lobby e da garagem, adiciona controles de giro da moto e amplia a autoescola para doze momentos: chegada, dez aulas e preparação para a prova. Cada uma das dez questões está ligada à sua própria aula e explicação. A prova exige oito acertos, mostra o tempo decorrido e não tem limite de tempo. O progresso da aula é salvo.

A v48 habilita o módulo Animation do Unity no manifesto do projeto. Ele é necessário para compilar `AnimationClip` e `Animation` nas cenas da história e no piloto; corrige os erros CS1069 enviados no log da v47. Reabra o projeto da v48 em uma pasta nova para que o Unity resolva o manifesto. A compilação completa ainda precisa ser confirmada no Editor Windows.

A v49 corrige o desnível entre os pneus da Street na preparação da cena, impede que peças altas do garfo da Adventure deslizem com a suspensão e atribui nomes estáveis e texturas externas aos materiais da pintura. As pistas recebem céu, nuvens, sol quente, névoa e sombras de maior alcance; a garagem recebe luzes para destacar as motos. A auditoria das três motos, com medições e limites da análise, está em `Documentation/AUDITORIA_MOTOS_v49.md`.

A v50 acrescenta criação de personagem com nome e escolha homem/mulher em cada carreira, seis espaços de salvamento, XP por missões e quilômetros pilotados, mais seis missões e colegas articulados nas aulas. A prova prática aprovada registra a data da habilitação e apresenta uma CNH no jogo com nome e datas da carreira. Os braços e mãos da câmera interna usam malhas do personagem Rocketbox. O lobby tem perfil com XP e botões com ícones destacados; as configurações incluem volume do instrutor e sombras. O Editor ainda precisa validar visualmente a pose do piloto, o enquadramento da sala e a cena de entrega da CNH. A geração de música via API ElevenLabs retornou `paid_plan_required` no plano gratuito, por isso não há música nova neste pacote.

A troca de idioma no lobby não fala. A história usa legendas e inclui 36 narrações offline do ElevenLabs: doze arquivos para cada idioma em Assets/Resources/MotoSim/Voice, com chegada e encerramento reescritos para uma conversa mais natural. A voz escolhida foi Eric, pois as vozes brasileiras profissionais da conta exigiam um plano pago; em português, ela pode ter sotaque. O script Tools/generate_elevenlabs_voice.py permite trocar a voz depois, com uma chave guardada no ambiente. **Nenhuma chave de API está no projeto ou no ZIP.** Documentation/VOICE_PROVENANCE_v46.json identifica a voz e o modelo usados. A reprodução ainda precisa ser conferida no Unity Editor.

A v43 ligou o garfo dianteiro da Street e da Adventure ao movimento da roda física. As três motos passaram no teste simplificado de arrancada com a massa e o limite de aderência de cada uma. A cena ainda precisa ser executada no Unity Editor para confirmar física e visual.

## Abrir e testar

1. Extraia o ZIP em uma pasta nova.
2. Abra `ABRIR_JOGO.bat`. Na primeira execução, ele compila o jogo em segundo plano e o inicia automaticamente. Se falhar, mostra as mensagens principais, abre o log no Bloco de Notas e mantém o Prompt aberto.
3. Depois da primeira compilação, o mesmo arquivo abre diretamente o executável. Use `ABRIR_PROJETO.bat` para editar no Unity.

Para sair: **I**, segure **Shift** e aperte **Q**; depois segure **W** e solte **Shift**. **A/D** dirigem, **Espaço** freia na frente, **S** freia atrás. **L** farol, **Z/X** setas, **H** alerta; **R** recomeça. Os botões correspondentes também estão no HUD. A liberação da embreagem é mais rápida e os manetes animam com o comando.

É um teste físico em revisão com **parâmetros provisórios**. Esta versão remove os retrovisores, tira as faixas adesivas, permite girar a câmera segurando o botão direito do mouse e arrastando, ajusta altura/distância da câmera em primeira pessoa e anima embreagem, freio, acelerador e chave de ignição. O farol, as setas e a luz de freio usam lentes translúcidas com emissão; foram adicionados sons procedurais de partida e motor ligado. A câmera em terceira pessoa orbita ao redor da moto.

O HUD foi reorganizado conforme a prévia aprovada: informações de motor, marcha, RPM, iluminação e comandos ficam em um painel compacto no alto à esquerda; o velocímetro circular menor fica embaixo à direita, com velocidade real e limite de pista; opções de câmera permanecem no alto à direita. Botões de motor, farol e sinalização são clicáveis.

A versão atual separa o teste livre da avaliação: o botão TESTAR abre uma área pavimentada simples e fechada, inclusive para motos ainda bloqueadas, sem conceder créditos ou desbloqueios. A prova prática fica em uma cena distinta, a 1,2 km de distância lógica, com percurso marcado e muros nos quatro lados. Ambas as áreas têm prédios ao redor. O posicionamento e o contato das rodas ainda precisam ser conferidos no Unity Editor.

A história da autoescola agora usa cenários 3D do próprio jogo: entrada, sala, pátio de demonstração e sala de prova. O jogador pode alternar a câmera da história entre primeira e terceira pessoa com V. Cada uma das dez aulas inclui uma decisão de treino antes da prova teórica; a progressão é manual. Dois personagens e quatro animações vêm da biblioteca Microsoft Rocketbox sob licença MIT; veja Assets/MotoSim/Art/Characters/Rocketbox/ORIGEM.md. O piloto realista substitui o corpo provisório na câmera externa da pilotagem. O ajuste fino de pose, mãos e textura será feito após teste no Unity.

Na v50, NOVO JOGO abre uma tela com seis espaços independentes para salvar a carreira. É possível continuar ou excluir cada espaço; a exclusão exige dois cliques. O salvamento automático registra dinheiro, motos compradas, pintura, aulas, provas, distância e missões. Uma carreira antiga é preservada no primeiro espaço quando o jogo atualiza. As opções de idioma, áudio e qualidade permanecem globais.

Há 21 missões de dificuldade crescente, com recompensa única: aulas, aprovação, distância, farol, setas, frenagem controlada, condução sem quedas e compras na garagem. A tela MISSÕES mostra objetivos, progresso e créditos. A prévia TESTAR continua sem acumular distância, missões ou dinheiro. Os objetivos de pilotagem valem na carreira após a prova prática.

Ajustes contra a instabilidade perto de 20 km/h: subpassos uniformes na faixa de baixa velocidade, torque limitado pela carga traseira estimada, centro de aplicação das forças mais baixo, suspensão mais amortecida e assistência de equilíbrio ativa mesmo com rodas fora do chão. As setas piscam, o farol tem feixe, a luz traseira reage ao freio e o HUD mostra velocímetro ligado à velocidade real do corpo. O limite continua em 50 km/h. A cena deve ser testada no PC; não há confirmação local da física e iluminação do Unity nesta nuvem.

O Editor precisa importar e compilar o projeto na primeira execução, o que pode demorar. O jogo Windows só é produzido no PC porque não há Unity Editor Windows neste ambiente de nuvem. O executável e o log ficam em `Build/Windows` e `Build/primeira_compilacao.log`.

## Estado real

- Modelo original preservado e visível; não substituído por formas genéricas.
- Escala uniforme calculada por entre-eixos configurável; raios medidos no modelo importado.
- Massa de moto/piloto, centro de massa, suspensão e aderência iniciais, ainda sem certificação para o ano da CG enviada.
- Motor, embreagem, marchas e freios independentes ligados a WheelColliders; assistência de equilíbrio e câmera de primeira pessoa.
- 39 testes C# puro aprovados; esses testes não executam Unity/PhysX.
- O código de build e os BATs foram preparados, mas não foi possível executar nem validar o executável sem o Editor Windows.

Consulte Documentation/TESTE_FISICO_v15.md para os ajustes, comandos e limitações. O perfil Assets/MotoSim/Config/PhysicsCalibration.json está marcado ReferenceVerified=false. Não apresentar seus números como especificações oficiais da Honda.

Guidão e conjunto do garfo dianteiro agora acompanham a direção e o curso físico da roda. A pintura preto/amarelo é demonstrativa. A velocidade da pista está limitada a 50 km/h. A câmera alterna entre primeira e terceira pessoa pelo botão no HUD ou tecla V. Amortecedores traseiros, corrente, sistema elétrico, painel original, piloto 3D, materiais finais e otimização ainda estão pendentes na Unity. O núcleo físico não equivale ao jogo completo.

## Automação

A marca MotoSimProject.json solicita a cena riding-test. A preparação preserva cenas Untitled em Generated/Recuperadas antes de criar outra cena, mantendo a correção v2. Não sobrescreve uma cena de teste já existente. O menu MotoSim/Abrir teste físico permite retomar; MotoSim/Abrir inspeção da moto mantém acesso à etapa visual anterior.

Câmera ativa e gravação da cena são verificadas antes do marcador de conclusão. Falhas são registradas no Console e em MotoSim_Setup_Error.txt. O relatório de escala/massa/raios é salvo em ProjectSettings/MotoSimCalibrationReport.json após montagem no PC.

## Reprodução

Na raiz do repositório: python3 tools/check_core.py. Gerar o pacote: python3 tools/package_unity_project.py. O núcleo tem fonte única em Assets/MotoSim/Core, referenciada pelos projetos .NET. O SDK local é preparado por tools/setup_dotnet.py com verificação SHA-512 oficial.

O BAT usa a instalação padrão C:\Program Files\Unity\Hub\Editor\6000.3.27f2\Editor\Unity.exe. Se estiver em outra pasta, o Hub pode abrir diretamente a pasta MotoSimulador. Nenhuma reinstalação do Editor é necessária para o pacote.

## Atribuição

CG 160: rafaazx1000, CC-BY-4.0; https://sketchfab.com/3d-models/cg-160-0900747144084e538244f8c504161baa . Modificações: separação de peças, hierarquia, materiais demonstrativos, exportação e montagem de teste. Preservar atribuição e indicação das alterações. Essa é a licença declarada do modelo, não uma declaração de licença para todo o código.
