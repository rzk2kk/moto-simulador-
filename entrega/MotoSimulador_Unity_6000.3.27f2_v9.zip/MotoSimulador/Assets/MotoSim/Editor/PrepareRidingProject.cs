using System;
using System.IO;
using System.Linq;
using MotoSim.Core;
using MotoSim.Unity;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.SceneManagement;

namespace MotoSim.Editor
{
    public static class PrepareRidingProject
    {
        internal const string ScenePath = "Assets/MotoSim/Generated/CG160_TesteFisico_v9.unity";
        private const string Generated = "Assets/MotoSim/Generated";
        private const string SessionKey = "MotoSim.RidingSetupAttempted_v9";
        private static string Root => Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
        private static string Completion => Path.Combine(Root, "ProjectSettings/MotoSimRidingSetup.json");
        internal static void TryAutomaticSetup()
        {
            if (File.Exists(Completion) && AssetDatabase.LoadAssetAtPath<SceneAsset>(ScenePath) != null)
            {
                var active = SceneManager.GetActiveScene();
                if (active.IsValid() && !active.isDirty && string.IsNullOrEmpty(active.path))
                    PrepareInspectionProject.OpenPreparedScene(ScenePath);
                return;
            }
            if (SessionState.GetBool(SessionKey, false)) return;
            SessionState.SetBool(SessionKey, true); RunSetup();
        }
        [MenuItem("MotoSim/Abrir teste físico")]
        public static void RunSetup()
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode || EditorApplication.isCompiling || EditorApplication.isUpdating)
            {
                EditorApplication.isPlaying = false; EditorApplication.delayCall += RunSetup; return;
            }
            try
            {
                PrepareInspectionProject.EnsureFolder("Assets/MotoSim", "Generated");
                PrepareInspectionProject.EnsureFolder(Generated, "Materials");
                PrepareInspectionProject.ConfigurePipeline();
                if (AssetDatabase.LoadAssetAtPath<SceneAsset>(ScenePath) == null) CreateScene();
                else PrepareInspectionProject.OpenPreparedScene(ScenePath);
                Scene scene = SceneManager.GetSceneByPath(ScenePath);
                if (!PrepareInspectionProject.HasGameCamera(scene)) throw new InvalidOperationException("O teste físico não possui câmera ativa.");
                AssetDatabase.SaveAssets();
                File.WriteAllText(Completion, "{\"physicsScenePrepared\":true,\"manufacturerReferenceVerified\":false}");
                Debug.Log("MotoSim: teste físico preparado com parâmetros provisórios. Validar comportamento em Play.");
            }
            catch (Exception error)
            {
                Debug.LogException(error); File.WriteAllText(Path.Combine(Root, "MotoSim_Setup_Error.txt"), error.ToString());
                EditorUtility.DisplayDialog("MotoSim — preparação incompleta", error.Message, "OK");
            }
        }
        private static void CreateScene()
        {
            var config = AssetDatabase.LoadAssetAtPath<TextAsset>("Assets/MotoSim/Config/PhysicsCalibration.json");
            if (config == null) throw new InvalidOperationException("Perfil de calibração não encontrado.");
            var profile = JsonUtility.FromJson<BikePhysicsProfile>(config.text); profile.Validate();
            var model = AssetDatabase.LoadAssetAtPath<GameObject>("Assets/MotoSim/Art/CG160_neutra_unidades_originais.fbx");
            if (model == null) throw new InvalidOperationException("A importação da moto não terminou.");
            var recovered = PrepareInspectionProject.PreserveUnnamedScenes();
            Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Additive);
            SceneManager.SetActiveScene(scene);
            var root = new GameObject("CG160_Fisica_Provisoria");
            var visual = (GameObject)PrefabUtility.InstantiatePrefab(model, scene);
            visual.name = "Modelo_Original"; visual.transform.SetParent(root.transform, true);
            Transform front = Find(visual, "Eixo_Roda_Dianteira"), rear = Find(visual, "Eixo_Roda_Traseira");
            Vector3 direction = Vector3.ProjectOnPlane(front.position - rear.position, Vector3.up);
            if (direction.sqrMagnitude < .000001f) throw new InvalidOperationException("Não foi possível identificar o sentido de avanço.");
            visual.transform.rotation = Quaternion.FromToRotation(direction.normalized, Vector3.forward) * visual.transform.rotation;
            float measured = Vector3.ProjectOnPlane(front.position - rear.position, Vector3.up).magnitude;
            float scale = VehicleCalibration.UniformScale(measured, profile.WheelbaseMetres);
            visual.transform.localScale *= scale;
            Bounds bothTyres = TyreBounds(visual, "Pneu_");
            visual.transform.position -= new Vector3(rear.position.x, bothTyres.min.y, rear.position.z);
            Vector3 frontCenter = front.position, rearCenter = rear.position;
            float frontRadius = TyreRadius(visual, "Pneu_Dianteiro", frontCenter);
            float rearRadius = TyreRadius(visual, "Pneu_Traseiro", rearCenter);
            if (Mathf.Abs((frontCenter - rearCenter).magnitude - profile.WheelbaseMetres) > .02f)
                throw new InvalidOperationException("A escala aplicada não corresponde ao entre-eixos solicitado.");
            foreach (var renderer in visual.GetComponentsInChildren<Renderer>(true))
            {
                var materials = renderer.sharedMaterials;
                Material paint = PaintMaterialFor(renderer.name);
                for (int i = 0; i < materials.Length; i++)
                    materials[i] = paint != null ? paint : PrepareInspectionProject.PrepareMaterial(materials[i], renderer.name);
                renderer.sharedMaterials = materials;
            }
            AddDrivingSchoolStripes(visual);
            var chassis = root.AddComponent<BoxCollider>();
            chassis.center = new Vector3(0, .61f, profile.WheelbaseMetres * .45f);
            chassis.size = new Vector3(.32f, .58f, profile.WheelbaseMetres * .55f);
            var body = root.AddComponent<Rigidbody>(); body.mass = profile.TotalMassKg;
            body.centerOfMass = new Vector3(0, profile.CenterOfMassHeightMetres, profile.WheelbaseMetres * profile.FrontWeightFraction);
            body.interpolation = RigidbodyInterpolation.Interpolate; body.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
            body.solverIterations = 16; body.solverVelocityIterations = 8; body.maxAngularVelocity = 5;
            var frontWheel = MakeWheel(root, "RodaFisica_Dianteira", frontCenter, frontRadius,
                profile.TotalMassKg * profile.FrontWeightFraction, profile);
            var rearWheel = MakeWheel(root, "RodaFisica_Traseira", rearCenter, rearRadius,
                profile.TotalMassKg * (1 - profile.FrontWeightFraction), profile);
            var controller = root.AddComponent<MotorcycleController>(); controller.Configure(frontWheel, rearWheel, profile);
            var frontVisualRig = root.AddComponent<FrontVisualRig>();
            frontVisualRig.Configure(Find(visual, "CTRL_Direcao_PROVISORIO"),
                Find(visual, "CTRL_Suspensao_Dianteira"), frontWheel, frontCenter);
            root.AddComponent<KeyboardRiderInput>();
            root.AddComponent<WheelPoseBinding>().Configure(frontWheel, front, frontCenter);
            root.AddComponent<WheelPoseBinding>().Configure(rearWheel, rear, rearCenter);
            root.transform.position = Vector3.zero;
            body.ResetInertiaTensor();
            CreateSurface();
            var cameraObject = new GameObject("Camera_Acompanhamento"); cameraObject.tag = "MainCamera";
            var cameraComponent = cameraObject.AddComponent<Camera>(); cameraComponent.fieldOfView = 55; cameraComponent.nearClipPlane = .05f;
            cameraComponent.farClipPlane = 180; cameraComponent.clearFlags = CameraClearFlags.SolidColor;
            cameraComponent.backgroundColor = new Color(.25f, .34f, .45f);
            var rideCamera = cameraObject.AddComponent<RideCamera>(); rideCamera.Configure(root.transform);
            cameraObject.AddComponent<RideTelemetry>().Configure(controller, rideCamera);
            var lightObject = new GameObject("Luz_Solar_Teste"); var light = lightObject.AddComponent<Light>();
            light.type = LightType.Directional; light.intensity = 1.5f; light.shadows = LightShadows.Soft;
            lightObject.transform.rotation = Quaternion.Euler(45, -35, 0);
            RenderSettings.sun = light; RenderSettings.ambientMode = AmbientMode.Trilight;
            RenderSettings.ambientSkyColor = new Color(.55f, .62f, .7f); RenderSettings.ambientEquatorColor = new Color(.3f,.32f,.35f);
            RenderSettings.ambientGroundColor = new Color(.15f,.14f,.13f);
            if (!EditorSceneManager.SaveScene(scene, ScenePath)) throw new IOException("Não foi possível salvar a cena de teste.");
            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
            PrepareInspectionProject.CloseRecoveredScenes(recovered);
            File.WriteAllText(Path.Combine(Root,"ProjectSettings/MotoSimCalibrationReport.json"),
                "{\"wheelbaseMetres\":"+F(profile.WheelbaseMetres)+",\"scaleApplied\":"+F(scale)+
                ",\"frontRadiusMetres\":"+F(frontRadius)+",\"rearRadiusMetres\":"+F(rearRadius)+
                ",\"totalMassKg\":"+F(profile.TotalMassKg)+",\"manufacturerReferenceVerified\":false}");
        }
        private static string F(float value) => value.ToString("R", System.Globalization.CultureInfo.InvariantCulture);
        private static Material PaintMaterialFor(string part)
        {
            if (part == "Object_6" || part == "Paralama_Dianteiro") return PaintMaterial("MotoSim_Amarelo", new Color(1f, .72f, .02f), .28f);
            if (part == "Object_20" || part == "Object_5" || part == "Carenagem_Farol")
                return PaintMaterial("MotoSim_Preto", new Color(.025f, .03f, .04f), .32f);
            return null;
        }
        private static Material PaintMaterial(string name, Color color, float smoothness)
        {
            string path = Generated + "/Materials/" + name + ".mat";
            Material material = AssetDatabase.LoadAssetAtPath<Material>(path);
            if (material != null) return material;
            Shader shader = Shader.Find("Universal Render Pipeline/Lit");
            if (shader == null) throw new InvalidOperationException("Shader URP Lit não encontrado ao criar a pintura.");
            material = new Material(shader) { name = name };
            material.SetColor("_BaseColor", color); material.SetFloat("_Smoothness", smoothness);
            material.SetFloat("_Metallic", .12f); AssetDatabase.CreateAsset(material, path);
            return material;
        }
        private static void AddDrivingSchoolStripes(GameObject visual)
        {
            Transform sidePanel = Find(visual, "Object_20");
            Renderer surface = sidePanel.GetComponent<Renderer>();
            if (surface == null) throw new InvalidOperationException("Não foi possível localizar a lateral principal para a faixa amarela.");
            Bounds bounds = surface.bounds;
            float stripeLength = Mathf.Clamp(bounds.size.z * .43f, .38f, .68f);
            float stripeHeight = Mathf.Clamp(bounds.size.y * .2f, .09f, .15f);
            Material yellow = PaintMaterial("MotoSim_Faixa_Amarela", new Color(1f, .72f, .02f), .22f);
            for (int side = -1; side <= 1; side += 2)
            {
                Vector3 normal = Vector3.right * side;
                Vector3 center = new Vector3(bounds.center.x + normal.x * (bounds.extents.x * .82f + .006f),
                    bounds.center.y + bounds.size.y * .03f,
                    bounds.center.z + bounds.size.z * .17f);
                var stripe = GameObject.CreatePrimitive(PrimitiveType.Quad);
                stripe.name = side > 0 ? "Faixa_Amarela_Direita" : "Faixa_Amarela_Esquerda";
                UnityEngine.Object.DestroyImmediate(stripe.GetComponent<Collider>());
                stripe.transform.SetParent(visual.transform, true);
                stripe.transform.SetPositionAndRotation(center, Quaternion.LookRotation(normal, Vector3.up));
                Vector3 visualScale = visual.transform.lossyScale;
                stripe.transform.localScale = new Vector3(stripeLength / visualScale.x,
                    stripeHeight / visualScale.y, .002f / visualScale.z);
                stripe.GetComponent<Renderer>().sharedMaterial = yellow;

            }
        }
        private static Transform Find(GameObject model, string name)
        {
            var value = model.GetComponentsInChildren<Transform>(true).FirstOrDefault(t=>t.name==name);
            if (value == null) throw new InvalidOperationException("Peça necessária não encontrada: " + name);
            return value;
        }
        private static Bounds TyreBounds(GameObject model, string prefix)
        {
            var values = model.GetComponentsInChildren<Renderer>(true).Where(r=>r.name.StartsWith(prefix,StringComparison.Ordinal)).ToArray();
            if (values.Length==0) throw new InvalidOperationException("Pneus não encontrados: " + prefix);
            Bounds bounds=values[0].bounds; foreach(var value in values) bounds.Encapsulate(value.bounds); return bounds;
        }
        private static float TyreRadius(GameObject model,string prefix,Vector3 center)
        {
            Bounds bounds=TyreBounds(model,prefix);float radius=Mathf.Max(bounds.max.y-center.y,center.y-bounds.min.y);
            if (radius<.15f||radius>.6f) throw new InvalidOperationException("Raio de pneu fora da faixa do teste: "+radius);
            return radius;
        }
        private static WheelCollider MakeWheel(GameObject root,string name,Vector3 center,float radius,float supportedMass,BikePhysicsProfile p)
        {
            var obj=new GameObject(name);obj.transform.SetParent(root.transform,false);
            obj.transform.position=center+Vector3.up*p.SuspensionTravelMetres*.5f;
            var wheel=obj.AddComponent<WheelCollider>();wheel.radius=radius;wheel.mass=8;wheel.sprungMass=supportedMass;
            wheel.suspensionDistance=p.SuspensionTravelMetres;wheel.forceAppPointDistance=.18f;wheel.wheelDampingRate=.15f;
            float k=VehicleCalibration.SpringRate(supportedMass,p.SuspensionFrequencyHz);
            wheel.suspensionSpring=new JointSpring {spring=k,damper=VehicleCalibration.DamperRate(supportedMass,k,p.SuspensionDampingRatio),targetPosition=.5f};
            var forward=wheel.forwardFriction;forward.extremumSlip=.25f;forward.extremumValue=1;forward.asymptoteSlip=.5f;forward.asymptoteValue=.75f;forward.stiffness=1;wheel.forwardFriction=forward;
            var sideways=wheel.sidewaysFriction;sideways.extremumSlip=.2f;sideways.extremumValue=1.1f;sideways.asymptoteSlip=.5f;sideways.asymptoteValue=.8f;sideways.stiffness=1;wheel.sidewaysFriction=sideways;
            // Keep dense contact sampling through the first acceleration range; the
            // old 5 m/s switch dropped from 8 to 4 substeps right around 18 km/h.
            wheel.ConfigureVehicleSubsteps(20,12,8);return wheel;
        }
        private static void CreateSurface()
        {
            const string meshPath=Generated+"/SuperficieTeste.asset", materialPath=Generated+"/Materials/SuperficieTeste.mat";
            Mesh mesh=AssetDatabase.LoadAssetAtPath<Mesh>(meshPath);
            if(mesh==null)
            {
                mesh=new Mesh { name="SuperficieTeste" };
                mesh.vertices=new[]{new Vector3(-30,0,-20),new Vector3(-30,0,100),new Vector3(30,0,100),new Vector3(30,0,-20)};
                mesh.triangles=new[]{0,1,2,0,2,3};mesh.uv=new[]{Vector2.zero,Vector2.up,Vector2.one,Vector2.right};
                mesh.RecalculateNormals();mesh.RecalculateBounds();AssetDatabase.CreateAsset(mesh,meshPath);
            }
            Material material=AssetDatabase.LoadAssetAtPath<Material>(materialPath);
            if(material==null)
            {
                material=new Material(Shader.Find("Universal Render Pipeline/Lit"));material.SetColor("_BaseColor",new Color(.16f,.17f,.18f));
                material.SetFloat("_Smoothness",.08f);AssetDatabase.CreateAsset(material,materialPath);
            }
            var ground=new GameObject("Superficie_De_Validacao");ground.AddComponent<MeshFilter>().sharedMesh=mesh;
            ground.AddComponent<MeshRenderer>().sharedMaterial=material;
            var collider=ground.AddComponent<BoxCollider>();collider.center=new Vector3(0,-.1f,40);collider.size=new Vector3(60,.2f,120);
        }
    }
}
