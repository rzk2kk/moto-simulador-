using UnityEngine;

namespace MotoSim.Unity
{
    /// <summary>Toggleable first- and third-person riding camera.</summary>
    public sealed class RideCamera : MonoBehaviour
    {
        [SerializeField] private Transform target;
        [SerializeField] private Vector3 localEyePosition = new Vector3(0, 1.18f, .43f);
        [SerializeField] private Vector3 localThirdPersonPosition = new Vector3(0, 1.6f, -3.4f);
        [SerializeField] private Vector3 localThirdPersonFocus = new Vector3(0, .75f, .45f);
        [SerializeField] private bool firstPerson = true;
        private Vector3 velocity;

        public bool IsFirstPerson => firstPerson;

        public void Configure(Transform vehicle)
        {
            target = vehicle;
            Position(false);
        }

        public void ToggleView()
        {
            firstPerson = !firstPerson;
            velocity = Vector3.zero;
            Position(false);
        }

        private void LateUpdate() => Position(true);

        private void Update()
        {
#if ENABLE_LEGACY_INPUT_MANAGER
            if (Input.GetKeyDown(KeyCode.V)) ToggleView();
#endif
        }

#if !ENABLE_LEGACY_INPUT_MANAGER
        private void OnGUI()
        {
            Event e = Event.current;
            if (e.type == EventType.KeyDown && e.keyCode == KeyCode.V)
            { ToggleView(); e.Use(); }
        }
#endif

        private void Position(bool smooth)
        {
            if (target == null) return;
            Vector3 desired = target.TransformPoint(firstPerson ? localEyePosition : localThirdPersonPosition);
            Quaternion desiredRotation = firstPerson
                ? target.rotation
                : Quaternion.LookRotation(target.TransformPoint(localThirdPersonFocus) - desired, Vector3.up);
            transform.position = smooth
                ? Vector3.SmoothDamp(transform.position, desired, ref velocity, firstPerson ? .06f : .14f)
                : desired;
            transform.rotation = smooth
                ? Quaternion.Slerp(transform.rotation, desiredRotation, 1 - Mathf.Exp(-8 * Time.deltaTime))
                : desiredRotation;
        }
    }
}
