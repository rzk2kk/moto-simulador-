using UnityEngine;

namespace MotoSim.Unity
{
    public sealed class RideTelemetry : MonoBehaviour
    {
        [SerializeField] private MotorcycleController motorcycle;
        [SerializeField] private RideCamera rideCamera;
        public void Configure(MotorcycleController vehicle, RideCamera camera) { motorcycle = vehicle; rideCamera = camera; }
        private void OnGUI()
        {
            if (motorcycle == null) return;
            var state = motorcycle.Telemetry;
            string gear = state.Gear == 0 ? "N" : state.Gear.ToString();
            GUI.Box(new Rect(12, 12, 560, 180),
                "TESTE FÍSICO — PARÂMETROS PROVISÓRIOS\n" +
                motorcycle.SpeedKph.ToString("0") + " km/h    " + state.EngineRpm.ToString("0") + " RPM    Marcha " + gear +
                "    Limite " + motorcycle.MaximumSpeedKph.ToString("0") + " km/h    Motor " +
                (state.EngineRunning ? "ligado" : "desligado") + "\n" +
                "Contato rodas: frente " + (motorcycle.FrontGrounded ? "SIM" : "NÃO") +
                " | trás " + (motorcycle.RearGrounded ? "SIM" : "NÃO") +
                " | inclinação " + motorcycle.RollDegrees.ToString("0") + "°\n" +
                "RPM roda traseira: " + motorcycle.RearWheelRpm.ToString("0") + " | embreagem " +
                (motorcycle.ClutchLever > .5f ? "acionada" : "solta") + " | freio dianteiro " +
                (motorcycle.FrontBrakeInput > .05f ? "acionado" : "solto") + "\n" +
                "I: ignição | Shift + Q: primeira | W: acelerar\n" +
                "Segure W e solte Shift: liberação gradual assistida.\n" +
                "A/D: direção | Espaço: freio dianteiro | S: traseiro\n" +
                "Shift + E/Q: marchas | Shift + N: neutro | R: recomeçar\n" +
                "Botão direito + arrastar: mover câmera");
            if (rideCamera != null)
            {
                string destination = rideCamera.IsFirstPerson ? "3ª pessoa" : "1ª pessoa";
                if (GUI.Button(new Rect(Screen.width - 210, 12, 198, 42), "Mudar para " + destination))
                    rideCamera.ToggleView();
                GUI.Label(new Rect(Screen.width - 210, 58, 198, 24),
                    "Visão atual: " + (rideCamera.IsFirstPerson ? "1ª pessoa" : "3ª pessoa"));
            }
        }
    }
}
