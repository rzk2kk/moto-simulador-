using UnityEngine;

namespace MotoSim.Unity
{
    /// <summary>Plays the supplied motorcycle cues in response to riding events.</summary>
    public sealed class MotorcycleAudio : MonoBehaviour
    {
        [SerializeField] private MotorcycleController motorcycle;
        [SerializeField, Range(0, 1)] private float engineVolume = .16f;
        [SerializeField, Range(0, 1)] private float starterVolume = .62f;
        [SerializeField, Range(0, 1)] private float accelerationVolume = .72f;
        [SerializeField, Range(0, 1)] private float gearShiftVolume = .78f;
        [SerializeField, Range(0, 1)] private float slowdownVolume = .62f;
        [SerializeField, Range(0, 1)] private float hornVolume = .9f;

        private AudioSource engineSource, starterSource, eventSource, slowdownSource, hornSource;
        private AudioClip starterClip, accelerationClip, gearShiftClip, slowdownClip, hornClip, engineClip;
        private bool ownsStarterClip;
        private bool wasRunning;
        private float previousThrottle, previousSpeed;
        private int previousGear;
        private const int SampleRate = 22050;

        public void Configure(MotorcycleController vehicle) => motorcycle = vehicle;

        private void Awake()
        {
            starterClip = Resources.Load<AudioClip>("MotoSim/Audio/01_partida_moto");
            accelerationClip = Resources.Load<AudioClip>("MotoSim/Audio/03_primeira_aceleracao");
            gearShiftClip = Resources.Load<AudioClip>("MotoSim/Audio/04_troca_de_marcha");
            slowdownClip = Resources.Load<AudioClip>("MotoSim/Audio/05_reducao_de_velocidade");
            hornClip = Resources.Load<AudioClip>("MotoSim/Audio/06_buzina_recortada");
            if (starterClip == null)
            {
                starterClip = CreateStarterClip();
                ownsStarterClip = true;
            }
            engineClip = CreateEngineLoop();
            starterSource = CreateSource("Audio_Partida", starterVolume);
            engineSource = CreateSource("Audio_Motor_Continuo", engineVolume);
            engineSource.clip = engineClip;
            engineSource.loop = true;
            eventSource = CreateSource("Audio_Eventos_Conducao", 1f);
            slowdownSource = CreateSource("Audio_Reducao", 1f);
            hornSource = CreateSource("Audio_Buzina", hornVolume);
        }

        public void PlayHorn()
        {
            if (hornSource == null || hornClip == null) return;
            hornSource.PlayOneShot(hornClip, hornVolume);
        }

        private AudioSource CreateSource(string sourceName, float volume)
        {
            var source = gameObject.AddComponent<AudioSource>();
            source.name = sourceName;
            source.playOnAwake = false;
            source.spatialBlend = 0;
            source.volume = volume;
            return source;
        }

        private void Update()
        {
            if (motorcycle == null) return;
            bool running = motorcycle.Telemetry.EngineRunning;
            float speed = motorcycle.SpeedKph;
            float throttle = motorcycle.ThrottleInput;
            int gear = motorcycle.Telemetry.Gear;

            if (running && !wasRunning)
            {
                starterSource.PlayOneShot(starterClip, starterVolume);
                previousSpeed = speed;
                previousGear = gear;
            }
            if (running)
            {
                if (!engineSource.isPlaying) engineSource.Play();
                float rpm = motorcycle.Telemetry.EngineRpm;
                engineSource.pitch = Mathf.Lerp(.72f, 2.3f, Mathf.Clamp01((rpm - 900) / 8100f));
                engineSource.volume = engineVolume * Mathf.Lerp(.75f, 1.35f, throttle);

                if (wasRunning && gear > 0 && previousGear > 0 && gear != previousGear && gearShiftClip != null)
                    eventSource.PlayOneShot(gearShiftClip, gearShiftVolume);

                if (throttle > .2f && previousThrottle <= .2f && speed < 7f && accelerationClip != null)
                    eventSource.PlayOneShot(accelerationClip, accelerationVolume);

                float decelerationKphPerSecond = (previousSpeed - speed) / Mathf.Max(Time.deltaTime, .001f);
                if (speed > 7f && throttle < .12f && decelerationKphPerSecond > 3.2f &&
                    slowdownClip != null && !slowdownSource.isPlaying)
                    slowdownSource.PlayOneShot(slowdownClip, slowdownVolume);
            }
            else if (engineSource.isPlaying) engineSource.Stop();

            wasRunning = running;
            previousThrottle = throttle;
            previousSpeed = speed;
            previousGear = gear;
        }

        private static AudioClip CreateStarterClip()
        {
            const float duration = .62f;
            int count = Mathf.CeilToInt(SampleRate * duration);
            var samples = new float[count];
            for (int i = 0; i < count; i++)
            {
                float t = (float)i / SampleRate;
                float envelope = t < .48f ? Mathf.Sin(Mathf.PI * Mathf.Clamp01(t / .48f)) :
                    Mathf.Exp(-(t - .48f) * 18f);
                float frequency = Mathf.Lerp(58, 92, Mathf.Clamp01(t / .4f));
                float crank = Mathf.Sin(2 * Mathf.PI * frequency * t) * .58f +
                    Mathf.Sin(2 * Mathf.PI * frequency * 2.03f * t) * .2f;
                float click = Mathf.Exp(-t * 95f) * Mathf.Sin(2 * Mathf.PI * 1300 * t) * .45f;
                float startCatch = Mathf.Exp(-Mathf.Abs(t - .48f) * 42f) * Mathf.Sin(2 * Mathf.PI * 76 * t) * .7f;
                samples[i] = Mathf.Clamp((crank * envelope + click + startCatch) * .7f, -1, 1);
            }
            AudioClip clip = AudioClip.Create("MotoSim_Som_Partida_Reserva", count, 1, SampleRate, false);
            clip.SetData(samples, 0);
            return clip;
        }

        private static AudioClip CreateEngineLoop()
        {
            int count = SampleRate;
            var samples = new float[count];
            const float cyclesPerSecond = 28;
            for (int i = 0; i < count; i++)
            {
                float phase = Mathf.Repeat((float)i / SampleRate * cyclesPerSecond, 1f);
                float angle = phase * 2 * Mathf.PI;
                float pulse = Mathf.Sin(angle) * .42f + Mathf.Sin(angle * 2) * .22f +
                    Mathf.Sin(angle * 3) * .1f + Mathf.Sin(angle * 5) * .055f;
                float rasp = (phase < .12f ? 1f : -.18f) * .11f;
                samples[i] = Mathf.Clamp((pulse + rasp) * .68f, -.8f, .8f);
            }
            AudioClip clip = AudioClip.Create("MotoSim_Som_Motor_Ligado", count, 1, SampleRate, false);
            clip.SetData(samples, 0);
            return clip;
        }

        private void OnDestroy()
        {
            if (ownsStarterClip && starterClip != null) Destroy(starterClip);
            if (engineClip != null) Destroy(engineClip);
        }
    }
}
