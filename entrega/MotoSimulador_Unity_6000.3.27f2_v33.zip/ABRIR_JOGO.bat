@echo off
setlocal
set "MOTOSIM_PROJECT=%~dp0MotoSimulador"
set "MOTOSIM_EDITOR=%ProgramFiles%\Unity\Hub\Editor\6000.3.27f2\Editor\Unity.exe"
set "MOTOSIM_PLAYER=%MOTOSIM_PROJECT%\Build\Windows\MotoSimulador.exe"
set "MOTOSIM_LOG=%MOTOSIM_PROJECT%\Build\primeira_compilacao.log"
if not exist "%MOTOSIM_PROJECT%\MotoSimProject.json" (
 echo Pasta do projeto MotoSimulador nao encontrada ao lado deste arquivo.
 pause
 exit /b 1
)
if exist "%MOTOSIM_PLAYER%" goto launch_game
if not exist "%MOTOSIM_EDITOR%" (
 echo Unity 6000.3.27f2 nao foi encontrada em:
 echo %MOTOSIM_EDITOR%
 echo No Unity Hub, verifique a instalacao do Editor e reabra este arquivo.
 pause
 exit /b 1
)
if not exist "%MOTOSIM_PROJECT%\Build" mkdir "%MOTOSIM_PROJECT%\Build"
echo Primeira compilacao do jogo. Pode levar alguns minutos; a Unity sera executada em segundo plano.
"%MOTOSIM_EDITOR%" -batchmode -quit -projectPath "%MOTOSIM_PROJECT%" -buildTarget Win64 -executeMethod MotoSim.Editor.BuildStandalone.BuildWindows -logFile "%MOTOSIM_LOG%"
set "MOTOSIM_EXIT=%ERRORLEVEL%"
if not exist "%MOTOSIM_PLAYER%" (
 echo Nao foi possivel gerar o jogo. Codigo de saida da Unity: %MOTOSIM_EXIT%
 if exist "%MOTOSIM_LOG%" (
  echo Principais mensagens do log:
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$f='%MOTOSIM_LOG%'; $m=Select-String -Path $f -Pattern 'error CS[0-9]+|Exception:|BuildFailedException|Error building Player|failed to compile' | Select-Object -Last 20; if ($m) { $m | ForEach-Object { $_.Line } } else { Get-Content $f -Tail 30 }"
  start "" notepad.exe "%MOTOSIM_LOG%"
 ) else (
  echo A Unity nao criou o arquivo de log esperado: %MOTOSIM_LOG%
  echo Confirme se o Editor 6000.3.27f2 esta instalado e acessivel.
 )
 echo.
 echo Esta janela ficara aberta. O log foi aberto no Bloco de Notas quando disponivel.
 pause >nul
 exit /b 1
)
:launch_game
start "" "%MOTOSIM_PLAYER%"
