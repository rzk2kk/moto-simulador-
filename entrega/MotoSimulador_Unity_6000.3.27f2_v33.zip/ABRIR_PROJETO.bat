@echo off
setlocal
set "MOTOSIM_PROJECT=%~dp0MotoSimulador"
set "MOTOSIM_EDITOR=%ProgramFiles%\Unity\Hub\Editor\6000.3.27f2\Editor\Unity.exe"
if not exist "%MOTOSIM_EDITOR%" (
 echo Editor Unity 6000.3.27f2 nao encontrado na pasta padrao.
 echo No Unity Hub, adicione a pasta MotoSimulador desta extracao.
 pause
 exit /b 1
)
start "" "%MOTOSIM_EDITOR%" -projectPath "%MOTOSIM_PROJECT%"
