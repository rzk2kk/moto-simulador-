using UnityEngine;

namespace MotoSim.Unity
{
    /// <summary>Animates the clutch and front-brake levers from the actual rider inputs.</summary>
    public sealed class RiderControlVisuals : MonoBehaviour
    {
        [SerializeField] private Transform clutchLever;
        [SerializeField] private Transform frontBrakeLever;
        [SerializeField] private Transform throttlePivot;
        [SerializeField] private Transform ignitionKeyPivot;
        [SerializeField] private Transform rearBrakePedalPivot;
        [SerializeField] private MotorcycleController motorcycle;
        [SerializeField] private float travelDegrees = 14;
        [SerializeField] private float throttleDegrees = 24;
        [SerializeField] private float ignitionDegrees = 32;
        [SerializeField] private float clutchAnimationResponse = 24;
        private Quaternion clutchRest;
        private Quaternion brakeRest;
        private Quaternion throttleRest;
        private Quaternion ignitionRest;
        private Quaternion rearBrakePedalRest;

        public void Configure(Transform clutch, Transform frontBrake, Transform throttle,
            Transform ignitionKey, MotorcycleController vehicle, Transform rearBrakePedal = null)
        {
            clutchLever = clutch;
            frontBrakeLever = frontBrake;
            throttlePivot = throttle;
            ignitionKeyPivot = ignitionKey;
            rearBrakePedalPivot = rearBrakePedal;
            motorcycle = vehicle;
            // Some imported bikes do not include animated rider controls. Keep the
            // controller active and animate only pivots that were actually found.
            clutchRest = clutchLever != null ? clutchLever.localRotation : Quaternion.identity;
            brakeRest = frontBrakeLever != null ? frontBrakeLever.localRotation : Quaternion.identity;
            throttleRest = throttlePivot != null ? throttlePivot.localRotation : Quaternion.identity;
            ignitionRest = ignitionKeyPivot != null ? ignitionKeyPivot.localRotation : Quaternion.identity;
            if (rearBrakePedalPivot != null) rearBrakePedalRest = rearBrakePedalPivot.localRotation;
        }

        private void Awake()
        {
            if (clutchLever != null) clutchRest = clutchLever.localRotation;
            if (frontBrakeLever != null) brakeRest = frontBrakeLever.localRotation;
            if (throttlePivot != null) throttleRest = throttlePivot.localRotation;
            if (ignitionKeyPivot != null) ignitionRest = ignitionKeyPivot.localRotation;
            if (rearBrakePedalPivot != null) rearBrakePedalRest = rearBrakePedalPivot.localRotation;
        }

        private void LateUpdate()
        {
            if (motorcycle == null) return;
            float clutch = motorcycle.ClutchLever;
            float brake = motorcycle.FrontBrakeInput;
            float throttle = motorcycle.ThrottleInput;
            float rearBrake = motorcycle.RearBrakeInput;
            if (clutchLever != null)
                clutchLever.localRotation = Quaternion.Slerp(clutchLever.localRotation,
                    clutchRest * Quaternion.AngleAxis(-travelDegrees * clutch, Vector3.forward),
                    1 - Mathf.Exp(-32 * Time.deltaTime));
            if (frontBrakeLever != null)
                frontBrakeLever.localRotation = brakeRest * Quaternion.AngleAxis(travelDegrees * brake, Vector3.forward);
            if (throttlePivot != null)
                throttlePivot.localRotation = Quaternion.Slerp(throttlePivot.localRotation,
                    throttleRest * Quaternion.AngleAxis(-throttleDegrees * throttle, Vector3.forward),
                    1 - Mathf.Exp(-14 * Time.deltaTime));
            if (ignitionKeyPivot != null)
                ignitionKeyPivot.localRotation = Quaternion.Slerp(ignitionKeyPivot.localRotation,
                    ignitionRest * Quaternion.AngleAxis(motorcycle.Telemetry.EngineRunning ? ignitionDegrees : 0,
                        Vector3.forward), 1 - Mathf.Exp(-10 * Time.deltaTime));
            if (rearBrakePedalPivot != null)
                rearBrakePedalPivot.localRotation = rearBrakePedalRest *
                    Quaternion.AngleAxis(-12f * rearBrake, Vector3.right);
        }
    }
}
