using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace MotoSim.Unity
{
    /// <summary>Simple responsive bike selector for the MotoSim garage and async loading overlay.</summary>
    public sealed class GarageSelectionScreen : MonoBehaviour
    {
        [SerializeField] private GameObject[] displayModels = new GameObject[0];
        [SerializeField] private string[] bikeNames = new string[0];
        [SerializeField] private string[] scenePaths = new string[0];
        [SerializeField] private Texture2D officialLoadingBackground;
        private int selectedIndex;
        private bool loading;
        private float loadProgress;
        private GUIStyle title, heading, body, small, button, card;

        public void Configure(GameObject[] models, string[] names, string[] scenes, Texture2D loadingBackground)
        {
            displayModels = models ?? new GameObject[0];
            bikeNames = names ?? new string[0];
            scenePaths = scenes ?? new string[0];
            officialLoadingBackground = loadingBackground;
            selectedIndex = Mathf.Clamp(PlayerPrefs.GetInt("MotoSim.GarageSelection", 0), 0, Mathf.Max(0, bikeNames.Length - 1));
            ApplySelection();
        }

        private void Start()
        {
            string saved = PlayerPrefs.GetString("MotoSim.SelectedBike", "");
            for (int i = 0; i < bikeNames.Length; i++)
                if (bikeNames[i] == saved) selectedIndex = i;
            ApplySelection();
        }

        private void ApplySelection()
        {
            for (int i = 0; i < displayModels.Length; i++)
                if (displayModels[i] != null) displayModels[i].SetActive(i == selectedIndex);
        }

        private void EnsureStyles()
        {
            if (title != null) return;
            title = new GUIStyle(GUI.skin.label) { fontSize = 27, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleLeft, normal = { textColor = Color.white } };
            heading = new GUIStyle(GUI.skin.label) { fontSize = 18, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleLeft, normal = { textColor = Color.white } };
            body = new GUIStyle(GUI.skin.label) { fontSize = 14, alignment = TextAnchor.MiddleLeft, wordWrap = true, normal = { textColor = new Color(.86f, .87f, .9f) } };
            small = new GUIStyle(body) { fontSize = 11, normal = { textColor = new Color(.68f, .7f, .74f) } };
            button = new GUIStyle(GUI.skin.button) { fontSize = 15, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleCenter };
            card = new GUIStyle(GUI.skin.button) { fontSize = 15, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleLeft, padding = new RectOffset(14, 8, 8, 8) };
        }

        private void OnGUI()
        {
            GUI.matrix = Matrix4x4.identity;
            GUI.color = Color.white;
            GUI.backgroundColor = Color.white;
            EnsureStyles();
            if (loading) { DrawLoading(); GUI.matrix = Matrix4x4.identity; return; }
            float w = Screen.width, h = Screen.height;
            float scale = Mathf.Clamp(Mathf.Min(w / 1440f, h / 900f), .68f, 1.35f);
            GUI.matrix = Matrix4x4.Scale(new Vector3(scale, scale, 1));
            w /= scale; h /= scale;

            Rect top = new Rect(0, 0, w, 82);
            Fill(top, new Color(.025f, .03f, .045f, .92f));
            GUI.Label(new Rect(30, 13, 370, 52), "GARAGEM", title);
            GUI.Label(new Rect(w * .39f, 15, 330, 50), "MOTOSIMULADOR", heading);
            GUI.Label(new Rect(w - 280, 18, 250, 45), "JOGADOR   •   NÍVEL 1", body);

            float leftX = 24, leftW = w * .225f, topY = 118;
            Fill(new Rect(leftX, topY, leftW, h * .70f), new Color(.025f, .03f, .04f, .91f));
            GUI.Label(new Rect(leftX + 16, topY + 12, leftW - 28, 32), "ESCOLHA SUA MOTO", heading);
            string[] types = { "Honda CG 160", "Honda CB 300 Twister", "Honda Africa Twin" };
            int count = Mathf.Min(bikeNames.Length, scenePaths.Length);
            float cardH = Mathf.Min(78, (h * .62f) / Mathf.Max(1, count));
            for (int i = 0; i < count; i++)
            {
                float y = topY + 56 + i * (cardH + 10);
                GUI.backgroundColor = i == selectedIndex ? new Color(.73f, .025f, .035f, 1) : new Color(.12f, .13f, .15f, .96f);
                string displayName = i < types.Length ? types[i] : bikeNames[i];
                if (GUI.Button(new Rect(leftX + 12, y, leftW - 24, cardH), displayName + "\nDISPONÍVEL", card))
                { selectedIndex = i; PlayerPrefs.SetInt("MotoSim.GarageSelection", i); ApplySelection(); }
            }
            GUI.backgroundColor = Color.white;
            GUI.Label(new Rect(leftX + 16, topY + h * .64f, leftW - 32, 34), "A moto selecionada aparece no centro.", small);

            float rightW = w * .225f, rightX = w - rightW - 24;
            Rect info = new Rect(rightX, topY + 48, rightW, h * .55f);
            Fill(info, new Color(.025f, .03f, .04f, .91f));
            string name = selectedIndex < bikeNames.Length ? bikeNames[selectedIndex] : "Moto";
            GUI.Label(new Rect(rightX + 20, info.y + 18, rightW - 40, 50), name, title);
            GUI.Label(new Rect(rightX + 20, info.y + 74, rightW - 40, 36), "HONDA  •  MODELO 3D", body);
            Fill(new Rect(rightX + 18, info.y + 120, rightW - 36, 2), new Color(.75f, .025f, .04f));
            GUI.Label(new Rect(rightX + 20, info.y + 140, rightW - 40, 80), "Modelo incluído no MotoSimulador.\nEscolha Testar para pilotar no circuito.", body);
            GUI.Label(new Rect(rightX + 20, info.y + 233, rightW - 40, 34), "OPÇÃO DE PILOTAGEM", small);
            GUI.Label(new Rect(rightX + 20, info.y + 265, rightW - 40, 40), "Treino de moto", heading);

            float bottomY = h - 92;
            GUI.backgroundColor = new Color(.75f, .025f, .04f, 1);
            if (GUI.Button(new Rect(w * .34f, bottomY, w * .2f, 62), "✓   SELECIONAR", button))
            { SaveSelection(); }
            GUI.backgroundColor = new Color(.08f, .09f, .11f, 1);
            if (GUI.Button(new Rect(w * .56f, bottomY, w * .2f, 62), "TESTAR  →", button))
            { SaveSelection(); StartCoroutine(LoadSelectedScene()); }
            GUI.backgroundColor = Color.white;
            GUI.Label(new Rect(24, h - 31, 300, 24), "MOTOS DISPONÍVEIS: " + count, small);
            GUI.matrix = Matrix4x4.identity;
        }

        private void SaveSelection()
        {
            if (selectedIndex >= 0 && selectedIndex < bikeNames.Length)
                PlayerPrefs.SetString("MotoSim.SelectedBike", bikeNames[selectedIndex]);
            PlayerPrefs.Save();
        }

        private IEnumerator LoadSelectedScene()
        {
            if (selectedIndex < 0 || selectedIndex >= scenePaths.Length) yield break;
            loading = true; loadProgress = 0;
            AsyncOperation operation = SceneManager.LoadSceneAsync(scenePaths[selectedIndex]);
            if (operation == null) { loading = false; yield break; }
            operation.allowSceneActivation = false;
            while (operation.progress < .9f)
            { loadProgress = Mathf.Clamp01(operation.progress / .9f); yield return null; }
            loadProgress = 1; yield return null; operation.allowSceneActivation = true;
        }

        private void DrawLoading()
        {
            EnsureStyles();
            Rect screen = new Rect(0, 0, Screen.width, Screen.height);
            if (officialLoadingBackground != null)
                GUI.DrawTexture(screen, officialLoadingBackground, ScaleMode.ScaleAndCrop, false);
            else Fill(screen, new Color(.035f, .035f, .045f, 1));
            GUIStyle center = new GUIStyle(title)
            { alignment = TextAnchor.MiddleCenter, fontSize = Mathf.Clamp(Screen.height / 28, 20, 34), fontStyle = FontStyle.Bold };
            GUIStyle tip = new GUIStyle(body)
            { alignment = TextAnchor.MiddleLeft, fontSize = Mathf.Clamp(Screen.height / 62, 13, 22), fontStyle = FontStyle.Italic };
            float labelY = Screen.height * .735f;
            GUI.Label(new Rect(0, labelY, Screen.width, Screen.height * .055f), "C A R R E G A N D O . . .", center);
            Rect bar = new Rect(Screen.width * .24f, Screen.height * .805f, Screen.width * .52f, Mathf.Clamp(Screen.height * .037f, 20, 36));
            Fill(bar, new Color(.025f, .025f, .03f, .96f));
            Fill(new Rect(bar.x + 4, bar.y + 4, Mathf.Max(0, (bar.width - 8) * Mathf.Clamp01(loadProgress)), bar.height - 8), new Color(.91f, .025f, .035f));
            Fill(new Rect(bar.x, bar.y, bar.width, 2), new Color(.7f, .7f, .72f, .85f));
            GUI.Label(new Rect(Screen.width * .285f, bar.y + bar.height + 14, Screen.width * .43f, Screen.height * .075f),
                "DICA: MANTENHA O EQUILÍBRIO E A VELOCIDADE CONSTANTE\nNOS PERCURSOS DE PROVA.", tip);
        }

        private static void Fill(Rect rect, Color color)
        {
            Color old = GUI.color; GUI.color = color; GUI.DrawTexture(rect, Texture2D.whiteTexture); GUI.color = old;
        }
    }
}
