using UnityEngine;

namespace MotoSim.Unity
{
    /// <summary>Inspection view only; it does not claim a completed riding camera.</summary>
    [RequireComponent(typeof(Camera))]
    public sealed class ModelInspectionCamera : MonoBehaviour
    {
        [SerializeField] private Vector3 center;
        [SerializeField] private float radius = 10;
        [SerializeField] private float angleDegrees = 35;
        [SerializeField] private float degreesPerSecond = 8;

        public void Configure(Bounds bounds)
        {
            center = bounds.center;
            radius = Mathf.Max(.1f, bounds.extents.magnitude * 3.3f);
            var cameraComponent = GetComponent<Camera>();
            cameraComponent.fieldOfView = 35;
            cameraComponent.nearClipPlane = Mathf.Max(.001f, bounds.size.magnitude / 1000);
            cameraComponent.farClipPlane = radius * 10;
            PositionCamera();
        }
        private void Update()
        {
            angleDegrees += degreesPerSecond * Time.unscaledDeltaTime;
            PositionCamera();
        }
        private void PositionCamera()
        {
            float angle = angleDegrees * Mathf.Deg2Rad;
            transform.position = center + new Vector3(Mathf.Sin(angle) * radius, radius * .35f, Mathf.Cos(angle) * radius);
            transform.LookAt(center, Vector3.up);
        }
        private void OnGUI()
        {
            GUI.Box(new Rect(12, 12, 340, 52), "Modo de inspeção da CG 160\nMontagem física em preparação.");
        }
    }
}
