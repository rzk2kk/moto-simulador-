namespace MotoSim.Core
{
    public readonly struct RiderCommands
    {
        public readonly float Throttle;
        /// <summary>0 = lever released, clutch engaged; 1 = lever pulled, disconnected.</summary>
        public readonly float ClutchLever;
        public readonly float FrontBrake;
        public readonly float RearBrake;
        /// <summary>Single edge/event: -1, 0 or +1; not a continuously held key.</summary>
        public readonly int ShiftDelta;
        /// <summary>Keyboard equivalent of the half-step to neutral between first and second.</summary>
        public readonly bool SelectNeutral;

        public RiderCommands(float throttle, float clutchLever, float frontBrake = 0,
            float rearBrake = 0, int shiftDelta = 0, bool selectNeutral = false)
        {
            Throttle = throttle; ClutchLever = clutchLever; FrontBrake = frontBrake;
            RearBrake = rearBrake; ShiftDelta = shiftDelta; SelectNeutral = selectNeutral;
        }
    }

    public readonly struct DriveOutput
    {
        public readonly float EngineRpm, RearDriveTorqueNm, FrontBrakeTorqueNm, RearBrakeTorqueNm;
        public readonly float Throttle, FuelLitres, ClutchDissipationWatts;
        public readonly int Gear;
        public readonly bool EngineRunning, ShiftRejected, RevLimiterActive;

        internal DriveOutput(float rpm, float torque, float frontBrake, float rearBrake,
            float throttle, float fuel, float clutchHeat, int gear, bool running,
            bool shiftRejected, bool limiter)
        {
            EngineRpm = rpm; RearDriveTorqueNm = torque; FrontBrakeTorqueNm = frontBrake;
            RearBrakeTorqueNm = rearBrake; Throttle = throttle; FuelLitres = fuel;
            ClutchDissipationWatts = clutchHeat; Gear = gear; EngineRunning = running;
            ShiftRejected = shiftRejected; RevLimiterActive = limiter;
        }
    }
}
