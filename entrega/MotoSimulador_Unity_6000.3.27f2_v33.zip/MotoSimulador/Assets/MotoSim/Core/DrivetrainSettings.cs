using System;

namespace MotoSim.Core
{
    /// <summary>Initial simulator tuning in SI units, NOT certified CG 160 specifications.</summary>
    [Serializable]
    public sealed class DrivetrainSettings
    {
        public float IdleRpm = 1500;
        public float StallRpm = 600;
        public float RedlineRpm = 9000;
        public float PeakTorqueRpm = 6500;
        public float PeakTorqueNm = 15;
        public float EngineInertiaKgM2 = 0.12f;
        public float EngineFrictionNm = 1.5f;
        public float EngineViscousDrag = 0.004f;
        public float ClosedThrottlePumpingDrag = 0.01f;
        public float IdleControlGain = 0.2f;
        public float MaxIdleTorqueNm = 10;
        public float ClutchCapacityNm = 30;
        public float ClutchSlipGain = 0.8f;
        public float ShiftClutchThreshold = 0.7f;
        public float PrimaryRatio = 3;
        public float FinalRatio = 3;
        public float[] GearRatios = { 2.7f, 1.8f, 1.35f, 1.1f, 0.95f };
        public float TransmissionEfficiency = 0.95f;
        public float MaxFrontBrakeNm = 230;
        public float MaxRearBrakeNm = 130;
        public float ThrottleRisePerSecond = 3;
        public float ThrottleFallPerSecond = 6;
        public float FuelCapacityLitres = 10;
        public float IdleFuelLitresPerHour = 0.4f;
        public float ExtraFuelLitresPerHourAtFullThrottle = 2;

        internal DrivetrainSettings CopyValidated()
        {
            var result = (DrivetrainSettings)MemberwiseClone();
            result.GearRatios = GearRatios == null ? null : (float[])GearRatios.Clone();
            result.Validate();
            return result;
        }

        public void Validate()
        {
            Positive(IdleRpm, nameof(IdleRpm)); Positive(StallRpm, nameof(StallRpm));
            Positive(RedlineRpm, nameof(RedlineRpm)); Positive(PeakTorqueRpm, nameof(PeakTorqueRpm));
            Positive(PeakTorqueNm, nameof(PeakTorqueNm)); Positive(EngineInertiaKgM2, nameof(EngineInertiaKgM2));
            Positive(EngineFrictionNm, nameof(EngineFrictionNm)); Positive(EngineViscousDrag, nameof(EngineViscousDrag));
            Nonnegative(ClosedThrottlePumpingDrag, nameof(ClosedThrottlePumpingDrag));
            Positive(IdleControlGain, nameof(IdleControlGain)); Positive(MaxIdleTorqueNm, nameof(MaxIdleTorqueNm));
            Positive(ClutchCapacityNm, nameof(ClutchCapacityNm)); Positive(ClutchSlipGain, nameof(ClutchSlipGain));
            Positive(PrimaryRatio, nameof(PrimaryRatio)); Positive(FinalRatio, nameof(FinalRatio));
            Positive(MaxFrontBrakeNm, nameof(MaxFrontBrakeNm)); Positive(MaxRearBrakeNm, nameof(MaxRearBrakeNm));
            Positive(ThrottleRisePerSecond, nameof(ThrottleRisePerSecond)); Positive(ThrottleFallPerSecond, nameof(ThrottleFallPerSecond));
            Positive(FuelCapacityLitres, nameof(FuelCapacityLitres)); Positive(IdleFuelLitresPerHour, nameof(IdleFuelLitresPerHour));
            Nonnegative(ExtraFuelLitresPerHourAtFullThrottle, nameof(ExtraFuelLitresPerHourAtFullThrottle));
            if (!(StallRpm < IdleRpm && IdleRpm < PeakTorqueRpm && PeakTorqueRpm < RedlineRpm))
                throw new ArgumentException("Require stall < idle < peak torque < redline RPM.");
            if (!Finite(TransmissionEfficiency) || TransmissionEfficiency <= 0 || TransmissionEfficiency > 1)
                throw new ArgumentOutOfRangeException(nameof(TransmissionEfficiency));
            if (!Finite(ShiftClutchThreshold) || ShiftClutchThreshold <= 0 || ShiftClutchThreshold > 1)
                throw new ArgumentOutOfRangeException(nameof(ShiftClutchThreshold));
            if (GearRatios == null || GearRatios.Length == 0 || GearRatios.Length > 12)
                throw new ArgumentException("Provide 1–12 forward gear ratios.");
            float largestRatio = 0;
            foreach (float ratio in GearRatios) { Positive(ratio, nameof(GearRatios)); largestRatio = Math.Max(largestRatio, ratio); }
            if (!Finite(PrimaryRatio * FinalRatio * largestRatio))
                throw new ArgumentException("Total gear ratio must be finite.");
        }

        internal static bool Finite(float value) => !float.IsNaN(value) && !float.IsInfinity(value);
        private static void Positive(float value, string name)
        { if (!Finite(value) || value <= 0) throw new ArgumentOutOfRangeException(name); }
        private static void Nonnegative(float value, string name)
        { if (!Finite(value) || value < 0) throw new ArgumentOutOfRangeException(name); }
    }
}
