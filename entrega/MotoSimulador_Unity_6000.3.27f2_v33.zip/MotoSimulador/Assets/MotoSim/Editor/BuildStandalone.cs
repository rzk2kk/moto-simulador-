using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace MotoSim.Editor
{
    /// <summary>Builds and launches the Windows game from the installed Unity Editor.</summary>
    public static class BuildStandalone
    {
        private static string ProjectRoot => Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
        private static string OutputDirectory => Path.Combine(ProjectRoot, "Build", "Windows");
        private static string OutputPlayer => Path.Combine(OutputDirectory, "MotoSimulador.exe");

        public static void BuildWindows()
        {
            try
            {
                // Generate the garage hub and all motorcycle scenes before building the player.
                PrepareGarageProject.RunSetup();
                AssetDatabase.Refresh();
                AssetDatabase.SaveAssets();

                string[] scenes = EditorBuildSettings.scenes
                    .Where(scene => scene.enabled)
                    .Select(scene => scene.path)
                    .ToArray();
                if (!scenes.Contains(PrepareGarageProject.ScenePath))
                    throw new InvalidOperationException("A cena da garagem não foi criada: " + PrepareGarageProject.ScenePath);
                if (!scenes.Contains(PrepareRidingProject.ScenePath) ||
                    !scenes.Contains(PrepareCB300Project.ScenePath) ||
                    !scenes.Contains(PrepareAfricaTwinProject.ScenePath))
                    throw new InvalidOperationException("As cenas das três motos não foram registradas para a compilação.");
                foreach (string scene in scenes)
                    if (AssetDatabase.LoadAssetAtPath<SceneAsset>(scene) == null)
                        throw new InvalidOperationException("Cena da garagem ou de uma moto ausente: " + scene);

                Directory.CreateDirectory(OutputDirectory);
                var options = new BuildPlayerOptions
                {
                    scenes = scenes,
                    locationPathName = OutputPlayer,
                    target = BuildTarget.StandaloneWindows64,
                    options = BuildOptions.None
                };
                BuildReport report = BuildPipeline.BuildPlayer(options);
                if (report.summary.result != BuildResult.Succeeded)
                    throw new InvalidOperationException("A compilação do jogo falhou: " + report.summary.result +
                        ". Veja o Console da Unity para o erro detalhado.");

                Debug.Log("MotoSim: jogo Windows criado em " + OutputPlayer);
                EditorApplication.Exit(0);
            }
            catch (Exception error)
            {
                Debug.LogException(error);
                try { File.WriteAllText(Path.Combine(ProjectRoot, "Build", "ERRO_AO_GERAR_JOGO.txt"), error.ToString()); }
                catch { /* Unity writes the same details to its batch log. */ }
                EditorApplication.Exit(1);
            }
        }
    }
}
