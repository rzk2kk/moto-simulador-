using System;
using System.IO;
using MotoSim.Unity;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace MotoSim.Editor
{
    /// <summary>Generates the garage hub and registers each available motorcycle scene.</summary>
    public static class PrepareGarageProject
    {
        internal const string ScenePath = "Assets/MotoSim/Generated/Garagem_Motos.unity";
        private const string Generated = "Assets/MotoSim/Generated";
        private const string ModelPath = "Assets/MotoSim/Art/";
        private const string SessionKey = "MotoSim.GarageSetupAttempted";
        private static string Root => Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
        private static string Completion => Path.Combine(Root, "ProjectSettings", "MotoSimGarageSetup.json");

        internal static void TryAutomaticSetup()
        {
            if (File.Exists(Completion) && AssetDatabase.LoadAssetAtPath<SceneAsset>(ScenePath) != null)
            {
                Scene active = SceneManager.GetActiveScene();
                if (active.IsValid() && !active.isDirty && string.IsNullOrEmpty(active.path)) RunSetup();
                return;
            }
            if (SessionState.GetBool(SessionKey, false)) return;
            SessionState.SetBool(SessionKey, true);
            RunSetup();
        }

        [MenuItem("MotoSim/Abrir Garagem")]
        public static void RunSetup()
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode || EditorApplication.isCompiling || EditorApplication.isUpdating)
            { EditorApplication.delayCall += RunSetup; return; }
            try
            {
                PrepareInspectionProject.EnsureFolder("Assets/MotoSim", "Generated");
                PrepareInspectionProject.ConfigurePipeline();
                PrepareInspectionProject.EnsureFolder(Generated, "Materials");

                EnsureScene(PrepareRidingProject.ScenePath, PrepareRidingProject.RunSetup);
                EnsureScene(PrepareCB300Project.ScenePath, PrepareCB300Project.RunSetup);
                EnsureScene(PrepareAfricaTwinProject.ScenePath, PrepareAfricaTwinProject.RunSetup);
                if (AssetDatabase.LoadAssetAtPath<SceneAsset>(ScenePath) == null) CreateScene();
                else PrepareInspectionProject.OpenPreparedScene(ScenePath);

                EditorBuildSettings.scenes = new[] {
                    new EditorBuildSettingsScene(ScenePath, true),
                    new EditorBuildSettingsScene(PrepareRidingProject.ScenePath, true),
                    new EditorBuildSettingsScene(PrepareCB300Project.ScenePath, true),
                    new EditorBuildSettingsScene(PrepareAfricaTwinProject.ScenePath, true)
                };
                AssetDatabase.SaveAssets();
                File.WriteAllText(Completion, "{\"scenePrepared\":true,\"motorcycles\":3}");
                Debug.Log("MotoSim: garagem pronta com CG 160, CB 300 Twister e Africa Twin.");
            }
            catch (Exception error)
            {
                Debug.LogException(error);
                File.WriteAllText(Path.Combine(Root, "MotoSim_Garage_Setup_Error.txt"), error.ToString());
                if (!Application.isBatchMode)
                    EditorUtility.DisplayDialog("MotoSim — Garagem", error.Message, "OK");
            }
        }

        private static void EnsureScene(string path, Action build)
        {
            if (AssetDatabase.LoadAssetAtPath<SceneAsset>(path) != null) return;
            build();
            // Individual scene builders open their result. Save this completed scene before the
            // next builder changes the active scene, so the garage can be created afterwards.
            Scene built = SceneManager.GetSceneByPath(path);
            if (built.IsValid() && built.isLoaded) EditorSceneManager.SaveScene(built, path);
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            if (AssetDatabase.LoadAssetAtPath<SceneAsset>(path) == null)
                throw new InvalidOperationException("A preparação não gerou a cena necessária para a garagem: " + path);
        }

        private static void CreateScene()
        {
            var recovered = PrepareInspectionProject.PreserveUnnamedScenes();
            Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Additive);
            SceneManager.SetActiveScene(scene);
            Material black = MakeMaterial("Garage_Black", new Color(.035f, .04f, .05f));
            Material floor = MakeMaterial("Garage_Floor", new Color(.12f, .13f, .14f));
            Material yellow = MakeMaterial("Garage_Yellow", new Color(1f, .55f, .015f));
            Material red = MakeMaterial("Garage_Red", new Color(.68f, .018f, .025f));
            Material gray = MakeMaterial("Garage_Wall", new Color(.28f, .29f, .3f));
            Material tool = MakeMaterial("Garage_Toolbox", new Color(.72f, .025f, .035f));

            Cube("Piso_Garagem", new Vector3(0, -.12f, 0), new Vector3(18, .2f, 15), floor);
            Cube("Parede_Fundo", new Vector3(0, 3.5f, 7), new Vector3(18, 7, .3f), gray);
            Cube("Faixa_Amarela", new Vector3(0, 2.35f, 6.78f), new Vector3(18, .42f, .12f), yellow);
            Cube("Faixa_Vermelha", new Vector3(0, 2.05f, 6.77f), new Vector3(18, .1f, .12f), red);
            Cube("Parede_Esquerda", new Vector3(-9, 3.5f, 0), new Vector3(.3f, 7, 14), black);
            Cube("Parede_Direita", new Vector3(9, 3.5f, 0), new Vector3(.3f, 7, 14), black);
            Cube("Fundo_Escuro", new Vector3(0, 5.8f, 6.78f), new Vector3(18, 2.4f, .1f), black);

            Cube("Bancada", new Vector3(-5, 1.2f, 5.8f), new Vector3(5.4f, .18f, 1.1f), MakeMaterial("Bancada_Madeira", new Color(.34f, .2f, .1f)));
            Cube("Armario_Ferramentas", new Vector3(2.8f, 1.15f, 6), new Vector3(2.2f, 2.25f, .8f), tool);
            for (int i = 0; i < 4; i++) Cube("Gaveta_" + i, new Vector3(2.8f, .38f + i * .42f, 5.55f), new Vector3(1.95f, .3f, .05f), gray);
            Cube("Prateleira", new Vector3(-5.2f, 3.4f, 6), new Vector3(5f, .14f, .8f), black);
            Cube("Area_Amarela", new Vector3(0, -.005f, 0), new Vector3(7.2f, .02f, 5f), yellow);
            Cube("Area_Centro", new Vector3(0, .012f, 0), new Vector3(6.92f, .02f, 4.72f), black);

            var stage = new GameObject("Suporte_Modelos");
            GameObject[] models = {
                InstantiateBike("CG160", ModelPath + "CG160_neutra_unidades_originais.fbx", stage.transform, 0),
                InstantiateBike("CB300_Twister", ModelPath + "CB300_Twister_MotoSim.fbx", stage.transform, 1),
                InstantiateBike("Honda_Africa_Twin", ModelPath + "Honda_Africa_Twin_MotoSim.fbx", stage.transform, 2)
            };
            var screen = new GameObject("Interface_Garagem").AddComponent<GarageSelectionScreen>();
            screen.Configure(models,
                new[] { "Honda CG 160", "Honda CB 300 Twister", "Honda Africa Twin" },
                new[] { PrepareRidingProject.ScenePath, PrepareCB300Project.ScenePath, PrepareAfricaTwinProject.ScenePath },
                AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/MotoSim/Art/Textures/Tela_Carregamento.png"));

            var camGo = new GameObject("Camera_Garagem"); camGo.tag = "MainCamera";
            var cam = camGo.AddComponent<Camera>(); cam.clearFlags = CameraClearFlags.SolidColor; cam.backgroundColor = new Color(.035f, .04f, .05f);
            cam.fieldOfView = 48; cam.nearClipPlane = .1f; cam.farClipPlane = 100;
            camGo.transform.position = new Vector3(0, 2.3f, -10.6f); camGo.transform.LookAt(new Vector3(0, 1.05f, 0));
            camGo.AddComponent<AudioListener>();
            var sunGo = new GameObject("Luz_Garagem"); var sun = sunGo.AddComponent<Light>(); sun.type = LightType.Directional; sun.intensity = 1.2f; sun.shadows = LightShadows.Soft;
            sunGo.transform.rotation = Quaternion.Euler(48, -28, 0); RenderSettings.sun = sun;
            RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Trilight;
            RenderSettings.ambientSkyColor = new Color(.35f,.37f,.4f); RenderSettings.ambientEquatorColor = new Color(.2f,.2f,.22f); RenderSettings.ambientGroundColor = new Color(.08f,.08f,.09f);

            if (!EditorSceneManager.SaveScene(scene, ScenePath)) throw new IOException("Não foi possível salvar a garagem.");
            PrepareInspectionProject.CloseRecoveredScenes(recovered);
        }

        private static GameObject InstantiateBike(string name, string path, Transform parent, int index)
        {
            GameObject prefab = AssetDatabase.LoadAssetAtPath<GameObject>(path);
            if (prefab == null) throw new InvalidOperationException("Modelo da garagem ausente: " + path);
            var instance = PrefabUtility.InstantiatePrefab(prefab) as GameObject;
            if (instance == null) throw new InvalidOperationException("Não foi possível abrir o modelo: " + path);
            instance.name = "Exibicao_" + name; instance.transform.SetParent(parent, true);
            Bounds bounds = BoundsOf(instance);
            float scale = 1.55f / Mathf.Max(.01f, bounds.size.y);
            instance.transform.localScale *= scale;
            bounds = BoundsOf(instance);
            instance.transform.position += new Vector3(-bounds.center.x, -bounds.min.y, -bounds.center.z);
            instance.transform.position += Vector3.forward * (index * .01f);
            instance.SetActive(index == 0);
            return instance;
        }

        private static Bounds BoundsOf(GameObject root)
        {
            Renderer[] renderers = root.GetComponentsInChildren<Renderer>(true);
            if (renderers.Length == 0) throw new InvalidOperationException("Modelo sem malhas renderizáveis: " + root.name);
            Bounds b = renderers[0].bounds; foreach (Renderer r in renderers) b.Encapsulate(r.bounds); return b;
        }

        private static Material MakeMaterial(string name, Color color)
        {
            string path = Generated + "/Materials/" + name + ".mat";
            Material material = AssetDatabase.LoadAssetAtPath<Material>(path);
            if (material == null)
            {
                Shader shader = Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Standard");
                material = new Material(shader); AssetDatabase.CreateAsset(material, path);
            }
            if (material.HasProperty("_BaseColor")) material.SetColor("_BaseColor", color);
            if (material.HasProperty("_Color")) material.SetColor("_Color", color);
            return material;
        }

        private static void Cube(string name, Vector3 position, Vector3 size, Material material)
        {
            var cube = GameObject.CreatePrimitive(PrimitiveType.Cube); cube.name = name;
            cube.transform.position = position; cube.transform.localScale = size;
            cube.GetComponent<Renderer>().sharedMaterial = material;
            if (name == "Area_Centro") UnityEngine.Object.DestroyImmediate(cube.GetComponent<Collider>());
        }
    }
}
