# Versão 3 — primeiro teste físico

A cena CG160_TesteFisico é criada automaticamente ao abrir o pacote v3. A inspeção anterior continua disponível no menu MotoSim. Esta é uma versão inicial para validar contato, estabilidade e comandos; não é uma simulação completa ou calibrada da Honda.

## Dados provisórios
PhysicsCalibration.json marca ReferenceVerified=false. A referência de entre-eixos é 1,315 m, a massa estimada da moto 115 kg e a massa de piloto 75 kg, totalizando 190 kg. Esses números NÃO foram confirmados para o ano/variante do modelo enviado. O perfil é ajustável e precisa de uma referência oficial ou medição real antes de qualquer afirmação de fidelidade.

O código mede a separação dos pivôs do FBX importado, aplica uma única escala uniforme até o entre-eixos configurado, alinha a frente com +Z e posiciona a base dos pneus no plano do chão. Raios são calculados a partir dos limites geométricos dos pneus identificados. Esses cálculos precisam ser conferidos no importador real; não são medições de uma moto real.

A raiz física fica com escala (1,1,1), e somente o modelo visual recebe a escala. O BoxCollider do chassi é invisível; a moto visível continua sendo o modelo original. Não se usa a malha visual de 141 mil triângulos como colisor dinâmico.

## Física e comandos preparados
Rigidbody com massa total e centro de massa iniciais; dois WheelColliders com massa apoiada, suspensão por frequência/amortecimento e curvas de atrito provisórias. O acelerador, a embreagem, as marchas e os freios recebem valores do núcleo C# e alimentam os colliders. Existe assistência de equilíbrio/inclinação, resistência de rolagem e arrasto aerodinâmico iniciais. Não há modelo completo de giroscópio, piloto, deformação de pneu ou simulação multicorpos.

A direção é limitada conforme velocidade, entre-eixos e inclinação máxima. O motor inclui perdas adicionais ao fechar o acelerador, separadas do atrito viscoso em carga; isso mantém desaceleração e freio-motor sem consumir quase todo o torque em alta.

O teclado tem embreagem gradual: puxar é rápido, e soltar libera o acoplamento em aproximadamente 1,67 s. Trocas solicitadas com a tecla de embreagem segurada aguardam o movimento da alavanca. O motor ainda pode morrer; R restaura a posição inicial e reinicia o estado da transmissão.

I liga/desliga. Shift + Q seleciona a primeira a partir de N. W acelera; solte Shift para sair. A/D dirigem; Espaço é freio dianteiro; S é traseiro. Shift + E/Q troca marchas; Shift + N seleciona neutro a partir de 1 ou 2. R recomeça. Clique na janela Game para que ela receba teclado.

O adaptador usa Input Manager quando disponível e eventos de teclado IMGUI como alternativa, evitando exigir que o usuário instale um pacote de entrada adicional.

## Visualização e limitações
A câmera acompanha a moto, e o HUD mostra velocidade de movimento, RPM, marcha e estado real do núcleo. As poses das rodas são vinculadas aos WheelColliders, preservando o alinhamento inicial da geometria. A superfície simples existe só para validação; não é o mapa de autoescola ou o asfalto final.

Guidão, garfo, amortecedores, manetes, corrente, chave, luzes, painel original e áudio ainda precisam de ligações completas dentro da Unity. As demonstrações do Blender não foram transferidas como mecanismos funcionais para o jogo. A suspensão tem ação física nos colliders, mas sua animação visual completa no modelo ainda está pendente. Não há piloto 3D ou câmeras de primeira pessoa nesta entrega.

## Evidência de validação
30 cenários de C# puro aprovados, incluindo a saída com liberação progressiva da embreagem em uma carga inercial externa, conservação de massa, resposta de mola/amortecedor e limite de esterçamento. Isso não executa PhysX ou os scripts do Editor Unity.

A sintaxe C# dos arquivos foi conferida. A presença dos pivôs e dos nomes dos pneus foi comparada com o manifesto do FBX validado. O pacote foi conferido por ZIP/SHA-256. A abertura, a compilação Unity, o comportamento de contato no chão, a frenagem e a estabilidade ainda precisam ser testados no PC do usuário.

Ao gerar a cena no PC, o relatório ProjectSettings/MotoSimCalibrationReport.json registra a escala aplicada, os raios medidos, o entre-eixos solicitado e a massa. Continua marcando manufacturerReferenceVerified=false.
