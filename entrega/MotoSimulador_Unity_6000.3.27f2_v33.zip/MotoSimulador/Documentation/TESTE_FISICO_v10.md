# Versão 10 — câmera orbital, manetes e estabilidade

A cena `CG160_TesteFisico_v10` remove as faixas adesivas amarelas e mantém a pintura demonstrativa preto/amarelo e o limite da pista em 50 km/h.

Segure o botão direito do mouse e arraste para mover a câmera. Em primeira pessoa, isso gira o olhar do piloto. Em terceira pessoa, a câmera orbita ao redor da moto. O botão no HUD e a tecla `V` continuam alternando a perspectiva.

O manete esquerdo acompanha a embreagem (Shift); o manete direito acompanha o freio dianteiro (Espaço). Os espelhos são afastados simetricamente para junto das extremidades do guidão e as hastes acompanham esse deslocamento.

Para investigar o salto/afundamento relatado perto de 20 km/h, a cena usa o mesmo número de subpassos até essa faixa, limita o torque da roda traseira pela carga estática estimada, reduz o ponto de aplicação das forças, amortece a suspensão e mantém a assistência de rolagem ativa durante perda de contato. O HUD apresenta contato das rodas, inclinação e RPM da roda traseira.

Estes são ajustes provisórios revisados por sintaxe; não foram executados no Unity/PhysX nesta nuvem. Teste em terceira pessoa, acelere em linha reta e confira contato, inclinação e RPM se a moto ainda afundar ou oscilar.
