# Correção v2 — criação da cena de inspeção

Erro observado no PC do usuário: `InvalidOperationException: Cannot create a new scene additively with an untitled scene unsaved.`

Causa confirmada: a inicialização chamava EditorSceneManager.NewScene no modo Additive com uma cena Untitled sem caminho salvo, inclusive quando vazia.

A revisão salva todas as cenas sem nome em caminhos únicos de Assets/MotoSim/Generated/Recuperadas antes de criar ou abrir outra cena de forma adicional. Se salvar falhar, a preparação é interrompida. Depois de salvar a inspeção com sucesso, fecha somente as cenas recuperadas que continuam sem novas alterações; os arquivos recuperados ficam no projeto.

Também foi corrigida a retomada: existir um marcador de conclusão não garante que a Unity tenha aberto a cena gerada. A preparação agora restaura a inspeção ao abrir uma cena vazia e impede iniciar Play vazio sem antes tentar concluir a montagem. Erros são mostrados em uma janela, além do Console, para não desaparecerem com Clear on Play.

Verificações locais: sintaxe dos 8 arquivos C# aprovada; integridade e conteúdo do ZIP conferidos. Os 23 cenários do núcleo permanecem aprovados e não testam APIs de gerenciamento de cena. Não há Editor Unity nesta máquina para executar essa regressão: a nova abertura no Editor do usuário ainda precisa ser validada.
