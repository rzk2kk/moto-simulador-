# Versão 11 — sentido de avanço, retrovisores e garfo

A versão 11 corrige três problemas relatados no teste local:

- O torque e a leitura de RPM da roda traseira agora consideram a orientação do eixo físico da roda em relação ao avanço da moto.
- Os retrovisores voltam a ficar perto das manoplas e simétricos, sem deslocamento extra para fora do guidão.
- O garfo e o paralama dianteiro passam a se deslocar no eixo real da suspensão, com suavização curta para reduzir tremulação visual.

Os ajustes continuam provisórios e precisam ser conferidos na Unity local. Teste primeiro acelerar em linha reta e observe se a moto segue para frente; depois veja se o paralama acompanha o curso do garfo sem saltos e se os espelhos permanecem unidos às hastes ao virar o guidão.
