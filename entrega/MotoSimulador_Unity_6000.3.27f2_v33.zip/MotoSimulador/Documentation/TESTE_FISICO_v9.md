# Versão 9 — alternância de câmera

A cena `CG160_TesteFisico_v9` preserva a faixa amarela sem texto e o limite de 50 km/h.

No canto superior direito do HUD, o botão alterna entre `1ª pessoa` e `3ª pessoa`. A tecla `V` faz a mesma troca. A visão em terceira pessoa acompanha a moto por trás e acima, para mostrar as rodas e o contato com a pista; o HUD continua mostrando contato dianteiro/traseiro, velocidade, RPM e marcha.

Esta alteração de câmera foi revisada por sintaxe, mas não executada no Editor Unity nesta nuvem. A alternância e a visibilidade das rodas devem ser conferidas em Play no PC.
