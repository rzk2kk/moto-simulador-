# Versão 12 — avanço e remoção dos retrovisores

O teste local da versão 11 continuou movendo a moto para trás. Nesta versão, o sinal do torque aplicado à roda traseira foi invertido em relação à saída positiva da transmissão, para que a primeira marcha mova a moto na direção do eixo dianteiro. O painel exibe `Sentido FRENTE/RÉ` calculado pela velocidade do corpo da moto.

Os retrovisores e suas hastes foram ocultados na cena de teste. Guidão, manetes e comandos permanecem. O ajuste visual do curso do garfo e do paralama da versão 11 foi mantido.

O sinal do WheelCollider ainda precisa de confirmação no Play do Unity local. Primeiro teste com a moto parada: ligue, selecione a primeira marcha e acelere levemente. A indicação no HUD deve mudar para `FRENTE`.
