# Versão 13 — sentido visual dos manetes

Os controles continuam iguais: Shift aciona a embreagem e Espaço aciona o freio dianteiro. A rotação visual dos dois manetes foi invertida para que, ao acionar, eles se movam no sentido de apertar junto à manopla; ao soltar, retornam à posição de descanso.

Esta alteração foi revisada por sintaxe, mas precisa ser confirmada visualmente no Play da Unity local.
