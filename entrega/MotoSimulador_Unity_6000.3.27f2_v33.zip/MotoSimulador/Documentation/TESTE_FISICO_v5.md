# Versão 5 — contato de roda em velocidade

A cena `CG160_TesteFisico_v5` é criada automaticamente ao abrir a versão 5. Ela mantém as correções de equilíbrio, câmera de primeira pessoa e articulação visual da frente da versão 4.

## Alterações

- Os WheelColliders mantêm 12 subpassos até 20 m/s (72 km/h) e 8 acima dessa velocidade. Antes, aos 5 m/s (18 km/h), a simulação reduzia de 8 para 4 subpassos; isso podia provocar salto no contato da roda durante a aceleração.
- O Rigidbody usa 16 iterações de contato e 8 de velocidade.
- Direção e inclinação usam a velocidade horizontal da moto. Uma queda ou salto vertical deixa de ser interpretado como aumento da velocidade de deslocamento.
- O HUD mostra se cada roda está tocando o chão, além da velocidade, rotação do motor, marcha e estado da ignição.

Os controles não mudaram. Se a velocidade parar de subir, confira no HUD se o motor está ligado, qual marcha está selecionada e se a roda traseira indica contato com o chão. O teste de núcleo e a checagem de sintaxe não executam Unity/PhysX; a nova cena ainda precisa ser conferida em Play.
