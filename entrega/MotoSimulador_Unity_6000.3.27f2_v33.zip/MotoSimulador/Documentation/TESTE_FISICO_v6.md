# Versão 6 — pintura preto e amarelo com faixas AUTOESCOLA

A cena `CG160_TesteFisico_v6` é criada automaticamente ao abrir o pacote. Ela mantém as melhorias de equilíbrio e contato das rodas da versão 5, com câmera de primeira pessoa.

## Pintura

As carenagens principais e o conjunto do farol recebem preto acetinado; o paralama dianteiro e as laterais recebem amarelo. Duas faixas amarelas com “AUTOESCOLA” em preto são posicionadas nos lados do corpo principal. As rodas, pneus, banco, motor, corrente e peças metálicas mantêm acabamento escuro ou metálico.

As faixas são placas visuais finas com texto 3D, adicionadas à cena e sem colisores. O modelo FBX original permanece preservado. A posição e o tamanho das faixas são estimativas feitas com base nas dimensões do modelo, ainda precisam de conferência visual na Unity.

## Controles e validação

`I` liga o motor; segure `Shift` e aperte `Q` para a primeira marcha; `W` acelera e soltar `Shift` libera a embreagem. `A/D` esterçam, `Espaço` freia na frente, `S` freia atrás e `R` reinicia.

Os testes C# verificam o núcleo da transmissão e cálculos; não executam o Editor/PhysX nem renderizam a pintura. A cena precisa ser aberta no Editor Unity do PC para confirmar cores, posicionamento das faixas e pilotagem.
