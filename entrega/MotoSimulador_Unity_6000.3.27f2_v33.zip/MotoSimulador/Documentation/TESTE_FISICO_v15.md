# Versão 15 — acabamento, iluminação e áudio

- Liberação da embreagem mais rápida; animação visual da manopla do acelerador invertida para girar no sentido esperado.
- Lentes de farol, setas e lanterna com material translúcido em branco, âmbar e vermelho. Emissão ampliada; lanterna vermelha fica mais intensa ao frear.
- Motor e peças do escapamento/suspensão em cinza metálico, molas traseiras douradas, manetes prateados, borracha preta, chave dourada, cabos em aço e símbolos do painel ciano.
- Movimento visível do garfo/paralama mais suave e reduzido para evitar oscilações aparentes.
- Som procedural de partida e um loop simples de motor. A partida toca quando o motor realmente liga; o loop só permanece enquanto o motor está ligado. Não usa gravações externas.

O HUD do jogo não foi alterado nesta versão; a imagem da proposta foi apresentada para revisão. Materiais, iluminação, áudio e suspensão visual precisam de teste no Play da Unity local.
