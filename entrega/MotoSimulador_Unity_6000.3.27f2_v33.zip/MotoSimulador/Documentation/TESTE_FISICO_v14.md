# Versão 14 — painel, câmera e comandos visuais

- HUD reorganizado com velocímetro em destaque, RPM, marcha, limite e estado da moto. A leitura de km/h vem da velocidade real do Rigidbody.
- Botões no HUD e teclas: `I` ignição, `L` farol, `Z/X` setas, `H` alerta. O farol usa feixe de luz; as setas piscam; a lanterna traseira aumenta ao frear.
- Segure o botão direito e arraste para olhar ao redor. Em `AJUSTAR CÂMERA`, sliders alteram altura e distância da câmera em primeira pessoa; os valores ficam salvos no computador. Há botão para restaurar a posição inicial.
- A manopla do acelerador gira enquanto `W` está pressionado, a chave acompanha o estado do motor e os manetes respondem aos comandos existentes. A liberação da embreagem ficou mais rápida.

Os controles foram conectados às peças nomeadas no modelo. Não existem botões físicos separados para todas as funções no FBX; os botões clicáveis do HUD fornecem essas ações. A aparência e a iluminação precisam ser conferidas no Play do Unity local.
