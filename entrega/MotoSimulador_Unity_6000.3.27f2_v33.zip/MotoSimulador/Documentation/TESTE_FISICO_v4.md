# Versão 4 — equilíbrio, câmera do piloto e suspensão dianteira

Ao abrir o pacote v4, o Editor cria uma cena nova (`CG160_TesteFisico_v4`) para aplicar as mudanças sem reaproveitar a cena antiga. A inspeção anterior continua acessível pelo menu MotoSim.

## O que foi corrigido

- A assistência de equilíbrio agora corrige a rolagem ao redor do eixo longitudinal da moto. Antes, o cálculo cruzava vetores de forma que aplicava torque no eixo errado e não conseguia recuperar uma queda lateral.
- O ganho e o amortecimento do equilíbrio foram aumentados, e o centro de massa configurável foi baixado de 0,50 m para 0,42 m. São valores de estabilidade inicial, ainda sujeitos ao teste de pilotagem.
- A moto não começa mais 18 cm acima da posição calibrada das rodas. Os WheelColliders podem alcançar o piso dentro do curso de suspensão configurado.
- A câmera passou para um ponto de vista aproximado do piloto, atrás do guidão.
- Os pivôs `CTRL_Direcao_PROVISORIO` e `CTRL_Suspensao_Dianteira` do FBX agora recebem o ângulo e o deslocamento medidos pela roda física dianteira. Guidão, farol e conjunto do garfo movem-se com esses pivôs.

## Uso e limites

Os comandos continuam iguais: `I` liga o motor; segure `Shift` e aperte `Q` para a primeira marcha; `W` acelera e soltar `Shift` libera a embreagem gradualmente. `A/D` esterçam, `Espaço` freia na frente, `S` freia atrás e `R` reinicia. Clique na janela Game antes de usar o teclado.

A câmera e o alinhamento do conjunto visual são estimativas iniciais de posição, ainda sem calibração com o piloto ou medidas reais. A moto continua usando assistência ativa de equilíbrio; o teste não representa estabilidade natural de uma motocicleta real. Os valores de entre-eixos, massa, centro de gravidade, suspensão e pneus não são especificações oficiais da Honda.

Os 30 testes do núcleo C# cobrem transmissão, comandos e fórmulas de calibração, mas não executam Unity nem PhysX. A montagem da cena e a resposta das rodas precisam de nova validação em Play no Editor instalado no PC.
