# Versão 8 — velocidade de treino limitada a 50 km/h

A cena `CG160_TesteFisico_v8` é recriada automaticamente ao abrir este pacote.

## Mudanças

- O texto das faixas foi removido; as duas faixas amarelas continuam na moto.
- A pista tem limite de 50 km/h. A entrega de torque diminui gradualmente nos últimos 3 km/h, corta no limite e a velocidade horizontal é limitada novamente depois do passo de física.
- Direção em velocidade ficou mais suave: o ângulo máximo permitido acompanha o limite de inclinação, e o máximo de esterço diminui progressivamente até 50 km/h.
- A velocidade máxima aparece no HUD.

Os testes do núcleo verificam a curva de corte de torque do limitador e os valores do perfil. Eles não executam Unity/PhysX. A cena precisa ser testada em Play no PC para verificar se o problema de contato e instabilidade perto de 20 km/h foi resolvido.
