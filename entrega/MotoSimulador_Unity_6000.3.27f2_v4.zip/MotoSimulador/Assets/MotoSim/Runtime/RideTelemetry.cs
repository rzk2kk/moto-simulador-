using UnityEngine;

namespace MotoSim.Unity
{
    public sealed class RideTelemetry : MonoBehaviour
    {
        [SerializeField] private MotorcycleController motorcycle;
        public void Configure(MotorcycleController vehicle) => motorcycle = vehicle;
        private void OnGUI()
        {
            if (motorcycle == null) return;
            var state = motorcycle.Telemetry;
            string gear = state.Gear == 0 ? "N" : state.Gear.ToString();
            GUI.Box(new Rect(12, 12, 500, 140),
                "TESTE FÍSICO — PARÂMETROS PROVISÓRIOS\n" +
                motorcycle.SpeedKph.ToString("0") + " km/h    " + state.EngineRpm.ToString("0") + " RPM    Marcha " + gear +
                "    Motor " + (state.EngineRunning ? "ligado" : "desligado") + "\n" +
                "I: ignição | Shift + Q: primeira | W: acelerar\n" +
                "Segure W e solte Shift: liberação gradual assistida.\n" +
                "A/D: direção | Espaço: freio dianteiro | S: traseiro\n" +
                "Shift + E/Q: marchas | Shift + N: neutro | R: recomeçar");
        }
    }
}
