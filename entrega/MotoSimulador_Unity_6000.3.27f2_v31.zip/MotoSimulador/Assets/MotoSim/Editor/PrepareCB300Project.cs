using System;
using System.IO;
using System.Linq;
using MotoSim.Core;
using MotoSim.Unity;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.SceneManagement;

namespace MotoSim.Editor
{
    /// <summary>Creates the CB300 Twister riding scene using the same MotoSim input, camera, audio and physics systems.</summary>
    public static class PrepareCB300Project
    {
        internal const string ScenePath = "Assets/MotoSim/Generated/CB300_Twister_TesteFisico.unity";
        private const string ModelPath = "Assets/MotoSim/Art/CB300_Twister_MotoSim.fbx";
        private const string Generated = "Assets/MotoSim/Generated";
        private const string SessionKey = "MotoSim.CB300SetupAttempted_v1";
        private static string Root => Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
        private static string Completion => Path.Combine(Root, "ProjectSettings/MotoSimCB300Setup.json");

        internal static void TryAutomaticSetup()
        {
            if (File.Exists(Completion) && AssetDatabase.LoadAssetAtPath<SceneAsset>(ScenePath) != null)
            {
                var active = SceneManager.GetActiveScene();
                if (active.IsValid() && !active.isDirty && string.IsNullOrEmpty(active.path))
                    PrepareInspectionProject.OpenPreparedScene(ScenePath);
                return;
            }
            if (SessionState.GetBool(SessionKey, false)) return;
            SessionState.SetBool(SessionKey, true);
            RunSetup();
        }

        [MenuItem("MotoSim/Abrir Honda CB 300 Twister")]
        public static void RunSetup()
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode || EditorApplication.isCompiling || EditorApplication.isUpdating)
            {
                EditorApplication.isPlaying = false;
                EditorApplication.delayCall += RunSetup;
                return;
            }
            try
            {
                PrepareInspectionProject.EnsureFolder("Assets/MotoSim", "Generated");
                PrepareInspectionProject.EnsureFolder(Generated, "Materials");
                PrepareInspectionProject.ConfigurePipeline();
                if (AssetDatabase.LoadAssetAtPath<SceneAsset>(ScenePath) == null) CreateScene();
                else PrepareInspectionProject.OpenPreparedScene(ScenePath);
                Scene scene = SceneManager.GetSceneByPath(ScenePath);
                if (!PrepareInspectionProject.HasGameCamera(scene))
                    throw new InvalidOperationException("A cena da CB 300 não tem uma câmera de jogo ativa.");
                AssetDatabase.SaveAssets();
                File.WriteAllText(Completion, "{\"scenePrepared\":true,\"bike\":\"CB300 Twister\",\"referenceCalibration\":false}");
                Debug.Log("MotoSim: cena da Honda CB 300 Twister criada com o sistema de pilotagem existente. Testar aceleração, luzes e direção em Play.");
            }
            catch (Exception error)
            {
                Debug.LogException(error);
                File.WriteAllText(Path.Combine(Root, "MotoSim_CB300_Setup_Error.txt"), error.ToString());
                EditorUtility.DisplayDialog("MotoSim — CB 300", error.Message, "OK");
            }
        }

        private static void CreateScene()
        {
            GameObject model = AssetDatabase.LoadAssetAtPath<GameObject>(ModelPath);
            if (model == null) throw new InvalidOperationException("O FBX da CB 300 ainda não foi importado pelo Unity: " + ModelPath);

            // These are adjustable test values for a 300-class bike, not a factory-certified calibration.
            var profile = new BikePhysicsProfile
            {
                WheelbaseMetres = 1.41f,
                BikeMassKg = 147f,
                RiderMassKg = 75f,
                FrontWeightFraction = .48f,
                SuspensionTravelMetres = .12f,
                SuspensionFrequencyHz = 3f,
                SuspensionDampingRatio = .82f,
                CenterOfMassHeightMetres = .48f,
                TrainingSpeedLimitKph = 160f,
                GearSpeedLimitsKph = new[] { 20f, 40f, 80f, 110f, 160f },
                ClutchPullPerSecond = 16f,
                ClutchReleasePerSecond = 8f,
                ReferenceVerified = false,
                ReferenceNote = "Ajuste inicial de teste para o modelo CB300 importado; confirmar ano e especificações antes de calibrar.",
                ReferenceUrl = ""
            };
            profile.Validate();

            var recovered = PrepareInspectionProject.PreserveUnnamedScenes();
            Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Additive);
            SceneManager.SetActiveScene(scene);
            var root = new GameObject("CB300_Twister_Fisica");
            var visual = PrefabUtility.InstantiatePrefab(model, scene) as GameObject;
            if (visual == null) throw new InvalidOperationException("O modelo FBX da CB 300 não pôde ser instanciado.");
            visual.name = "Modelo_CB300_Twister";
            visual.transform.SetParent(root.transform, true);

            Transform front = Find(visual, "Eixo_Roda_Dianteira");
            Transform rear = Find(visual, "Eixo_Roda_Traseira");
            Vector3 direction = Vector3.ProjectOnPlane(front.position - rear.position, Vector3.up);
            if (direction.sqrMagnitude < .000001f) throw new InvalidOperationException("Os eixos das rodas da CB 300 estão sobrepostos.");
            visual.transform.rotation = Quaternion.FromToRotation(direction.normalized, Vector3.forward) * visual.transform.rotation;
            float measuredWheelbase = Vector3.ProjectOnPlane(front.position - rear.position, Vector3.up).magnitude;
            float scale = VehicleCalibration.UniformScale(measuredWheelbase, profile.WheelbaseMetres);
            visual.transform.localScale *= scale;
            Bounds tyreBounds = BoundsOf(FindRenderers(visual, "Pneu_"));
            visual.transform.position += new Vector3(-rear.position.x, -tyreBounds.min.y, -rear.position.z);

            Vector3 frontCenter = front.position;
            Vector3 rearCenter = rear.position;
            float frontRadius = TyreRadius(Find(visual, "Pneu_Dianteiro"));
            float rearRadius = TyreRadius(Find(visual, "Pneu_Traseiro"));
            float calibratedBase = Vector3.ProjectOnPlane(frontCenter - rearCenter, Vector3.up).magnitude;
            if (Mathf.Abs(calibratedBase - profile.WheelbaseMetres) > .025f)
                throw new InvalidOperationException("O entre-eixos importado não bate com a escala calibrada.");

            foreach (Renderer renderer in visual.GetComponentsInChildren<Renderer>(true))
            {
                Material[] materials = renderer.sharedMaterials;
                for (int i = 0; i < materials.Length; i++)
                    materials[i] = PrepareInspectionProject.PrepareMaterial(materials[i], renderer.name);
                renderer.sharedMaterials = materials;
            }

            var bodyCollider = root.AddComponent<BoxCollider>();
            bodyCollider.center = new Vector3(0f, .60f, .64f);
            bodyCollider.size = new Vector3(.48f, .54f, 1.12f);
            var body = root.AddComponent<Rigidbody>();
            body.mass = profile.TotalMassKg;
            body.centerOfMass = new Vector3(0f, profile.CenterOfMassHeightMetres, profile.WheelbaseMetres * profile.FrontWeightFraction);
            body.interpolation = RigidbodyInterpolation.Interpolate;
            body.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
            body.solverIterations = 16;
            body.solverVelocityIterations = 8;
            body.maxAngularVelocity = 5f;

            WheelCollider frontWheel = MakeWheel(root, "RodaFisica_CB300_Dianteira", frontCenter, frontRadius,
                profile.TotalMassKg * profile.FrontWeightFraction, profile);
            WheelCollider rearWheel = MakeWheel(root, "RodaFisica_CB300_Traseira", rearCenter, rearRadius,
                profile.TotalMassKg * (1f - profile.FrontWeightFraction), profile);
            var controller = root.AddComponent<MotorcycleController>();
            controller.Configure(frontWheel, rearWheel, profile);
            root.AddComponent<MotorcycleAudio>().Configure(controller);
            root.AddComponent<KeyboardRiderInput>();
            root.AddComponent<RiderControlVisuals>().Configure(null, null, null, null, controller);

            Transform steering = FindOptional(visual, "CTRL_Direcao_PROVISORIO");
            Transform suspension = FindOptional(visual, "CTRL_Suspensao_Dianteira");
            if (steering != null && suspension != null)
                root.AddComponent<FrontVisualRig>().Configure(steering, suspension, frontWheel, frontCenter);

            Renderer headlamp = FindRendererByMaterial(visual, "FarolCB");
            Renderer tailLamp = FindRendererByMaterial(visual, "LanternaCB");
            Renderer[] signals = FindRenderersByMaterial(visual, "PiscaAlertaCB");
            if (headlamp == null || tailLamp == null || signals.Length == 0)
                throw new InvalidOperationException("Não encontrei no CB300 as lentes identificadas de farol, lanterna e setas.");
            var lighting = root.AddComponent<MotorcycleLighting>();
            lighting.Configure(visual, steering, controller, headlamp, tailLamp, signals, signals);
            root.AddComponent<WheelPoseBinding>().Configure(frontWheel, front, frontCenter);
            root.AddComponent<WheelPoseBinding>().Configure(rearWheel, rear, rearCenter);

            root.transform.position = new Vector3(0f, 0f, -3.8f);
            body.ResetInertiaTensor();
            TrainingCourseBuilder.Build();

            var cameraObject = new GameObject("Camera_Acompanhamento_CB300");
            cameraObject.tag = "MainCamera";
            var camera = cameraObject.AddComponent<Camera>(); camera.fieldOfView = 55f; camera.nearClipPlane = .05f;
            camera.farClipPlane = 180f; camera.clearFlags = CameraClearFlags.SolidColor;
            camera.backgroundColor = new Color(.25f, .34f, .45f);
            cameraObject.AddComponent<AudioListener>();
            var rideCamera = cameraObject.AddComponent<RideCamera>(); rideCamera.Configure(root.transform);
            cameraObject.AddComponent<RideTelemetry>().Configure(controller, rideCamera, lighting);

            var sunObject = new GameObject("Luz_Solar_CB300");
            var sun = sunObject.AddComponent<Light>(); sun.type = LightType.Directional; sun.intensity = 1.5f; sun.shadows = LightShadows.Soft;
            sunObject.transform.rotation = Quaternion.Euler(45f, -35f, 0f);
            RenderSettings.sun = sun; RenderSettings.ambientMode = AmbientMode.Trilight;
            RenderSettings.ambientSkyColor = new Color(.55f, .62f, .7f);
            RenderSettings.ambientEquatorColor = new Color(.3f, .32f, .35f);
            RenderSettings.ambientGroundColor = new Color(.15f, .14f, .13f);

            if (!EditorSceneManager.SaveScene(scene, ScenePath)) throw new IOException("Não foi possível salvar a cena de teste da CB 300.");
            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
            PrepareInspectionProject.CloseRecoveredScenes(recovered);
            File.WriteAllText(Path.Combine(Root, "ProjectSettings/MotoSimCB300Calibration.json"),
                "{\"wheelbaseMetres\":" + F(profile.WheelbaseMetres) + ",\"scaleApplied\":" + F(scale) +
                ",\"frontRadiusMetres\":" + F(frontRadius) + ",\"rearRadiusMetres\":" + F(rearRadius) +
                ",\"totalMassKg\":" + F(profile.TotalMassKg) + ",\"referenceVerified\":false}");
        }

        private static WheelCollider MakeWheel(GameObject root, string name, Vector3 center, float radius, float supportedMass, BikePhysicsProfile p)
        {
            var wheelObject = new GameObject(name);
            wheelObject.transform.SetParent(root.transform, false);
            wheelObject.transform.position = center + Vector3.up * p.SuspensionTravelMetres * .5f;
            var wheel = wheelObject.AddComponent<WheelCollider>();
            wheel.radius = radius; wheel.mass = 10f; wheel.sprungMass = supportedMass;
            wheel.suspensionDistance = p.SuspensionTravelMetres; wheel.forceAppPointDistance = .04f; wheel.wheelDampingRate = .4f;
            float spring = VehicleCalibration.SpringRate(supportedMass, p.SuspensionFrequencyHz * .82f);
            wheel.suspensionSpring = new JointSpring
            {
                spring = spring,
                damper = VehicleCalibration.DamperRate(supportedMass, spring, Mathf.Max(1.05f, p.SuspensionDampingRatio)),
                targetPosition = .5f
            };
            WheelFrictionCurve forward = wheel.forwardFriction;
            forward.extremumSlip = .18f; forward.extremumValue = 1f; forward.asymptoteSlip = .38f;
            forward.asymptoteValue = .82f; forward.stiffness = 1.2f; wheel.forwardFriction = forward;
            WheelFrictionCurve sideways = wheel.sidewaysFriction;
            sideways.extremumSlip = .3f; sideways.extremumValue = .85f; sideways.asymptoteSlip = .65f;
            sideways.asymptoteValue = .68f; sideways.stiffness = .82f; wheel.sidewaysFriction = sideways;
            wheel.ConfigureVehicleSubsteps(100f, 16, 16);
            return wheel;
        }

        private static float TyreRadius(Transform tyre)
        {
            Renderer renderer = tyre.GetComponent<Renderer>() ?? tyre.GetComponentInChildren<Renderer>(true);
            if (renderer == null) throw new InvalidOperationException("O pneu não tem Renderer: " + tyre.name);
            float radius = renderer.bounds.extents.y;
            if (radius < .15f || radius > .6f) throw new InvalidOperationException("Raio de pneu fora da faixa: " + radius);
            return radius;
        }

        private static Bounds BoundsOf(Renderer[] renderers)
        {
            if (renderers == null || renderers.Length == 0) throw new InvalidOperationException("Não encontrei os dois pneus da CB 300.");
            Bounds bounds = renderers[0].bounds;
            foreach (Renderer renderer in renderers) bounds.Encapsulate(renderer.bounds);
            return bounds;
        }

        private static Renderer[] FindRenderers(GameObject model, string prefix) =>
            model.GetComponentsInChildren<Renderer>(true).Where(r => r.name.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)).ToArray();

        private static Renderer FindRendererByMaterial(GameObject model, string token) =>
            model.GetComponentsInChildren<Renderer>(true).FirstOrDefault(r => r.sharedMaterials.Any(m =>
                m != null && m.name.IndexOf(token, StringComparison.OrdinalIgnoreCase) >= 0));

        private static Renderer[] FindRenderersByMaterial(GameObject model, string token) =>
            model.GetComponentsInChildren<Renderer>(true).Where(r => r.sharedMaterials.Any(m =>
                m != null && m.name.IndexOf(token, StringComparison.OrdinalIgnoreCase) >= 0)).ToArray();

        private static Transform Find(GameObject model, string name) => FindOptional(model, name) ??
            throw new InvalidOperationException("Locator funcional não encontrado no FBX: " + name);

        private static Transform FindOptional(GameObject model, string name) =>
            model.GetComponentsInChildren<Transform>(true).FirstOrDefault(t => t.name == name);

        private static string F(float value) => value.ToString("R", System.Globalization.CultureInfo.InvariantCulture);
    }
}
