using UnityEngine;

namespace MotoSim.Unity
{
    /// <summary>Small synthesized starter cue and engine loop, with no external audio assets.</summary>
    public sealed class MotorcycleAudio : MonoBehaviour
    {
        [SerializeField] private MotorcycleController motorcycle;
        [SerializeField, Range(0, 1)] private float engineVolume = .24f;
        [SerializeField, Range(0, 1)] private float starterVolume = .48f;
        private AudioSource starterSource;
        private AudioSource engineSource;
        private AudioClip starterClip;
        private AudioClip engineClip;
        private bool wasRunning;
        private const int SampleRate = 22050;

        public void Configure(MotorcycleController vehicle) => motorcycle = vehicle;

        private void Awake()
        {
            starterClip = CreateStarterClip();
            engineClip = CreateEngineLoop();
            starterSource = gameObject.AddComponent<AudioSource>();
            starterSource.playOnAwake = false;
            starterSource.spatialBlend = 0;
            starterSource.volume = starterVolume;
            engineSource = gameObject.AddComponent<AudioSource>();
            engineSource.clip = engineClip;
            engineSource.loop = true;
            engineSource.playOnAwake = false;
            engineSource.spatialBlend = 0;
            engineSource.volume = engineVolume;
        }

        private void Update()
        {
            bool running = motorcycle != null && motorcycle.Telemetry.EngineRunning;
            if (running && !wasRunning) starterSource.PlayOneShot(starterClip, starterVolume);
            if (running)
            {
                if (!engineSource.isPlaying) engineSource.Play();
                float rpm = motorcycle.Telemetry.EngineRpm;
                engineSource.pitch = Mathf.Lerp(.72f, 2.3f, Mathf.Clamp01((rpm - 900) / 8100f));
                engineSource.volume = engineVolume * Mathf.Lerp(.75f, 1.35f, motorcycle.ThrottleInput);
            }
            else if (engineSource.isPlaying) engineSource.Stop();
            wasRunning = running;
        }

        private static AudioClip CreateStarterClip()
        {
            const float duration = .62f;
            int count = Mathf.CeilToInt(SampleRate * duration);
            var samples = new float[count];
            for (int i = 0; i < count; i++)
            {
                float t = (float)i / SampleRate;
                float envelope = t < .48f ? Mathf.Sin(Mathf.PI * Mathf.Clamp01(t / .48f)) :
                    Mathf.Exp(-(t - .48f) * 18f);
                float frequency = Mathf.Lerp(58, 92, Mathf.Clamp01(t / .4f));
                float crank = Mathf.Sin(2 * Mathf.PI * frequency * t) * .58f +
                    Mathf.Sin(2 * Mathf.PI * frequency * 2.03f * t) * .2f;
                float click = Mathf.Exp(-t * 95f) * Mathf.Sin(2 * Mathf.PI * 1300 * t) * .45f;
                float startCatch = Mathf.Exp(-Mathf.Abs(t - .48f) * 42f) * Mathf.Sin(2 * Mathf.PI * 76 * t) * .7f;
                samples[i] = Mathf.Clamp((crank * envelope + click + startCatch) * .7f, -1, 1);
            }
            AudioClip clip = AudioClip.Create("MotoSim_Som_Partida", count, 1, SampleRate, false);
            clip.SetData(samples, 0);
            return clip;
        }

        private static AudioClip CreateEngineLoop()
        {
            int count = SampleRate;
            var samples = new float[count];
            const float cyclesPerSecond = 28;
            for (int i = 0; i < count; i++)
            {
                float phase = Mathf.Repeat((float)i / SampleRate * cyclesPerSecond, 1f);
                float angle = phase * 2 * Mathf.PI;
                float pulse = Mathf.Sin(angle) * .42f + Mathf.Sin(angle * 2) * .22f +
                    Mathf.Sin(angle * 3) * .1f + Mathf.Sin(angle * 5) * .055f;
                float rasp = (phase < .12f ? 1f : -.18f) * .11f;
                samples[i] = Mathf.Clamp((pulse + rasp) * .68f, -.8f, .8f);
            }
            AudioClip clip = AudioClip.Create("MotoSim_Som_Motor_Ligado", count, 1, SampleRate, false);
            clip.SetData(samples, 0);
            return clip;
        }

        private void OnDestroy()
        {
            if (starterClip != null) Destroy(starterClip);
            if (engineClip != null) Destroy(engineClip);
        }
    }
}
