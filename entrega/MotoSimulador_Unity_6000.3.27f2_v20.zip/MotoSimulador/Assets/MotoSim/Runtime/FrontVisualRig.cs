using UnityEngine;

namespace MotoSim.Unity
{
    /// <summary>Drives the imported steering and fork pivots from the physical front wheel.</summary>
    [DefaultExecutionOrder(-100)]
    public sealed class FrontVisualRig : MonoBehaviour
    {
        [SerializeField] private Transform steeringPivot;
        [SerializeField] private Transform suspensionPivot;
        [SerializeField] private WheelCollider frontWheel;
        [SerializeField] private Quaternion steeringRestRotation;
        [SerializeField] private Vector3 suspensionRestPosition;
        [SerializeField] private Vector3 wheelRestCenter;
        [SerializeField] private bool configured;
        [SerializeField] private float suspensionSmoothTime = .12f;
        [SerializeField, Range(.1f, 1f)] private float visibleSuspensionTravel = .4f;
        private float smoothedSuspensionTravel;
        private float suspensionTravelVelocity;

        public void Configure(Transform steering, Transform suspension, WheelCollider wheel, Vector3 restWheelCenter)
        {
            steeringPivot = steering;
            suspensionPivot = suspension;
            frontWheel = wheel;
            steeringRestRotation = steering.localRotation;
            suspensionRestPosition = suspension.localPosition;
            wheelRestCenter = transform.InverseTransformPoint(restWheelCenter);
            configured = true;
        }

        private void LateUpdate()
        {
            if (!configured || steeringPivot == null || suspensionPivot == null || frontWheel == null) return;

            steeringPivot.localRotation = steeringRestRotation *
                Quaternion.AngleAxis(frontWheel.steerAngle, Vector3.forward);

            frontWheel.GetWorldPose(out Vector3 wheelCenter, out _);
            Transform suspensionParent = suspensionPivot.parent;
            Vector3 forkAxisWorld = suspensionPivot.TransformDirection(Vector3.forward).normalized;
            Vector3 forkAxisInParent = suspensionParent == null
                ? transform.InverseTransformDirection(forkAxisWorld).normalized
                : suspensionParent.InverseTransformDirection(forkAxisWorld).normalized;
            Vector3 wheelCenterLocal = transform.InverseTransformPoint(wheelCenter);
            Vector3 forkAxisInRoot = transform.InverseTransformDirection(forkAxisWorld).normalized;
            float suspensionTravel = Vector3.Dot(wheelCenterLocal - wheelRestCenter, forkAxisInRoot);
            suspensionTravel = Mathf.Clamp(suspensionTravel,
                -frontWheel.suspensionDistance * .5f, frontWheel.suspensionDistance * .5f);
            smoothedSuspensionTravel = Mathf.SmoothDamp(smoothedSuspensionTravel,
                suspensionTravel * visibleSuspensionTravel,
                ref suspensionTravelVelocity, suspensionSmoothTime);
            suspensionPivot.localPosition = suspensionRestPosition + forkAxisInParent * smoothedSuspensionTravel;
        }
    }
}
