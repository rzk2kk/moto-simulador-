using UnityEngine;

namespace MotoSim.Unity
{
    /// <summary>Toggleable first- and third-person riding camera.</summary>
    public sealed class RideCamera : MonoBehaviour
    {
        [SerializeField] private Transform target;
        [SerializeField] private Vector3 localEyePosition = new Vector3(0, 1.18f, .43f);
        [SerializeField] private Vector3 localThirdPersonPosition = new Vector3(0, 1.6f, -3.4f);
        [SerializeField] private Vector3 localThirdPersonFocus = new Vector3(0, .75f, .45f);
        [SerializeField] private bool firstPerson = true;
        [SerializeField] private float mouseSensitivity = 2.2f;
        [SerializeField] private float maxPitchDegrees = 65;
        [SerializeField] private float firstPersonHeightOffset;
        [SerializeField] private float firstPersonForwardOffset;
        private Vector3 velocity;
        private Vector2 look;
        private bool dragging;
        private const string HeightPreference = "MotoSim.Camera.FirstPerson.Height";
        private const string ForwardPreference = "MotoSim.Camera.FirstPerson.Forward";

        public bool IsFirstPerson => firstPerson;
        public float FirstPersonHeightOffset => firstPersonHeightOffset;
        public float FirstPersonForwardOffset => firstPersonForwardOffset;

        public void Configure(Transform vehicle)
        {
            target = vehicle;
            firstPersonHeightOffset = PlayerPrefs.GetFloat(HeightPreference, firstPersonHeightOffset);
            firstPersonForwardOffset = PlayerPrefs.GetFloat(ForwardPreference, firstPersonForwardOffset);
            Position(false);
        }

        public void SetFirstPersonOffsets(float height, float forward)
        {
            firstPersonHeightOffset = Mathf.Clamp(height, -.25f, .65f);
            firstPersonForwardOffset = Mathf.Clamp(forward, -.35f, .65f);
            PlayerPrefs.SetFloat(HeightPreference, firstPersonHeightOffset);
            PlayerPrefs.SetFloat(ForwardPreference, firstPersonForwardOffset);
            Position(false);
        }

        public void ResetFirstPersonOffsets() => SetFirstPersonOffsets(0, 0);

        public void ToggleView()
        {
            firstPerson = !firstPerson;
            velocity = Vector3.zero;
            Position(false);
        }

        private void LateUpdate() => Position(true);

        private void Update()
        {
#if ENABLE_LEGACY_INPUT_MANAGER
            if (Input.GetKeyDown(KeyCode.V)) ToggleView();
            if (Input.GetMouseButtonDown(1)) dragging = true;
            if (Input.GetMouseButtonUp(1)) dragging = false;
            if (dragging)
            {
                look.x += Input.GetAxis("Mouse X") * mouseSensitivity;
                look.y = Mathf.Clamp(look.y - Input.GetAxis("Mouse Y") * mouseSensitivity,
                    -maxPitchDegrees, maxPitchDegrees);
            }
#endif
        }

        private void OnGUI()
        {
            Event e = Event.current;
#if !ENABLE_LEGACY_INPUT_MANAGER
            if (e.type == EventType.KeyDown && e.keyCode == KeyCode.V)
            { ToggleView(); e.Use(); }
#endif
#if !ENABLE_LEGACY_INPUT_MANAGER
            if (e.type == EventType.MouseDown && e.button == 1) dragging = true;
            if (e.type == EventType.MouseUp && e.button == 1) dragging = false;
            if (dragging && e.type == EventType.MouseDrag && e.button == 1)
            {
                look.x += e.delta.x * mouseSensitivity * .1f;
                look.y = Mathf.Clamp(look.y + e.delta.y * mouseSensitivity * .1f,
                    -maxPitchDegrees, maxPitchDegrees);
                e.Use();
            }
#endif
        }

        private void Position(bool smooth)
        {
            if (target == null) return;
            Vector3 desired;
            Quaternion desiredRotation;
            if (firstPerson)
            {
                desired = target.TransformPoint(localEyePosition +
                    new Vector3(0, firstPersonHeightOffset, firstPersonForwardOffset));
                desiredRotation = target.rotation * Quaternion.Euler(look.y, look.x, 0);
            }
            else
            {
                Vector3 focus = target.TransformPoint(localThirdPersonFocus);
                Vector3 orbit = Quaternion.Euler(look.y, look.x, 0) *
                    target.TransformVector(localThirdPersonPosition - localThirdPersonFocus);
                desired = focus + orbit;
                desiredRotation = Quaternion.LookRotation(focus - desired, Vector3.up);
            }
            transform.position = smooth
                ? Vector3.SmoothDamp(transform.position, desired, ref velocity, firstPerson ? .06f : .14f)
                : desired;
            transform.rotation = smooth
                ? Quaternion.Slerp(transform.rotation, desiredRotation, 1 - Mathf.Exp(-8 * Time.deltaTime))
                : desiredRotation;
        }
    }
}
