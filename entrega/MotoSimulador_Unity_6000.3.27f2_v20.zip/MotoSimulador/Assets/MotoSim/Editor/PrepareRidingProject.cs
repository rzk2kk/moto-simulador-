using System;
using System.IO;
using System.Linq;
using MotoSim.Core;
using MotoSim.Unity;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.SceneManagement;

namespace MotoSim.Editor
{
    public static class PrepareRidingProject
    {
        internal const string ScenePath = "Assets/MotoSim/Generated/CG160_TesteFisico_v17.unity";
        private const string Generated = "Assets/MotoSim/Generated";
        private const string SessionKey = "MotoSim.RidingSetupAttempted_v17";
        private static string Root => Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
        private static string Completion => Path.Combine(Root, "ProjectSettings/MotoSimRidingSetup.json");
        internal static void TryAutomaticSetup()
        {
            if (File.Exists(Completion) && AssetDatabase.LoadAssetAtPath<SceneAsset>(ScenePath) != null)
            {
                var active = SceneManager.GetActiveScene();
                if (active.IsValid() && !active.isDirty && string.IsNullOrEmpty(active.path))
                    PrepareInspectionProject.OpenPreparedScene(ScenePath);
                return;
            }
            if (SessionState.GetBool(SessionKey, false)) return;
            SessionState.SetBool(SessionKey, true); RunSetup();
        }
        [MenuItem("MotoSim/Abrir teste físico")]
        public static void RunSetup()
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode || EditorApplication.isCompiling || EditorApplication.isUpdating)
            {
                EditorApplication.isPlaying = false; EditorApplication.delayCall += RunSetup; return;
            }
            try
            {
                PrepareInspectionProject.EnsureFolder("Assets/MotoSim", "Generated");
                PrepareInspectionProject.EnsureFolder(Generated, "Materials");
                PrepareInspectionProject.ConfigurePipeline();
                if (AssetDatabase.LoadAssetAtPath<SceneAsset>(ScenePath) == null) CreateScene();
                else PrepareInspectionProject.OpenPreparedScene(ScenePath);
                Scene scene = SceneManager.GetSceneByPath(ScenePath);
                if (!PrepareInspectionProject.HasGameCamera(scene)) throw new InvalidOperationException("O teste físico não possui câmera ativa.");
                AssetDatabase.SaveAssets();
                File.WriteAllText(Completion, "{\"physicsScenePrepared\":true,\"manufacturerReferenceVerified\":false}");
                Debug.Log("MotoSim: teste físico preparado com parâmetros provisórios. Validar comportamento em Play.");
            }
            catch (Exception error)
            {
                Debug.LogException(error); File.WriteAllText(Path.Combine(Root, "MotoSim_Setup_Error.txt"), error.ToString());
                EditorUtility.DisplayDialog("MotoSim — preparação incompleta", error.Message, "OK");
            }
        }
        private static void CreateScene()
        {
            var config = AssetDatabase.LoadAssetAtPath<TextAsset>("Assets/MotoSim/Config/PhysicsCalibration.json");
            if (config == null) throw new InvalidOperationException("Perfil de calibração não encontrado.");
            var profile = JsonUtility.FromJson<BikePhysicsProfile>(config.text); profile.Validate();
            var model = AssetDatabase.LoadAssetAtPath<GameObject>("Assets/MotoSim/Art/CG160_neutra_unidades_originais.fbx");
            if (model == null) throw new InvalidOperationException("A importação da moto não terminou.");
            var recovered = PrepareInspectionProject.PreserveUnnamedScenes();
            Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Additive);
            SceneManager.SetActiveScene(scene);
            var root = new GameObject("CG160_Fisica_Provisoria");
            var visual = (GameObject)PrefabUtility.InstantiatePrefab(model, scene);
            visual.name = "Modelo_Original"; visual.transform.SetParent(root.transform, true);
            Transform front = Find(visual, "Eixo_Roda_Dianteira"), rear = Find(visual, "Eixo_Roda_Traseira");
            Vector3 direction = Vector3.ProjectOnPlane(front.position - rear.position, Vector3.up);
            if (direction.sqrMagnitude < .000001f) throw new InvalidOperationException("Não foi possível identificar o sentido de avanço.");
            visual.transform.rotation = Quaternion.FromToRotation(direction.normalized, Vector3.forward) * visual.transform.rotation;
            float measured = Vector3.ProjectOnPlane(front.position - rear.position, Vector3.up).magnitude;
            float scale = VehicleCalibration.UniformScale(measured, profile.WheelbaseMetres);
            visual.transform.localScale *= scale;
            Bounds bothTyres = TyreBounds(visual, "Pneu_");
            visual.transform.position -= new Vector3(rear.position.x, bothTyres.min.y, rear.position.z);
            Vector3 frontCenter = front.position, rearCenter = rear.position;
            float frontRadius = TyreRadius(visual, "Pneu_Dianteiro", frontCenter);
            float rearRadius = TyreRadius(visual, "Pneu_Traseiro", rearCenter);
            if (Mathf.Abs((frontCenter - rearCenter).magnitude - profile.WheelbaseMetres) > .02f)
                throw new InvalidOperationException("A escala aplicada não corresponde ao entre-eixos solicitado.");
            foreach (var renderer in visual.GetComponentsInChildren<Renderer>(true))
            {
                var materials = renderer.sharedMaterials;
                Material paint = PaintMaterialFor(renderer.name);
                Material lens = LightMaterialFor(renderer.name);
                if (lens != null) paint = lens;
                for (int i = 0; i < materials.Length; i++)
                    materials[i] = paint != null ? paint : PrepareInspectionProject.PrepareMaterial(materials[i], renderer.name);
                renderer.sharedMaterials = materials;
            }
            Transform ignitionPivot = Find(visual, "CTRL_Chave_Ignicao_PROVISORIO");
            CreateIgnitionKey(ignitionPivot);
            var chassis = root.AddComponent<BoxCollider>();
            chassis.center = new Vector3(0, .61f, profile.WheelbaseMetres * .45f);
            chassis.size = new Vector3(.32f, .58f, profile.WheelbaseMetres * .55f);
            var body = root.AddComponent<Rigidbody>(); body.mass = profile.TotalMassKg;
            body.centerOfMass = new Vector3(0, profile.CenterOfMassHeightMetres, profile.WheelbaseMetres * profile.FrontWeightFraction);
            body.interpolation = RigidbodyInterpolation.Interpolate; body.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
            body.solverIterations = 16; body.solverVelocityIterations = 8; body.maxAngularVelocity = 5;
            var frontWheel = MakeWheel(root, "RodaFisica_Dianteira", frontCenter, frontRadius,
                profile.TotalMassKg * profile.FrontWeightFraction, profile);
            var rearWheel = MakeWheel(root, "RodaFisica_Traseira", rearCenter, rearRadius,
                profile.TotalMassKg * (1 - profile.FrontWeightFraction), profile);
            var controller = root.AddComponent<MotorcycleController>(); controller.Configure(frontWheel, rearWheel, profile);
            root.AddComponent<MotorcycleAudio>().Configure(controller);
            var riderVisuals = root.AddComponent<RiderControlVisuals>();
            riderVisuals.Configure(Find(visual, "CTRL_Manete_Esquerdo_PROVISORIO"),
                Find(visual, "CTRL_Manete_Direito_PROVISORIO"),
                Find(visual, "CTRL_Acelerador_PROVISORIO"),
                ignitionPivot, controller, CreateRearBrakePedal(root.transform));
            CreateRearPlate(root.transform, rear.position);
            RemoveMirrors(visual);
            var frontVisualRig = root.AddComponent<FrontVisualRig>();
            frontVisualRig.Configure(Find(visual, "CTRL_Direcao_PROVISORIO"),
                Find(visual, "CTRL_Suspensao_Dianteira"), frontWheel, frontCenter);
            var lighting = root.AddComponent<MotorcycleLighting>();
            lighting.Configure(visual, Find(visual, "CTRL_Direcao_PROVISORIO"), controller);
            root.AddComponent<KeyboardRiderInput>();
            root.AddComponent<WheelPoseBinding>().Configure(frontWheel, front, frontCenter);
            root.AddComponent<WheelPoseBinding>().Configure(rearWheel, rear, rearCenter);
            // The rear wheel is the physical origin. Place the bike just behind the start gate,
            // facing the single forward course direction (+Z).
            root.transform.position = new Vector3(0, 0, -3.8f);
            body.ResetInertiaTensor();
            TrainingCourseBuilder.Build();
            var cameraObject = new GameObject("Camera_Acompanhamento"); cameraObject.tag = "MainCamera";
            var cameraComponent = cameraObject.AddComponent<Camera>(); cameraComponent.fieldOfView = 55; cameraComponent.nearClipPlane = .05f;
            cameraObject.AddComponent<AudioListener>();
            cameraComponent.farClipPlane = 180; cameraComponent.clearFlags = CameraClearFlags.SolidColor;
            cameraComponent.backgroundColor = new Color(.25f, .34f, .45f);
            var rideCamera = cameraObject.AddComponent<RideCamera>(); rideCamera.Configure(root.transform);
            cameraObject.AddComponent<RideTelemetry>().Configure(controller, rideCamera, lighting);
            var lightObject = new GameObject("Luz_Solar_Teste"); var light = lightObject.AddComponent<Light>();
            light.type = LightType.Directional; light.intensity = 1.5f; light.shadows = LightShadows.Soft;
            lightObject.transform.rotation = Quaternion.Euler(45, -35, 0);
            RenderSettings.sun = light; RenderSettings.ambientMode = AmbientMode.Trilight;
            RenderSettings.ambientSkyColor = new Color(.55f, .62f, .7f); RenderSettings.ambientEquatorColor = new Color(.3f,.32f,.35f);
            RenderSettings.ambientGroundColor = new Color(.15f,.14f,.13f);
            if (!EditorSceneManager.SaveScene(scene, ScenePath)) throw new IOException("Não foi possível salvar a cena de teste.");
            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
            PrepareInspectionProject.CloseRecoveredScenes(recovered);
            File.WriteAllText(Path.Combine(Root,"ProjectSettings/MotoSimCalibrationReport.json"),
                "{\"wheelbaseMetres\":"+F(profile.WheelbaseMetres)+",\"scaleApplied\":"+F(scale)+
                ",\"frontRadiusMetres\":"+F(frontRadius)+",\"rearRadiusMetres\":"+F(rearRadius)+
                ",\"totalMassKg\":"+F(profile.TotalMassKg)+",\"manufacturerReferenceVerified\":false}");
        }
        private static string F(float value) => value.ToString("R", System.Globalization.CultureInfo.InvariantCulture);
        private static void CreateIgnitionKey(Transform pivot)
        {
            foreach (Transform child in pivot.GetComponentsInChildren<Transform>(true))
                if (child != pivot && child.name.StartsWith("Chave_Argolas_Chaveiro_", StringComparison.Ordinal))
                    child.gameObject.SetActive(false);
            Material black = PaintMaterial("MotoSim_Chave_Preta", new Color(.018f, .022f, .028f), .38f);
            Material metal = PaintMaterial("MotoSim_Chave_Metal_Cinza", new Color(.58f, .62f, .66f), .7f);
            var head = GameObject.CreatePrimitive(PrimitiveType.Capsule);
            head.name = "Chave_Cabeca_Preta"; head.transform.SetParent(pivot, false);
            head.transform.localPosition = new Vector3(0, -.012f, .025f);
            head.transform.localRotation = Quaternion.Euler(90, 0, 0);
            head.transform.localScale = new Vector3(.034f, .012f, .034f);
            head.GetComponent<Renderer>().sharedMaterial = black;
            UnityEngine.Object.DestroyImmediate(head.GetComponent<Collider>());
            var blade = GameObject.CreatePrimitive(PrimitiveType.Cube);
            blade.name = "Chave_Haste_Metal_Cinza"; blade.transform.SetParent(pivot, false);
            blade.transform.localPosition = new Vector3(0, -.035f, .025f);
            blade.transform.localRotation = Quaternion.identity;
            blade.transform.localScale = new Vector3(.012f, .045f, .006f);
            blade.GetComponent<Renderer>().sharedMaterial = metal;
            UnityEngine.Object.DestroyImmediate(blade.GetComponent<Collider>());
        }
        private static Transform CreateRearBrakePedal(Transform root)
        {
            Material metal = PaintMaterial("MotoSim_Pedal_Freio_Metal", new Color(.48f, .52f, .56f), .66f);
            Material rubber = PaintMaterial("MotoSim_Pedal_Freio_Borracha", new Color(.035f, .04f, .045f), .3f);
            var pivot = new GameObject("CTRL_Pedal_Freio_Traseiro").transform;
            pivot.SetParent(root, false); pivot.localPosition = new Vector3(.29f, .28f, .56f);
            var arm = GameObject.CreatePrimitive(PrimitiveType.Cube);
            arm.name = "Pedal_Freio_Braco"; arm.transform.SetParent(pivot, false);
            arm.transform.localPosition = new Vector3(.025f, 0, .12f);
            arm.transform.localScale = new Vector3(.025f, .025f, .24f);
            arm.GetComponent<Renderer>().sharedMaterial = metal;
            UnityEngine.Object.DestroyImmediate(arm.GetComponent<Collider>());
            var pad = GameObject.CreatePrimitive(PrimitiveType.Cube);
            pad.name = "Pedal_Freio_Apoio"; pad.transform.SetParent(pivot, false);
            pad.transform.localPosition = new Vector3(.025f, .006f, .235f);
            pad.transform.localScale = new Vector3(.075f, .022f, .07f);
            pad.GetComponent<Renderer>().sharedMaterial = rubber;
            UnityEngine.Object.DestroyImmediate(pad.GetComponent<Collider>());
            return pivot;
        }
        private static void CreateRearPlate(Transform root, Vector3 rearAxle)
        {
            Material plate = PaintMaterial("MotoSim_Placa_Preto", new Color(.025f, .032f, .04f), .3f);
            Material lettering = PaintMaterial("MotoSim_Placa_Letras", new Color(.9f, .91f, .85f), .35f);
            var holder = new GameObject("Suporte_Placa_Traseira").transform;
            holder.SetParent(root, false);
            holder.localPosition = root.InverseTransformPoint(rearAxle) + new Vector3(0, .34f, -.37f);
            holder.localRotation = Quaternion.Euler(10, 180, 0);
            var panel = GameObject.CreatePrimitive(PrimitiveType.Cube);
            panel.name = "Placa_Motocicleta"; panel.transform.SetParent(holder, false);
            panel.transform.localScale = new Vector3(.19f, .115f, .008f);
            panel.GetComponent<Renderer>().sharedMaterial = plate;
            UnityEngine.Object.DestroyImmediate(panel.GetComponent<Collider>());
            var textObject = new GameObject("Identificacao_Placa");
            textObject.transform.SetParent(holder, false);
            textObject.transform.localPosition = new Vector3(0, 0, -.005f);
            textObject.transform.localRotation = Quaternion.identity;
            var text = textObject.AddComponent<TextMesh>();
            text.text = "MOTO SIM"; text.anchor = TextAnchor.MiddleCenter; text.alignment = TextAlignment.Center;
            text.characterSize = .023f; text.fontSize = 48; text.color = new Color(.9f, .91f, .85f);
            text.GetComponent<Renderer>().sharedMaterial = lettering;
        }
        private static Material PaintMaterialFor(string part)
        {
            if (part == "Paralama_Dianteiro" || part == "Carenagem_Farol")
                return PaintMaterial("MotoSim_Amarelo", new Color(1f, .72f, .02f), .28f);
            if (part == "Object_4" || part == "Object_6") return PaintMaterial("MotoSim_Cinza_Motor", new Color(.42f, .45f, .48f), .52f);
            if (part == "Object_7") return PaintMaterial("MotoSim_Cinza_Escapamento", new Color(.48f, .5f, .53f), .62f);
            if (part == "Garfo_ParteInferior_Par" || part == "Pinca_Dianteira" || part == "Disco_Freio_Dianteiro" ||
                part == "Suportes_Paralama" || part.StartsWith("Amortecedor_Corpo_") ||
                part == "Balanca_Bracos" || part == "Balanca_Placas_Eixo")
                return PaintMaterial("MotoSim_Cinza_Suspensao", new Color(.52f, .55f, .58f), .56f);
            if (part.StartsWith("Molas_Traseiras_"))
                return PaintMaterial("MotoSim_Molas_Vermelhas", new Color(.82f, .035f, .055f), .42f);
            if (part.StartsWith("Manete_"))
                return PaintMaterial("MotoSim_Aluminio_Comandos", new Color(.68f, .72f, .76f), .48f);
            if (part == "Guidao_Comandos_Conjunto_Pendente")
                return PaintMaterial("MotoSim_Comandos_Grafite", new Color(.2f, .23f, .26f), .42f);
            if (part == "Painel_Simbolos_Originais")
                return PaintMaterial("MotoSim_Painel_Ciano", new Color(.2f, .85f, .94f), .32f);
            if (part.StartsWith("Chave_Argolas_Chaveiro_"))
                return PaintMaterial("MotoSim_Chave_Dourada", new Color(.92f, .66f, .12f), .52f);
            if (part == "Cabos_Escapamento_Pendente")
                return PaintMaterial("MotoSim_Cabos_Aco", new Color(.44f, .48f, .52f), .48f);
            if (part == "Manopla_Acelerador_Borracha" || part == "Manoplas_Par" ||
                part == "Object_20" || part == "Object_5" || part == "Object_12")
                return PaintMaterial("MotoSim_Preto", new Color(.025f, .03f, .04f), .32f);
            return null;
        }
        private static Material LightMaterialFor(string part)
        {
            if (part == "Lente_Farol") return TranslucentLightMaterial("MotoSim_Lente_Farol", new Color(.82f, .9f, 1f, .32f));
            if (part == "Lente_Lanterna_Traseira" || part == "Emissores_Traseiros_Centro")
                return TranslucentLightMaterial("MotoSim_Lente_Traseira_Vermelha", new Color(1f, .025f, .02f, .48f));
            if (part.StartsWith("Lente_Seta_") || part.StartsWith("Lampada_Seta_"))
                return TranslucentLightMaterial("MotoSim_Lente_Setas_Amber", new Color(1f, .38f, .015f, .42f));
            return null;
        }
        private static Material TranslucentLightMaterial(string name, Color color)
        {
            string path = Generated + "/Materials/" + name + ".mat";
            Material material = AssetDatabase.LoadAssetAtPath<Material>(path);
            if (material == null)
            {
                Shader shader = Shader.Find("Universal Render Pipeline/Lit");
                if (shader == null) throw new InvalidOperationException("Shader URP Lit não encontrado para as lentes.");
                material = new Material(shader) { name = name };
                AssetDatabase.CreateAsset(material, path);
            }
            material.SetFloat("_Surface", 1f);
            material.SetFloat("_Blend", 0f);
            material.SetFloat("_SrcBlend", (float)BlendMode.SrcAlpha);
            material.SetFloat("_DstBlend", (float)BlendMode.OneMinusSrcAlpha);
            material.SetFloat("_ZWrite", 0f);
            material.SetColor("_BaseColor", color);
            material.SetColor("_EmissionColor", Color.black);
            material.SetFloat("_Smoothness", .22f);
            material.SetFloat("_Metallic", 0f);
            material.SetOverrideTag("RenderType", "Transparent");
            material.EnableKeyword("_SURFACE_TYPE_TRANSPARENT");
            material.EnableKeyword("_EMISSION");
            material.SetShaderPassEnabled("DepthOnly", false);
            material.renderQueue = (int)RenderQueue.Transparent;
            EditorUtility.SetDirty(material);
            return material;
        }
        private static Material PaintMaterial(string name, Color color, float smoothness)
        {
            string path = Generated + "/Materials/" + name + ".mat";
            Material material = AssetDatabase.LoadAssetAtPath<Material>(path);
            if (material != null) return material;
            Shader shader = Shader.Find("Universal Render Pipeline/Lit");
            if (shader == null) throw new InvalidOperationException("Shader URP Lit não encontrado ao criar a pintura.");
            material = new Material(shader) { name = name };
            material.SetColor("_BaseColor", color); material.SetFloat("_Smoothness", smoothness);
            material.SetFloat("_Metallic", .12f); AssetDatabase.CreateAsset(material, path);
            return material;
        }
        private static void RemoveMirrors(GameObject visual)
        {
            foreach (Transform part in visual.GetComponentsInChildren<Transform>(true))
                if (part.name.IndexOf("Retrovisor", StringComparison.OrdinalIgnoreCase) >= 0)
                    part.gameObject.SetActive(false);
        }
        private static Transform Find(GameObject model, string name)
        {
            var value = model.GetComponentsInChildren<Transform>(true).FirstOrDefault(t=>t.name==name);
            if (value == null) throw new InvalidOperationException("Peça necessária não encontrada: " + name);
            return value;
        }
        private static Bounds TyreBounds(GameObject model, string prefix)
        {
            var values = model.GetComponentsInChildren<Renderer>(true).Where(r=>r.name.StartsWith(prefix,StringComparison.Ordinal)).ToArray();
            if (values.Length==0) throw new InvalidOperationException("Pneus não encontrados: " + prefix);
            Bounds bounds=values[0].bounds; foreach(var value in values) bounds.Encapsulate(value.bounds); return bounds;
        }
        private static float TyreRadius(GameObject model,string prefix,Vector3 center)
        {
            Bounds bounds=TyreBounds(model,prefix);float radius=Mathf.Max(bounds.max.y-center.y,center.y-bounds.min.y);
            if (radius<.15f||radius>.6f) throw new InvalidOperationException("Raio de pneu fora da faixa do teste: "+radius);
            return radius;
        }
        private static WheelCollider MakeWheel(GameObject root,string name,Vector3 center,float radius,float supportedMass,BikePhysicsProfile p)
        {
            var obj=new GameObject(name);obj.transform.SetParent(root.transform,false);
            obj.transform.position=center+Vector3.up*p.SuspensionTravelMetres*.5f;
            var wheel=obj.AddComponent<WheelCollider>();wheel.radius=radius;wheel.mass=8;wheel.sprungMass=supportedMass;
            wheel.suspensionDistance=p.SuspensionTravelMetres;wheel.forceAppPointDistance=.04f;wheel.wheelDampingRate=.4f;
            float k=VehicleCalibration.SpringRate(supportedMass,p.SuspensionFrequencyHz * .82f);
            wheel.suspensionSpring=new JointSpring {spring=k,damper=VehicleCalibration.DamperRate(supportedMass,k,Mathf.Max(1.05f,p.SuspensionDampingRatio)),targetPosition=.5f};
            var forward=wheel.forwardFriction;forward.extremumSlip=.25f;forward.extremumValue=1;forward.asymptoteSlip=.5f;forward.asymptoteValue=.75f;forward.stiffness=1;wheel.forwardFriction=forward;
            var sideways=wheel.sidewaysFriction;sideways.extremumSlip=.3f;sideways.extremumValue=.85f;sideways.asymptoteSlip=.65f;sideways.asymptoteValue=.68f;sideways.stiffness=.82f;wheel.sidewaysFriction=sideways;
            // Avoid a low-speed substep tier change around the reported 18–20 km/h region.
            wheel.ConfigureVehicleSubsteps(100,16,16);return wheel;
        }
        private static void CreateSurface()
        {
            const string meshPath=Generated+"/SuperficieTeste.asset", materialPath=Generated+"/Materials/SuperficieTeste.mat";
            Mesh mesh=AssetDatabase.LoadAssetAtPath<Mesh>(meshPath);
            if(mesh==null)
            {
                mesh=new Mesh { name="SuperficieTeste" };
                mesh.vertices=new[]{new Vector3(-30,0,-20),new Vector3(-30,0,100),new Vector3(30,0,100),new Vector3(30,0,-20)};
                mesh.triangles=new[]{0,1,2,0,2,3};mesh.uv=new[]{Vector2.zero,Vector2.up,Vector2.one,Vector2.right};
                mesh.RecalculateNormals();mesh.RecalculateBounds();AssetDatabase.CreateAsset(mesh,meshPath);
            }
            Material material=AssetDatabase.LoadAssetAtPath<Material>(materialPath);
            if(material==null)
            {
                material=new Material(Shader.Find("Universal Render Pipeline/Lit"));material.SetColor("_BaseColor",new Color(.16f,.17f,.18f));
                material.SetFloat("_Smoothness",.08f);AssetDatabase.CreateAsset(material,materialPath);
            }
            var ground=new GameObject("Superficie_De_Validacao");ground.AddComponent<MeshFilter>().sharedMesh=mesh;
            ground.AddComponent<MeshRenderer>().sharedMaterial=material;
            var collider=ground.AddComponent<BoxCollider>();collider.center=new Vector3(0,-.1f,40);collider.size=new Vector3(60,.2f,120);
        }
    }
}
