using System;
using UnityEngine;

namespace MotoSim.Unity
{
    /// <summary>Compact rider dashboard with live telemetry and practical controls.</summary>
    public sealed class RideTelemetry : MonoBehaviour
    {
        [SerializeField] private MotorcycleController motorcycle;
        [SerializeField] private RideCamera rideCamera;
        [SerializeField] private MotorcycleLighting lighting;
        [SerializeField] private bool cameraSettingsOpen;
        private Texture2D panelTexture;
        private GUIStyle panelStyle, titleStyle, speedStyle, valueStyle, labelStyle, buttonStyle;

        public void Configure(MotorcycleController vehicle, RideCamera camera, MotorcycleLighting lights)
        { motorcycle = vehicle; rideCamera = camera; lighting = lights; }

        private void OnGUI()
        {
            if (motorcycle == null) return;
            EnsureStyles();
            DrawRiderPanel();
            DrawCameraPanel();
        }

        private void DrawRiderPanel()
        {
            float width = Mathf.Min(374, Screen.width - 24);
            GUI.Box(new Rect(12, 12, width, 302), GUIContent.none, panelStyle);
            GUI.Label(new Rect(28, 20, width - 32, 24), "MOTOSIM  |  PAINEL DO PILOTO", titleStyle);

            float speed = motorcycle.SpeedKph;
            GUI.Label(new Rect(28, 48, 170, 70), speed.ToString("00"), speedStyle);
            GUI.Label(new Rect(171, 78, 54, 26), "km/h", valueStyle);
            GUI.Label(new Rect(width - 112, 62, 90, 42), "LIMITE\n" + motorcycle.MaximumSpeedKph.ToString("0"), labelStyle);

            var state = motorcycle.Telemetry;
            string gear = state.Gear == 0 ? "N" : state.Gear.ToString();
            GUI.Label(new Rect(29, 122, width - 40, 22), "RPM  " + state.EngineRpm.ToString("0") +
                "       MARCHA  " + gear + "       " + (state.EngineRunning ? "MOTOR LIGADO" : "MOTOR DESLIGADO"), valueStyle);
            DrawRpmBar(new Rect(29, 146, width - 56, 8), state.EngineRpm / 9000f);

            float buttonY = 166;
            float gap = 5;
            float buttonWidth = (width - 34 - gap * 4) / 5;
            DrawButton(new Rect(28, buttonY, buttonWidth, 42), state.EngineRunning ? "MOTOR\nDESLIGAR" : "MOTOR\nLIGAR",
                state.EngineRunning ? new Color(.27f, .62f, .43f) : new Color(.22f, .42f, .58f),
                motorcycle.RequestIgnitionToggle);
            DrawButton(new Rect(28 + (buttonWidth + gap), buttonY, buttonWidth, 42),
                lighting != null && lighting.HeadlampOn ? "FAROL\nLIGADO  L" : "FAROL\nDESLIGADO  L",
                lighting != null && lighting.HeadlampOn ? new Color(.72f, .58f, .25f) : new Color(.24f, .29f, .36f),
                () => lighting?.ToggleHeadlamp());
            DrawButton(new Rect(28 + 2 * (buttonWidth + gap), buttonY, buttonWidth, 42), "SETA\nESQ.  Z",
                lighting != null && lighting.LeftSignalOn ? new Color(.84f, .48f, .12f) : new Color(.24f, .29f, .36f),
                () => lighting?.ToggleLeftSignal());
            DrawButton(new Rect(28 + 3 * (buttonWidth + gap), buttonY, buttonWidth, 42), "SETA\nDIR.  X",
                lighting != null && lighting.RightSignalOn ? new Color(.84f, .48f, .12f) : new Color(.24f, .29f, .36f),
                () => lighting?.ToggleRightSignal());
            DrawButton(new Rect(28 + 4 * (buttonWidth + gap), buttonY, buttonWidth, 42), "ALERTA\nH",
                lighting != null && lighting.HazardsOn ? new Color(.84f, .48f, .12f) : new Color(.24f, .29f, .36f),
                () => lighting?.ToggleHazards());

            GUI.Label(new Rect(29, 214, width - 40, 20),
                "VELOCIDADE REAL     " + speed.ToString("0.0") + " km/h     SENTIDO " +
                (motorcycle.SignedForwardSpeedKph < -.5f ? "RÉ" : "FRENTE"), labelStyle);
            GUI.Label(new Rect(29, 236, width - 40, 20),
                "Rodas  " + (motorcycle.FrontGrounded ? "Dianteira ✓" : "Dianteira —") + "  " +
                (motorcycle.RearGrounded ? "Traseira ✓" : "Traseira —") + "    Inclinação " + motorcycle.RollDegrees.ToString("0") + "°", labelStyle);
            GUI.Label(new Rect(29, 260, width - 40, 38),
                "W acelerador  |  Shift embreagem  |  Espaço freio dianteiro\nA/D direção  |  S freio traseiro  |  Q/E marchas  |  R reiniciar", labelStyle);
        }

        private void DrawCameraPanel()
        {
            if (rideCamera == null) return;
            const float width = 290;
            float x = Screen.width - width - 12;
            DrawButton(new Rect(x, 12, 140, 38), rideCamera.IsFirstPerson ? "VISÃO  1ª PESSOA" : "VISÃO  3ª PESSOA",
                new Color(.17f, .28f, .4f), rideCamera.ToggleView);
            DrawButton(new Rect(x + 146, 12, 132, 38), cameraSettingsOpen ? "FECHAR CÂMERA" : "AJUSTAR CÂMERA",
                new Color(.22f, .31f, .42f), () => cameraSettingsOpen = !cameraSettingsOpen);
            if (!cameraSettingsOpen) return;

            float verticalAdjustment = rideCamera.IsFirstPerson ? 0 : 22;
            GUI.Box(new Rect(x, 56, width, 174 + verticalAdjustment), GUIContent.none, panelStyle);
            GUI.Label(new Rect(x + 12, 63, width - 24, 22), "POSIÇÃO DA CÂMERA 1ª PESSOA", titleStyle);
            if (!rideCamera.IsFirstPerson)
                GUI.Label(new Rect(x + 12, 86, width - 24, 22), "Ajuste salvo; volte para 1ª pessoa para conferir.", labelStyle);
            float start = 91 + verticalAdjustment;
            GUI.Label(new Rect(x + 12, start, width - 24, 22), "Altura  " + rideCamera.FirstPersonHeightOffset.ToString("+0.00;-0.00;0.00") + " m", labelStyle);
            float height = GUI.HorizontalSlider(new Rect(x + 14, start + 23, width - 28, 18),
                rideCamera.FirstPersonHeightOffset, -.25f, .65f);
            GUI.Label(new Rect(x + 12, start + 45, width - 24, 22), "Distância  " + rideCamera.FirstPersonForwardOffset.ToString("+0.00;-0.00;0.00") + " m", labelStyle);
            float forward = GUI.HorizontalSlider(new Rect(x + 14, start + 68, width - 28, 18),
                rideCamera.FirstPersonForwardOffset, -.35f, .65f);
            if (GUI.Button(new Rect(x + 12, start + 98, width - 24, 28), "RESTAURAR POSIÇÃO PADRÃO", buttonStyle))
                rideCamera.ResetFirstPersonOffsets();
            if (Mathf.Abs(height - rideCamera.FirstPersonHeightOffset) > .002f ||
                Mathf.Abs(forward - rideCamera.FirstPersonForwardOffset) > .002f)
                rideCamera.SetFirstPersonOffsets(height, forward);
        }

        private void DrawRpmBar(Rect rect, float value)
        {
            GUI.color = new Color(.08f, .11f, .15f);
            GUI.DrawTexture(rect, Texture2D.whiteTexture);
            GUI.color = value > .82f ? new Color(.93f, .25f, .17f) : new Color(.22f, .76f, .62f);
            GUI.DrawTexture(new Rect(rect.x, rect.y, rect.width * Mathf.Clamp01(value), rect.height), Texture2D.whiteTexture);
            GUI.color = Color.white;
        }

        private void DrawButton(Rect rect, string text, Color tint, Action action)
        {
            Color previous = GUI.color;
            GUI.color = tint;
            if (GUI.Button(rect, text, buttonStyle)) action();
            GUI.color = previous;
        }

        private void EnsureStyles()
        {
            if (panelStyle != null) return;
            panelTexture = new Texture2D(1, 1, TextureFormat.RGBA32, false);
            panelTexture.SetPixel(0, 0, new Color(.035f, .055f, .08f, .94f)); panelTexture.Apply();
            panelStyle = new GUIStyle(GUI.skin.box) { normal = { background = panelTexture } };
            titleStyle = new GUIStyle(GUI.skin.label) { fontSize = 13, fontStyle = FontStyle.Bold,
                alignment = TextAnchor.MiddleLeft, normal = { textColor = new Color(.68f, .83f, .94f) } };
            speedStyle = new GUIStyle(GUI.skin.label) { fontSize = 58, fontStyle = FontStyle.Bold,
                alignment = TextAnchor.MiddleLeft, normal = { textColor = Color.white } };
            valueStyle = new GUIStyle(GUI.skin.label) { fontSize = 14, fontStyle = FontStyle.Bold,
                alignment = TextAnchor.MiddleLeft, normal = { textColor = Color.white } };
            labelStyle = new GUIStyle(GUI.skin.label) { fontSize = 11,
                alignment = TextAnchor.MiddleLeft, normal = { textColor = new Color(.78f, .84f, .9f) } };
            buttonStyle = new GUIStyle(GUI.skin.button) { fontSize = 10, fontStyle = FontStyle.Bold,
                alignment = TextAnchor.MiddleCenter, wordWrap = true, normal = { textColor = Color.white } };
        }

        private void OnDestroy()
        { if (panelTexture != null) Destroy(panelTexture); }
    }
}
