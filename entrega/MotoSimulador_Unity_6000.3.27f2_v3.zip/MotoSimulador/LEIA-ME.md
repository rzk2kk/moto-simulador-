# MotoSimulador — Unity 6.3 LTS / versão 3

Projeto para o Editor **6000.3.27f2** e URP **17.3.0**. O pacote atual é MotoSimulador_Unity_6000.3.27f2_v3.zip.

## Abrir e testar

1. Feche a Unity e extraia o ZIP em uma pasta nova.
2. Abra ABRIR_PROJETO.bat e aguarde a importação.
3. Clique em Play. A cena de teste físico é preparada automaticamente.

Para sair: **I**, segure **Shift** e aperte **Q**; depois segure **W** e solte **Shift**. **A/D** dirigem, **Espaço** freia na frente, **S** freia atrás. **R** recomeça se cair ou travar. O HUD contém as demais teclas. A liberação da embreagem no teclado é gradual.

É um primeiro teste físico com **parâmetros provisórios**. A configuração foi implementada e os cálculos do núcleo passaram nos testes; comportamento de contato e estabilidade ainda precisam ser validados na Unity do usuário.

## Estado real

- Modelo original preservado e visível; não substituído por formas genéricas.
- Escala uniforme calculada por entre-eixos configurável; raios medidos no modelo importado.
- Massa de moto/piloto, centro de massa, suspensão e aderência iniciais, ainda sem certificação para o ano da CG enviada.
- Motor, embreagem, marchas e freios independentes ligados a WheelColliders; assistência de equilíbrio e câmera de acompanhamento.
- 30 testes C# puro aprovados; esses testes não executam Unity/PhysX.
- Não há validação local do Editor nesta máquina da nuvem. A versão de inspeção v2 foi confirmada pelo usuário; a pilotagem v3 ainda não foi testada no PC.

Consulte Documentation/TESTE_FISICO_v3.md para valores, comandos e limitações. O perfil Assets/MotoSim/Config/PhysicsCalibration.json está marcado ReferenceVerified=false. Não apresentar seus números como especificações oficiais da Honda.

Mecanismos visuais completos (guidão, garfo, amortecedores, corrente e comandos), sistema elétrico, áudio, painel original, piloto, materiais finais, mapa e otimização ainda estão pendentes na Unity. O núcleo físico não equivale ao jogo completo.

## Automação

A marca MotoSimProject.json solicita a cena riding-test. A preparação preserva cenas Untitled em Generated/Recuperadas antes de criar outra cena, mantendo a correção v2. Não sobrescreve uma cena de teste já existente. O menu MotoSim/Abrir teste físico permite retomar; MotoSim/Abrir inspeção da moto mantém acesso à etapa visual anterior.

Câmera ativa e gravação da cena são verificadas antes do marcador de conclusão. Falhas são registradas no Console e em MotoSim_Setup_Error.txt. O relatório de escala/massa/raios é salvo em ProjectSettings/MotoSimCalibrationReport.json após montagem no PC.

## Reprodução

Na raiz do repositório: python3 tools/check_core.py. Gerar o pacote: python3 tools/package_unity_project.py. O núcleo tem fonte única em Assets/MotoSim/Core, referenciada pelos projetos .NET. O SDK local é preparado por tools/setup_dotnet.py com verificação SHA-512 oficial.

O BAT usa a instalação padrão C:\Program Files\Unity\Hub\Editor\6000.3.27f2\Editor\Unity.exe. Se estiver em outra pasta, o Hub pode abrir diretamente a pasta MotoSimulador. Nenhuma reinstalação do Editor é necessária para o pacote.

## Atribuição

CG 160: rafaazx1000, CC-BY-4.0; https://sketchfab.com/3d-models/cg-160-0900747144084e538244f8c504161baa . Modificações: separação de peças, hierarquia, materiais demonstrativos, exportação e montagem de teste. Preservar atribuição e indicação das alterações. Essa é a licença declarada do modelo, não uma declaração de licença para todo o código.
