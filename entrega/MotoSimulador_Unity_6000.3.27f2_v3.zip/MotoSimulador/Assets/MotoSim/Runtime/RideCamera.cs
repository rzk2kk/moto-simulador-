using UnityEngine;

namespace MotoSim.Unity
{
    public sealed class RideCamera : MonoBehaviour
    {
        [SerializeField] private Transform target;
        private Vector3 velocity;
        public void Configure(Transform vehicle) { target = vehicle; Position(false); }
        private void LateUpdate() => Position(true);
        private void Position(bool smooth)
        {
            if (target == null) return;
            Vector3 forward = Vector3.ProjectOnPlane(target.forward, Vector3.up).normalized;
            Vector3 desired = target.position - forward * 3.3f + Vector3.up * 1.65f;
            transform.position = smooth ? Vector3.SmoothDamp(transform.position, desired, ref velocity, .15f) : desired;
            transform.LookAt(target.position + Vector3.up * .65f + forward * .4f, Vector3.up);
        }
    }
}
